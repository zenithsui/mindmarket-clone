const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["_astro/AnchorsNav.DiYM58Jd.js","_astro/scroll.C7dNMCy6.js","_astro/index.DtsRjIc2.js","_astro/index.BSdFiPHn.js","_astro/component-manager.modern.i7ixt_80.js","_astro/index.esm.Fld8o4I5.js"])))=>i.map(i=>d[i]);
import{_}from"./preload-helper.BlTxHScW.js";_(()=>import("./AnchorsNav.DiYM58Jd.js"),__vite__mapDeps([0,1,2,3,4,5]));
