import{$ as r}from"./preloader.DyWePj1f.js";import"./index.BSdFiPHn.js";r.subscribe(e=>{document.documentElement.style.setProperty("--preloader-delay",`${e/1e3}s`)});
