import { i as R } from "./component-manager.modern.i7ixt_80.js";
import { r as S } from "./rive.CThzgbxe.js";
import "./index.BSdFiPHn.js";
const r = -34,
  u = -15;
class M extends HTMLElement {
  $canvas;
  $button;
  rive;
  animationFrame = null;
  constructor() {
    super(),
      (this.$canvas = this.querySelector(".c-button-quote_icon_canvas")),
      (this.$button = this.querySelector(".c-button-quote")),
      (this.rive = null);
  }
  connectedCallback() {
    this.$canvas && this.initRive();
  }
  disconnectedCallback() {
    this.animationFrame !== null &&
      (cancelAnimationFrame(this.animationFrame), (this.animationFrame = null)),
      this.rive?.cleanup();
  }
  initRive() {
    this.rive = new S.Rive({
      src: "/rive/mindmarket_cursor_crop.riv",
      canvas: this.$canvas,
      stateMachines: "State Machine 1",
      autoplay: !0,
      autoBind: !0,
      onLoad: () => {
        this.rive?.resizeDrawingSurfaceToCanvas();
        const a = this.rive
          ?.stateMachineInputs("State Machine 1")
          ?.find((t) => t.name === "isSmiling");
        a?.value;
        const o = this.rive?.viewModelInstance;
        if (!o) return;
        const e = o.number("posx"),
          n = o.number("posy");
        e && (e.value = r), n && (n.value = u);
        const l = (t, s, i) => t + (s - t) * i,
          m = 0.1,
          v = () => {
            if (!e || !n) return;
            const t = e.value,
              s = n.value,
              i = 0.5;
            if (Math.abs(t - r) < i && Math.abs(s - u) < i) {
              e && (e.value = r),
                n && (n.value = u),
                (this.animationFrame = null);
              return;
            }
            e && (e.value = l(t, r, m)),
              n && (n.value = l(s, u, m)),
              (this.animationFrame = requestAnimationFrame(v));
          },
          h = (t, s) => {
            this.animationFrame !== null &&
              (cancelAnimationFrame(this.animationFrame),
              (this.animationFrame = null));
            const i = this.$canvas?.getBoundingClientRect();
            if (!i) return;
            const d = t - i.left,
              f = s - i.top,
              F = this.mapCursorToRange(d, i.width),
              b = this.mapCursorToRange(f, i.height);
            e && (e.value = F), n && (n.value = b);
          },
          p = (t) => {
            h(t.clientX, t.clientY);
          };
        window.addEventListener("mousemove", p),
          this.$button.addEventListener("mouseenter", () => {
            a && (a.value = !0);
          }),
          this.$button.addEventListener("mouseleave", () => {
            a && (a.value = !1);
          }),
          document.addEventListener("mouseleave", () => {
            this.animationFrame !== null &&
              cancelAnimationFrame(this.animationFrame),
              v();
          });
      },
    });
  }
  mapCursorToRange = (c, a) => -90 + (((c / a) * 100) / 100) * 110;
}
customElements.define("c-button-quote", R(M, "ButtonQuote"));
export { M as default };
