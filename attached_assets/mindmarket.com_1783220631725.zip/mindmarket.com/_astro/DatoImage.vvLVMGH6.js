import { i as t } from "./component-manager.modern.i7ixt_80.js";
import "./index.BSdFiPHn.js";
class e extends HTMLElement {
  $img;
  constructor() {
    super(), (this.$img = this.querySelector("img"));
  }
  connectedCallback() {
    this.setup();
  }
  disconnectedCallback() {
    this.$img && this.$img.removeEventListener("load", this.setOpacity);
  }
  setup() {
    this.$img &&
      (this.$img.complete
        ? this.setOpacity()
        : this.$img.addEventListener("load", this.setOpacity));
  }
  setOpacity = () => {
    this.$img && (this.$img.style.opacity = "1");
  };
}
customElements.define("c-dato-image", t(e, "DatoImage"));
export { e as default };
