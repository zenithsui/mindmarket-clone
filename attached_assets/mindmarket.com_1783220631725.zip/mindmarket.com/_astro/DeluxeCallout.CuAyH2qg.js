import { i as t } from "./component-manager.modern.i7ixt_80.js";
import "./index.BSdFiPHn.js";
const e = "is-active";
class s extends HTMLElement {
  $button;
  constructor() {
    super(),
      (this.$button = this.querySelector("[data-deluxe-callout-action]"));
  }
  connectedCallback() {
    this.bindEvents();
  }
  disconnectedCallback() {
    this.unbindEvents();
  }
  bindEvents() {
    this.$button?.addEventListener("mouseenter", this.onMouseEnter),
      this.$button?.addEventListener("mouseleave", this.onMouseLeave);
  }
  unbindEvents() {
    this.$button?.removeEventListener("mouseenter", this.onMouseEnter),
      this.$button?.removeEventListener("mouseleave", this.onMouseLeave);
  }
  onMouseEnter = () => {
    this.classList.add(e);
  };
  onMouseLeave = () => {
    this.classList.remove(e);
  };
}
customElements.define("c-deluxe-callout", t(s, "DeluxeCallout"));
export { s as default };
