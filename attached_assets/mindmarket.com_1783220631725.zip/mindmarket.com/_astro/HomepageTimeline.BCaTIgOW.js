import { i as oe } from "./component-manager.modern.i7ixt_80.js";
import { g as Z } from "./index.CsVyfrhj.js";
import { D as ae } from "./DrawSVGPlugin.C1ayHBcE.js";
import { $ as he } from "./screen.B17Nb0Vk.js";
import "./index.BSdFiPHn.js";
import "./index.esm.Fld8o4I5.js";
import "./index.DtsRjIc2.js";
/*!
 * paths 3.13.0
 * https://gsap.com
 *
 * Copyright 2008-2025, GreenSock. All rights reserved.
 * Subject to the terms at https://gsap.com/standard-license
 * @author: Jack Doyle, jack@greensock.com
 */ var le = /[achlmqstvz]|(-?\d*\.?\d*(?:e[\-+]?\d+)?)[0-9]/gi,
  me = /[\+\-]?\d*\.?\d+e[\+\-]?\d+/gi,
  ce = Math.PI / 180,
  W = Math.sin,
  Q = Math.cos,
  z = Math.abs,
  R = Math.sqrt,
  fe = function (i) {
    return typeof i == "number";
  },
  K = 1e5,
  k = function (i) {
    return Math.round(i * K) / K || 0;
  };
function ue(p, i, c, e, t, o, d) {
  for (var f = p.length, l, n, m, s, g; --f > -1; )
    for (l = p[f], n = l.length, m = 0; m < n; m += 2)
      (s = l[m]),
        (g = l[m + 1]),
        (l[m] = s * i + g * e + o),
        (l[m + 1] = s * c + g * t + d);
  return (p._dirty = 1), p;
}
function de(p, i, c, e, t, o, d, f, l) {
  if (!(p === f && i === l)) {
    (c = z(c)), (e = z(e));
    var n = (t % 360) * ce,
      m = Q(n),
      s = W(n),
      g = Math.PI,
      S = g * 2,
      r = (p - f) / 2,
      h = (i - l) / 2,
      P = m * r + s * h,
      u = -s * r + m * h,
      a = P * P,
      b = u * u,
      x = a / (c * c) + b / (e * e);
    x > 1 && ((c = R(x) * c), (e = R(x) * e));
    var y = c * c,
      T = e * e,
      M = (y * T - y * b - T * a) / (y * b + T * a);
    M < 0 && (M = 0);
    var E = (o === d ? -1 : 1) * R(M),
      w = E * ((c * u) / e),
      v = E * -((e * P) / c),
      N = (p + f) / 2,
      D = (i + l) / 2,
      L = N + (m * w - s * v),
      te = D + (s * w + m * v),
      C = (P - w) / c,
      q = (u - v) / e,
      I = (-P - w) / c,
      O = (-u - v) / e,
      U = C * C + q * q,
      B = (q < 0 ? -1 : 1) * Math.acos(C / R(U)),
      G =
        (C * O - q * I < 0 ? -1 : 1) *
        Math.acos((C * I + q * O) / R(U * (I * I + O * O)));
    isNaN(G) && (G = g),
      !d && G > 0 ? (G -= S) : d && G < 0 && (G += S),
      (B %= S),
      (G %= S);
    var J = Math.ceil(z(G) / (S / 4)),
      V = [],
      H = G / J,
      j = ((4 / 3) * W(H / 2)) / (1 + Q(H / 2)),
      ie = m * c,
      ne = s * c,
      se = s * -e,
      re = m * e,
      $;
    for ($ = 0; $ < J; $++)
      (t = B + $ * H),
        (P = Q(t)),
        (u = W(t)),
        (C = Q((t += H))),
        (q = W(t)),
        V.push(P - j * u, u + j * P, C + j * q, q - j * C, C, q);
    for ($ = 0; $ < V.length; $ += 2)
      (P = V[$]),
        (u = V[$ + 1]),
        (V[$] = P * ie + u * se + L),
        (V[$ + 1] = P * ne + u * re + te);
    return (V[$ - 2] = f), (V[$ - 1] = l), V;
  }
}
function ge(p) {
  var i =
      (p + "")
        .replace(me, function (w) {
          var v = +w;
          return v < 1e-4 && v > -1e-4 ? 0 : v;
        })
        .match(le) || [],
    c = [],
    e = 0,
    t = 0,
    o = 2 / 3,
    d = i.length,
    f = 0,
    l = "ERROR: malformed path: " + p,
    n,
    m,
    s,
    g,
    S,
    r,
    h,
    P,
    u,
    a,
    b,
    x,
    y,
    T,
    M,
    E = function (v, N, D, L) {
      (a = (D - v) / 3),
        (b = (L - N) / 3),
        h.push(v + a, N + b, D - a, L - b, D, L);
    };
  if (!p || !isNaN(i[0]) || isNaN(i[1])) return console.log(l), c;
  for (n = 0; n < d; n++)
    if (
      ((y = S),
      isNaN(i[n]) ? ((S = i[n].toUpperCase()), (r = S !== i[n])) : n--,
      (s = +i[n + 1]),
      (g = +i[n + 2]),
      r && ((s += e), (g += t)),
      n || ((P = s), (u = g)),
      S === "M")
    )
      h && (h.length < 8 ? (c.length -= 1) : (f += h.length)),
        (e = P = s),
        (t = u = g),
        (h = [s, g]),
        c.push(h),
        (n += 2),
        (S = "L");
    else if (S === "C")
      h || (h = [0, 0]),
        r || (e = t = 0),
        h.push(
          s,
          g,
          e + i[n + 3] * 1,
          t + i[n + 4] * 1,
          (e += i[n + 5] * 1),
          (t += i[n + 6] * 1)
        ),
        (n += 6);
    else if (S === "S")
      (a = e),
        (b = t),
        (y === "C" || y === "S") &&
          ((a += e - h[h.length - 4]), (b += t - h[h.length - 3])),
        r || (e = t = 0),
        h.push(a, b, s, g, (e += i[n + 3] * 1), (t += i[n + 4] * 1)),
        (n += 4);
    else if (S === "Q")
      (a = e + (s - e) * o),
        (b = t + (g - t) * o),
        r || (e = t = 0),
        (e += i[n + 3] * 1),
        (t += i[n + 4] * 1),
        h.push(a, b, e + (s - e) * o, t + (g - t) * o, e, t),
        (n += 4);
    else if (S === "T")
      (a = e - h[h.length - 4]),
        (b = t - h[h.length - 3]),
        h.push(
          e + a,
          t + b,
          s + (e + a * 1.5 - s) * o,
          g + (t + b * 1.5 - g) * o,
          (e = s),
          (t = g)
        ),
        (n += 2);
    else if (S === "H") E(e, t, (e = s), t), (n += 1);
    else if (S === "V") E(e, t, e, (t = s + (r ? t - e : 0))), (n += 1);
    else if (S === "L" || S === "Z")
      S === "Z" && ((s = P), (g = u), (h.closed = !0)),
        (S === "L" || z(e - s) > 0.5 || z(t - g) > 0.5) &&
          (E(e, t, s, g), S === "L" && (n += 2)),
        (e = s),
        (t = g);
    else if (S === "A") {
      if (
        ((T = i[n + 4]),
        (M = i[n + 5]),
        (a = i[n + 6]),
        (b = i[n + 7]),
        (m = 7),
        T.length > 1 &&
          (T.length < 3
            ? ((b = a), (a = M), m--)
            : ((b = M), (a = T.substr(2)), (m -= 2)),
          (M = T.charAt(1)),
          (T = T.charAt(0))),
        (x = de(
          e,
          t,
          +i[n + 1],
          +i[n + 2],
          +i[n + 3],
          +T,
          +M,
          (r ? e : 0) + a * 1,
          (r ? t : 0) + b * 1
        )),
        (n += m),
        x)
      )
        for (m = 0; m < x.length; m++) h.push(x[m]);
      (e = h[h.length - 2]), (t = h[h.length - 1]);
    } else console.log(l);
  return (
    (n = h.length),
    n < 6
      ? (c.pop(), (n = 0))
      : h[0] === h[n - 2] && h[1] === h[n - 1] && (h.closed = !0),
    (c.totalPoints = f + n),
    c
  );
}
function pe(p) {
  fe(p[0]) && (p = [p]);
  var i = "",
    c = p.length,
    e,
    t,
    o,
    d;
  for (t = 0; t < c; t++) {
    for (
      d = p[t], i += "M" + k(d[0]) + "," + k(d[1]) + " C", e = d.length, o = 2;
      o < e;
      o++
    )
      i +=
        k(d[o++]) +
        "," +
        k(d[o++]) +
        " " +
        k(d[o++]) +
        "," +
        k(d[o++]) +
        " " +
        k(d[o++]) +
        "," +
        k(d[o]) +
        " ";
    d.closed && (i += "z");
  }
  return i;
}
/*!
 * CustomEase 3.13.0
 * https://gsap.com
 *
 * @license Copyright 2008-2025, GreenSock. All rights reserved.
 * Subject to the terms at https://gsap.com/standard-license
 * @author: Jack Doyle, jack@greensock.com
 */ var _,
  F,
  ee = function () {
    return (
      _ || (typeof window < "u" && (_ = window.gsap) && _.registerPlugin && _)
    );
  },
  Y = function () {
    (_ = ee()),
      _
        ? (_.registerEase("_CE", A.create), (F = 1))
        : console.warn("Please gsap.registerPlugin(CustomEase)");
  },
  Se = 1e20,
  X = function (i) {
    return ~~(i * 1e3 + (i < 0 ? -0.5 : 0.5)) / 1e3;
  },
  be = /[-+=.]*\d+[.e\-+]*\d*[e\-+]*\d*/gi,
  Pe = /[cLlsSaAhHvVtTqQ]/g,
  ye = function (i) {
    var c = i.length,
      e = Se,
      t;
    for (t = 1; t < c; t += 6) +i[t] < e && (e = +i[t]);
    return e;
  },
  Te = function (i, c, e) {
    !e && e !== 0 && (e = Math.max(+i[i.length - 1], +i[1]));
    var t = +i[0] * -1,
      o = -e,
      d = i.length,
      f = 1 / (+i[d - 2] + t),
      l =
        -c ||
        (Math.abs(+i[d - 1] - +i[1]) < 0.01 * (+i[d - 2] - +i[0])
          ? ye(i) + o
          : +i[d - 1] + o),
      n;
    for (l ? (l = 1 / l) : (l = -f), n = 0; n < d; n += 2)
      (i[n] = (+i[n] + t) * f), (i[n + 1] = (+i[n + 1] + o) * l);
  },
  xe = function p(i, c, e, t, o, d, f, l, n, m, s) {
    var g = (i + e) / 2,
      S = (c + t) / 2,
      r = (e + o) / 2,
      h = (t + d) / 2,
      P = (o + f) / 2,
      u = (d + l) / 2,
      a = (g + r) / 2,
      b = (S + h) / 2,
      x = (r + P) / 2,
      y = (h + u) / 2,
      T = (a + x) / 2,
      M = (b + y) / 2,
      E = f - i,
      w = l - c,
      v = Math.abs((e - f) * w - (t - l) * E),
      N = Math.abs((o - f) * w - (d - l) * E),
      D;
    return (
      m ||
        ((m = [
          { x: i, y: c },
          { x: f, y: l },
        ]),
        (s = 1)),
      m.splice(s || m.length - 1, 0, { x: T, y: M }),
      (v + N) * (v + N) > n * (E * E + w * w) &&
        ((D = m.length),
        p(i, c, g, S, a, b, T, M, n, m, s),
        p(T, M, x, y, P, u, f, l, n, m, s + 1 + (m.length - D))),
      m
    );
  },
  A = (function () {
    function p(c, e, t) {
      F || Y(), (this.id = c), this.setData(e, t);
    }
    var i = p.prototype;
    return (
      (i.setData = function (e, t) {
        (t = t || {}), (e = e || "0,0,1,1");
        var o = e.match(be),
          d = 1,
          f = [],
          l = [],
          n = t.precision || 1,
          m = n <= 1,
          s,
          g,
          S,
          r,
          h,
          P,
          u,
          a,
          b;
        if (
          ((this.data = e),
          (Pe.test(e) || (~e.indexOf("M") && e.indexOf("C") < 0)) &&
            (o = ge(e)[0]),
          (s = o.length),
          s === 4)
        )
          o.unshift(0, 0), o.push(1, 1), (s = 8);
        else if ((s - 2) % 6) throw "Invalid CustomEase";
        for (
          (+o[0] != 0 || +o[s - 2] != 1) && Te(o, t.height, t.originY),
            this.segment = o,
            r = 2;
          r < s;
          r += 6
        )
          (g = { x: +o[r - 2], y: +o[r - 1] }),
            (S = { x: +o[r + 4], y: +o[r + 5] }),
            f.push(g, S),
            xe(
              g.x,
              g.y,
              +o[r],
              +o[r + 1],
              +o[r + 2],
              +o[r + 3],
              S.x,
              S.y,
              1 / (n * 2e5),
              f,
              f.length - 1
            );
        for (s = f.length, r = 0; r < s; r++)
          (u = f[r]),
            (a = f[r - 1] || u),
            (u.x > a.x || (a.y !== u.y && a.x === u.x) || u === a) && u.x <= 1
              ? ((a.cx = u.x - a.x),
                (a.cy = u.y - a.y),
                (a.n = u),
                (a.nx = u.x),
                m &&
                  r > 1 &&
                  Math.abs(a.cy / a.cx - f[r - 2].cy / f[r - 2].cx) > 2 &&
                  (m = 0),
                a.cx < d &&
                  (a.cx
                    ? (d = a.cx)
                    : ((a.cx = 0.001),
                      r === s - 1 &&
                        ((a.x -= 0.001), (d = Math.min(d, 0.001)), (m = 0)))))
              : (f.splice(r--, 1), s--);
        if (((s = (1 / d + 1) | 0), (h = 1 / s), (P = 0), (u = f[0]), m)) {
          for (r = 0; r < s; r++)
            (b = r * h),
              u.nx < b && (u = f[++P]),
              (g = u.y + ((b - u.x) / u.cx) * u.cy),
              (l[r] = { x: b, cx: h, y: g, cy: 0, nx: 9 }),
              r && (l[r - 1].cy = g - l[r - 1].y);
          (P = f[f.length - 1]),
            (l[s - 1].cy = P.y - g),
            (l[s - 1].cx = P.x - l[l.length - 1].x);
        } else {
          for (r = 0; r < s; r++) u.nx < r * h && (u = f[++P]), (l[r] = u);
          P < f.length - 1 && (l[r - 1] = f[f.length - 2]);
        }
        return (
          (this.ease = function (x) {
            var y = l[(x * s) | 0] || l[s - 1];
            return y.nx < x && (y = y.n), y.y + ((x - y.x) / y.cx) * y.cy;
          }),
          (this.ease.custom = this),
          this.id && _ && _.registerEase(this.id, this.ease),
          this
        );
      }),
      (i.getSVGData = function (e) {
        return p.getSVGData(this, e);
      }),
      (p.create = function (e, t, o) {
        return new p(e, t, o).ease;
      }),
      (p.register = function (e) {
        (_ = e), Y();
      }),
      (p.get = function (e) {
        return _.parseEase(e);
      }),
      (p.getSVGData = function (e, t) {
        t = t || {};
        var o = t.width || 100,
          d = t.height || 100,
          f = t.x || 0,
          l = (t.y || 0) + d,
          n = _.utils.toArray(t.path)[0],
          m,
          s,
          g,
          S,
          r,
          h,
          P,
          u,
          a,
          b;
        if (
          (t.invert && ((d = -d), (l = 0)),
          typeof e == "string" && (e = _.parseEase(e)),
          e.custom && (e = e.custom),
          e instanceof p)
        )
          m = pe(ue([e.segment], o, 0, 0, -d, f, l));
        else {
          for (
            m = [f, l],
              P = Math.max(5, (t.precision || 1) * 200),
              S = 1 / P,
              P += 2,
              u = 5 / P,
              a = X(f + S * o),
              b = X(l + e(S) * -d),
              s = (b - l) / (a - f),
              g = 2;
            g < P;
            g++
          )
            (r = X(f + g * S * o)),
              (h = X(l + e(g * S) * -d)),
              (Math.abs((h - b) / (r - a) - s) > u || g === P - 1) &&
                (m.push(a, b), (s = (h - b) / (r - a))),
              (a = r),
              (b = h);
          m = "M" + m.join(",");
        }
        return n && n.setAttribute("d", m), m;
      }),
      p
    );
  })();
A.version = "3.13.0";
A.headless = !0;
ee() && _.registerPlugin(A);
Z.registerPlugin(ae, A);
class ve extends HTMLElement {
  $desktopSvg;
  $mobileSvg;
  $mainPath;
  $secondaryPath;
  $shadowPath;
  $mobileMainPath;
  $mobileShadowPath;
  $mobileOverlapEndPath;
  masterTimeline = null;
  unbindScreenListener = null;
  constructor() {
    super(),
      (this.$desktopSvg = this.querySelector("#desktop-svg")),
      (this.$mainPath = this.$desktopSvg?.querySelector("#main-path")),
      (this.$secondaryPath =
        this.$desktopSvg?.querySelector("#secondary-path")),
      (this.$shadowPath = this.$desktopSvg?.querySelector("#shadow-path")),
      (this.$mobileSvg = this.querySelector("#mobile-svg")),
      (this.$mobileMainPath =
        this.$mobileSvg?.querySelector("#mobile-main-path")),
      (this.$mobileShadowPath = this.$mobileSvg?.querySelector(
        "#mobile-shadow-path"
      )),
      (this.$mobileOverlapEndPath = this.$mobileSvg?.querySelector(
        "#mobile-overlap-end"
      ));
  }
  connectedCallback() {
    window.addEventListener("pathProgress", this.onPathProgress),
      (this.unbindScreenListener = he.subscribe(this.onResize));
  }
  disconnectedCallback() {
    window.removeEventListener("pathProgress", this.onPathProgress),
      this.destroyTimeline();
  }
  onPathProgress = (i) => {
    const c = i.detail.progress;
    this.masterTimeline?.progress(c);
  };
  onResize = () => {
    this.destroyTimeline(),
      window.innerWidth < 1e3
        ? this.createMobileTimeline()
        : this.createDesktopTimeline();
  };
  createDesktopTimeline() {
    (this.masterTimeline = Z.timeline({ paused: !0 })),
      this.masterTimeline.fromTo(
        this.$mainPath,
        { drawSVG: "5%" },
        {
          drawSVG: "100%",
          ease: A.create("custom", "M0,0 C0.952,0.017 0.744,0.69 1,1 "),
          duration: 0.9,
        }
      ),
      this.masterTimeline.fromTo(
        this.$secondaryPath,
        { drawSVG: "0%" },
        { drawSVG: "100%", ease: "none", duration: 1 }
      ),
      this.masterTimeline.fromTo(
        this.$shadowPath,
        { opacity: 0 },
        { opacity: 1, ease: "none", duration: 0.15 },
        0.95
      );
  }
  createMobileTimeline() {
    (this.masterTimeline = Z.timeline({ paused: !0 })),
      this.masterTimeline.fromTo(
        this.$mobileMainPath,
        { drawSVG: "0.1%" },
        { drawSVG: "100%", duration: 1, ease: "power1.in" }
      ),
      this.masterTimeline.fromTo(
        this.$mobileOverlapEndPath,
        { drawSVG: "0%" },
        { drawSVG: "100%", ease: "none", duration: 1 }
      ),
      this.masterTimeline.fromTo(
        this.$mobileShadowPath,
        { opacity: 0 },
        { opacity: 1, ease: "none", duration: 0.15 },
        1.05
      );
  }
  destroyTimeline() {
    this.masterTimeline?.kill(), (this.masterTimeline = null);
  }
}
customElements.define("c-homepage-timeline", oe(ve, "HomepageTimeline"));
export { ve as default };
