import { S as qe } from "./Scroll.Bil0v7NL.js";
import "./MenuMobile.mSJs35Qy.js";
import "./MenuDesktop.CSIRkNn7.js";
import { i as On } from "./context.BMvvpewv.js";
import "./scroll.C7dNMCy6.js";
import "./index.DtsRjIc2.js";
import "./index.BSdFiPHn.js";
import "./component-manager.modern.i7ixt_80.js";
import "./index.CsVyfrhj.js";
const _n = (o) =>
  o
    .split(/(?=[A-Z])/)
    .join("-")
    .toLowerCase();
function xe() {
  return (
    (xe = Object.assign
      ? Object.assign.bind()
      : function (o) {
          for (var e = 1; e < arguments.length; e++) {
            var t = arguments[e];
            for (var n in t)
              Object.prototype.hasOwnProperty.call(t, n) && (o[n] = t[n]);
          }
          return o;
        }),
    xe.apply(this, arguments)
  );
}
const At = (o) =>
  String(o)
    .split(".")
    .map((e) => String(parseInt(e || "0", 10)))
    .concat(["0", "0"])
    .slice(0, 3)
    .join(".");
let Ze = class {
  constructor() {
    (this.isSwupPlugin = !0),
      (this.swup = void 0),
      (this.version = void 0),
      (this.requires = {}),
      (this.handlersToUnregister = []);
  }
  mount() {}
  unmount() {
    this.handlersToUnregister.forEach((e) => e()),
      (this.handlersToUnregister = []);
  }
  _beforeMount() {
    if (!this.name)
      throw new Error(
        "You must define a name of plugin when creating a class."
      );
  }
  _afterUnmount() {}
  _checkRequirements() {
    return (
      typeof this.requires != "object" ||
        Object.entries(this.requires).forEach(([e, t]) => {
          if (
            !(function (n, s, r) {
              const a = (function (i, l) {
                var c;
                if (i === "swup") return (c = l.version) != null ? c : "";
                {
                  var h;
                  const u = l.findPlugin(i);
                  return (h = u?.version) != null ? h : "";
                }
              })(n, r);
              return (
                !!a &&
                ((i, l) =>
                  l.every((c) => {
                    const [, h, u] = c.match(/^([\D]+)?(.*)$/) || [];
                    var f, p;
                    return ((d, g) => {
                      const y = {
                        "": (v) => v === 0,
                        ">": (v) => v > 0,
                        ">=": (v) => v >= 0,
                        "<": (v) => v < 0,
                        "<=": (v) => v <= 0,
                      };
                      return (y[g] || y[""])(d);
                    })(
                      ((p = u),
                      (f = At((f = i))),
                      (p = At(p)),
                      f.localeCompare(p, void 0, { numeric: !0 })),
                      h || ">="
                    );
                  }))(a, s)
              );
            })(e, (t = Array.isArray(t) ? t : [t]), this.swup)
          ) {
            const n = `${e} ${t.join(", ")}`;
            throw new Error(
              `Plugin version mismatch: ${this.name} requires ${n}`
            );
          }
        }),
      !0
    );
  }
  on(e, t, n = {}) {
    var s;
    t =
      !(s = t).name.startsWith("bound ") || s.hasOwnProperty("prototype")
        ? t.bind(this)
        : t;
    const r = this.swup.hooks.on(e, t, n);
    return this.handlersToUnregister.push(r), r;
  }
  once(e, t, n = {}) {
    return this.on(e, t, xe({}, n, { once: !0 }));
  }
  before(e, t, n = {}) {
    return this.on(e, t, xe({}, n, { before: !0 }));
  }
  replace(e, t, n = {}) {
    return this.on(e, t, xe({}, n, { replace: !0 }));
  }
  off(e, t) {
    return this.swup.hooks.off(e, t);
  }
};
function Ne() {
  return (
    (Ne = Object.assign
      ? Object.assign.bind()
      : function (o) {
          for (var e = 1; e < arguments.length; e++) {
            var t = arguments[e];
            for (var n in t) ({}.hasOwnProperty.call(t, n) && (o[n] = t[n]));
          }
          return o;
        }),
    Ne.apply(null, arguments)
  );
}
function Pt(o) {
  return o.localName !== "title" && !o.matches("[data-swup-theme]");
}
function xt(o, e) {
  return o.outerHTML === e.outerHTML;
}
function Lt(o, e = []) {
  const t = Array.from(o.attributes);
  return e.length
    ? t.filter(({ name: n }) =>
        e.some((s) => (s instanceof RegExp ? s.test(n) : n === s))
      )
    : t;
}
function Rn(o) {
  return o.matches("link[rel=stylesheet][href]");
}
let Mn = class extends Ze {
  constructor(e = {}) {
    var t;
    super(),
      (t = this),
      (this.name = "SwupHeadPlugin"),
      (this.requires = { swup: ">=4.6" }),
      (this.defaults = {
        persistTags: !1,
        persistAssets: !1,
        awaitAssets: !1,
        attributes: ["lang", "dir"],
        timeout: 3e3,
      }),
      (this.options = void 0),
      (this.updateHead = async function (n, { page: {} }) {
        const { awaitAssets: s, attributes: r, timeout: a } = t.options,
          i = n.to.document,
          { removed: l, added: c } = (function (
            h,
            u,
            { shouldPersist: f = () => !1 } = {}
          ) {
            const p = Array.from(h.children),
              d = Array.from(u.children),
              g =
                ((y = p),
                d.reduce(
                  (w, b, C) => (
                    y.some((L) => xt(b, L)) || w.push({ el: b, index: C }), w
                  ),
                  []
                ));
            var y;
            const v = (function (w, b) {
              return w.reduce(
                (C, L) => (b.some((A) => xt(L, A)) || C.push({ el: L }), C),
                []
              );
            })(p, d);
            v.reverse()
              .filter(({ el: w }) => Pt(w))
              .filter(({ el: w }) => !f(w))
              .forEach(({ el: w }) => h.removeChild(w));
            const $ = g
              .filter(({ el: w }) => Pt(w))
              .map((w) => {
                let b = w.el.cloneNode(!0);
                return (
                  h.insertBefore(b, h.children[(w.index || 0) + 1] || null),
                  Ne({}, w, { el: b })
                );
              });
            return {
              removed: v.map(({ el: w }) => w),
              added: $.map(({ el: w }) => w),
            };
          })(document.head, i.head, {
            shouldPersist: (h) => t.isPersistentTag(h),
          });
        if (
          (t.swup.log(`Removed ${l.length} / added ${c.length} tags in head`),
          r != null &&
            r.length &&
            (function (h, u, f = []) {
              const p = new Set();
              for (const { name: d, value: g } of Lt(u, f))
                h.setAttribute(d, g), p.add(d);
              for (const { name: d } of Lt(h, f))
                p.has(d) || h.removeAttribute(d);
            })(document.documentElement, i.documentElement, r),
          s)
        ) {
          const h = (function (u, f = 0) {
            return u.filter(Rn).map((p) =>
              (function (d, g = 0) {
                let y;
                const v = ($) => {
                  d.sheet ? $() : (y = setTimeout(() => v($), 10));
                };
                return new Promise(($) => {
                  v(() => $(d)),
                    g > 0 &&
                      setTimeout(() => {
                        y && clearTimeout(y), $(d);
                      }, g);
                });
              })(p, f)
            );
          })(c, a);
          h.length &&
            (t.swup.log(`Waiting for ${h.length} assets to load`),
            await Promise.all(h));
        }
      }),
      (this.options = Ne({}, this.defaults, e)),
      this.options.persistAssets &&
        !this.options.persistTags &&
        (this.options.persistTags = "link[rel=stylesheet], script[src], style");
  }
  mount() {
    this.before("content:replace", this.updateHead);
  }
  isPersistentTag(e) {
    const { persistTags: t } = this.options;
    return typeof t == "function"
      ? t(e)
      : typeof t == "string" && t.length > 0
      ? e.matches(t)
      : !!t;
  }
};
const Ke = new WeakMap();
function Qe(o, e, t, n) {
  if (!o && !Ke.has(e)) return !1;
  const s = Ke.get(e) ?? new WeakMap();
  Ke.set(e, s);
  const r = s.get(t) ?? new Set();
  s.set(t, r);
  const a = r.has(n);
  return o ? r.add(n) : r.delete(n), a && o;
}
function In(o, e) {
  let t = o.target;
  if (
    (t instanceof Text && (t = t.parentElement),
    t instanceof Element && o.currentTarget instanceof Element)
  ) {
    const n = t.closest(e);
    if (n && o.currentTarget.contains(n)) return n;
  }
}
function Dn(o, e, t, n = {}) {
  const { signal: s, base: r = document } = n;
  if (s?.aborted) return;
  const { once: a, ...i } = n,
    l = r instanceof Document ? r.documentElement : r,
    c = !!(typeof n == "object" ? n.capture : n),
    h = (p) => {
      const d = In(p, String(o));
      if (d) {
        const g = Object.assign(p, { delegateTarget: d });
        t.call(l, g), a && (l.removeEventListener(e, h, i), Qe(!1, l, t, u));
      }
    },
    u = JSON.stringify({ selector: o, type: e, capture: c });
  Qe(!0, l, t, u) || l.addEventListener(e, h, i),
    s?.addEventListener("abort", () => {
      Qe(!1, l, t, u);
    });
}
function Hn(o) {
  for (var e = [], t = 0; t < o.length; ) {
    var n = o[t];
    if (n === "*" || n === "+" || n === "?") {
      e.push({ type: "MODIFIER", index: t, value: o[t++] });
      continue;
    }
    if (n === "\\") {
      e.push({ type: "ESCAPED_CHAR", index: t++, value: o[t++] });
      continue;
    }
    if (n === "{") {
      e.push({ type: "OPEN", index: t, value: o[t++] });
      continue;
    }
    if (n === "}") {
      e.push({ type: "CLOSE", index: t, value: o[t++] });
      continue;
    }
    if (n === ":") {
      for (var s = "", r = t + 1; r < o.length; ) {
        var a = o.charCodeAt(r);
        if (
          (a >= 48 && a <= 57) ||
          (a >= 65 && a <= 90) ||
          (a >= 97 && a <= 122) ||
          a === 95
        ) {
          s += o[r++];
          continue;
        }
        break;
      }
      if (!s) throw new TypeError("Missing parameter name at ".concat(t));
      e.push({ type: "NAME", index: t, value: s }), (t = r);
      continue;
    }
    if (n === "(") {
      var i = 1,
        l = "",
        r = t + 1;
      if (o[r] === "?")
        throw new TypeError('Pattern cannot start with "?" at '.concat(r));
      for (; r < o.length; ) {
        if (o[r] === "\\") {
          l += o[r++] + o[r++];
          continue;
        }
        if (o[r] === ")") {
          if ((i--, i === 0)) {
            r++;
            break;
          }
        } else if (o[r] === "(" && (i++, o[r + 1] !== "?"))
          throw new TypeError("Capturing groups are not allowed at ".concat(r));
        l += o[r++];
      }
      if (i) throw new TypeError("Unbalanced pattern at ".concat(t));
      if (!l) throw new TypeError("Missing pattern at ".concat(t));
      e.push({ type: "PATTERN", index: t, value: l }), (t = r);
      continue;
    }
    e.push({ type: "CHAR", index: t, value: o[t++] });
  }
  return e.push({ type: "END", index: t, value: "" }), e;
}
function Vn(o, e) {
  e === void 0 && (e = {});
  for (
    var t = Hn(o),
      n = e.prefixes,
      s = n === void 0 ? "./" : n,
      r = e.delimiter,
      a = r === void 0 ? "/#?" : r,
      i = [],
      l = 0,
      c = 0,
      h = "",
      u = function (q) {
        if (c < t.length && t[c].type === q) return t[c++].value;
      },
      f = function (q) {
        var _ = u(q);
        if (_ !== void 0) return _;
        var M = t[c],
          K = M.type,
          z = M.index;
        throw new TypeError(
          "Unexpected ".concat(K, " at ").concat(z, ", expected ").concat(q)
        );
      },
      p = function () {
        for (var q = "", _; (_ = u("CHAR") || u("ESCAPED_CHAR")); ) q += _;
        return q;
      },
      d = function (q) {
        for (var _ = 0, M = a; _ < M.length; _++) {
          var K = M[_];
          if (q.indexOf(K) > -1) return !0;
        }
        return !1;
      },
      g = function (q) {
        var _ = i[i.length - 1],
          M = q || (_ && typeof _ == "string" ? _ : "");
        if (_ && !M)
          throw new TypeError(
            'Must have text between two parameters, missing text after "'.concat(
              _.name,
              '"'
            )
          );
        return !M || d(M)
          ? "[^".concat(he(a), "]+?")
          : "(?:(?!".concat(he(M), ")[^").concat(he(a), "])+?");
      };
    c < t.length;

  ) {
    var y = u("CHAR"),
      v = u("NAME"),
      $ = u("PATTERN");
    if (v || $) {
      var w = y || "";
      s.indexOf(w) === -1 && ((h += w), (w = "")),
        h && (i.push(h), (h = "")),
        i.push({
          name: v || l++,
          prefix: w,
          suffix: "",
          pattern: $ || g(w),
          modifier: u("MODIFIER") || "",
        });
      continue;
    }
    var b = y || u("ESCAPED_CHAR");
    if (b) {
      h += b;
      continue;
    }
    h && (i.push(h), (h = ""));
    var C = u("OPEN");
    if (C) {
      var w = p(),
        L = u("NAME") || "",
        A = u("PATTERN") || "",
        D = p();
      f("CLOSE"),
        i.push({
          name: L || (A ? l++ : ""),
          pattern: L && !A ? g(w) : A,
          prefix: w,
          suffix: D,
          modifier: u("MODIFIER") || "",
        });
      continue;
    }
    f("END");
  }
  return i;
}
function qn(o, e) {
  var t = [],
    n = Gt(o, t, e);
  return Un(n, t, e);
}
function Un(o, e, t) {
  t === void 0 && (t = {});
  var n = t.decode,
    s =
      n === void 0
        ? function (r) {
            return r;
          }
        : n;
  return function (r) {
    var a = o.exec(r);
    if (!a) return !1;
    for (
      var i = a[0],
        l = a.index,
        c = Object.create(null),
        h = function (f) {
          if (a[f] === void 0) return "continue";
          var p = e[f - 1];
          p.modifier === "*" || p.modifier === "+"
            ? (c[p.name] = a[f].split(p.prefix + p.suffix).map(function (d) {
                return s(d, p);
              }))
            : (c[p.name] = s(a[f], p));
        },
        u = 1;
      u < a.length;
      u++
    )
      h(u);
    return { path: i, index: l, params: c };
  };
}
function he(o) {
  return o.replace(/([.+*?=^!:${}()[\]|/\\])/g, "\\$1");
}
function zt(o) {
  return o && o.sensitive ? "" : "i";
}
function Bn(o, e) {
  if (!e) return o;
  for (var t = /\((?:\?<(.*?)>)?(?!\?)/g, n = 0, s = t.exec(o.source); s; )
    e.push({
      name: s[1] || n++,
      prefix: "",
      suffix: "",
      modifier: "",
      pattern: "",
    }),
      (s = t.exec(o.source));
  return o;
}
function jn(o, e, t) {
  var n = o.map(function (s) {
    return Gt(s, e, t).source;
  });
  return new RegExp("(?:".concat(n.join("|"), ")"), zt(t));
}
function Nn(o, e, t) {
  return Fn(Vn(o, t), e, t);
}
function Fn(o, e, t) {
  t === void 0 && (t = {});
  for (
    var n = t.strict,
      s = n === void 0 ? !1 : n,
      r = t.start,
      a = r === void 0 ? !0 : r,
      i = t.end,
      l = i === void 0 ? !0 : i,
      c = t.encode,
      h =
        c === void 0
          ? function (_) {
              return _;
            }
          : c,
      u = t.delimiter,
      f = u === void 0 ? "/#?" : u,
      p = t.endsWith,
      d = p === void 0 ? "" : p,
      g = "[".concat(he(d), "]|$"),
      y = "[".concat(he(f), "]"),
      v = a ? "^" : "",
      $ = 0,
      w = o;
    $ < w.length;
    $++
  ) {
    var b = w[$];
    if (typeof b == "string") v += he(h(b));
    else {
      var C = he(h(b.prefix)),
        L = he(h(b.suffix));
      if (b.pattern)
        if ((e && e.push(b), C || L))
          if (b.modifier === "+" || b.modifier === "*") {
            var A = b.modifier === "*" ? "?" : "";
            v += "(?:"
              .concat(C, "((?:")
              .concat(b.pattern, ")(?:")
              .concat(L)
              .concat(C, "(?:")
              .concat(b.pattern, "))*)")
              .concat(L, ")")
              .concat(A);
          } else
            v += "(?:"
              .concat(C, "(")
              .concat(b.pattern, ")")
              .concat(L, ")")
              .concat(b.modifier);
        else {
          if (b.modifier === "+" || b.modifier === "*")
            throw new TypeError(
              'Can not repeat "'.concat(b.name, '" without a prefix and suffix')
            );
          v += "(".concat(b.pattern, ")").concat(b.modifier);
        }
      else v += "(?:".concat(C).concat(L, ")").concat(b.modifier);
    }
  }
  if (l)
    s || (v += "".concat(y, "?")),
      (v += t.endsWith ? "(?=".concat(g, ")") : "$");
  else {
    var D = o[o.length - 1],
      q = typeof D == "string" ? y.indexOf(D[D.length - 1]) > -1 : D === void 0;
    s || (v += "(?:".concat(y, "(?=").concat(g, "))?")),
      q || (v += "(?=".concat(y, "|").concat(g, ")"));
  }
  return new RegExp(v, zt(t));
}
function Gt(o, e, t) {
  return o instanceof RegExp
    ? Bn(o, e)
    : Array.isArray(o)
    ? jn(o, e, t)
    : Nn(o, e, t);
}
function U() {
  return (
    (U = Object.assign
      ? Object.assign.bind()
      : function (o) {
          for (var e = 1; e < arguments.length; e++) {
            var t = arguments[e];
            for (var n in t) ({}.hasOwnProperty.call(t, n) && (o[n] = t[n]));
          }
          return o;
        }),
    U.apply(null, arguments)
  );
}
const pt = (o, e) =>
    String(o)
      .toLowerCase()
      .replace(/[\s/_.]+/g, "-")
      .replace(/[^\w-]+/g, "")
      .replace(/--+/g, "-")
      .replace(/^-+|-+$/g, "") ||
    e ||
    "",
  we = ({ hash: o } = {}) =>
    window.location.pathname +
    window.location.search +
    (o ? window.location.hash : ""),
  Wn = (o, e = {}) => {
    const t = U(
      {
        url: (o = o || we({ hash: !0 })),
        random: Math.random(),
        source: "swup",
      },
      e
    );
    window.history.pushState(t, "", o);
  },
  Le = (o = null, e = {}) => {
    o = o || we({ hash: !0 });
    const t = U(
      {},
      window.history.state || {},
      { url: o, random: Math.random(), source: "swup" },
      e
    );
    window.history.replaceState(t, "", o);
  },
  Yn = (o, e, t, n) => {
    const s = new AbortController();
    return (
      (n = U({}, n, { signal: s.signal })),
      Dn(o, e, t, n),
      { destroy: () => s.abort() }
    );
  };
let V = class Ue extends URL {
  constructor(e, t = document.baseURI) {
    super(e.toString(), t), Object.setPrototypeOf(this, Ue.prototype);
  }
  get url() {
    return this.pathname + this.search;
  }
  static fromElement(e) {
    const t = e.getAttribute("href") || e.getAttribute("xlink:href") || "";
    return new Ue(t);
  }
  static fromUrl(e) {
    return new Ue(e);
  }
};
const Tt = (o, e) => {
  Array.isArray(o) && !o.length && (o = "");
  try {
    return qn(o, e);
  } catch (t) {
    throw new Error(`[swup] Error parsing path "${String(o)}":
${String(t)}`);
  }
};
let Ie = class extends Error {
  constructor(e, t) {
    super(e),
      (this.url = void 0),
      (this.status = void 0),
      (this.aborted = void 0),
      (this.timedOut = void 0),
      (this.name = "FetchError"),
      (this.url = t.url),
      (this.status = t.status),
      (this.aborted = t.aborted || !1),
      (this.timedOut = t.timedOut || !1);
  }
};
async function zn(o, e = {}) {
  var t;
  o = V.fromUrl(o).url;
  const { visit: n = this.visit } = e,
    s = U({}, this.options.requestHeaders, e.headers),
    r = (t = e.timeout) != null ? t : this.options.timeout,
    a = new AbortController(),
    { signal: i } = a;
  e = U({}, e, { headers: s, signal: i });
  let l,
    c = !1,
    h = null;
  r &&
    r > 0 &&
    (h = setTimeout(() => {
      (c = !0), a.abort("timeout");
    }, r));
  try {
    (l = await this.hooks.call(
      "fetch:request",
      n,
      { url: o, options: e },
      (y, { url: v, options: $ }) => fetch(v, $)
    )),
      h && clearTimeout(h);
  } catch (y) {
    throw c
      ? (this.hooks.call("fetch:timeout", n, { url: o }),
        new Ie(`Request timed out: ${o}`, { url: o, timedOut: c }))
      : y?.name === "AbortError" || i.aborted
      ? new Ie(`Request aborted: ${o}`, { url: o, aborted: !0 })
      : y;
  }
  const { status: u, url: f } = l,
    p = await l.text();
  if (u === 500)
    throw (
      (this.hooks.call("fetch:error", n, { status: u, response: l, url: f }),
      new Ie(`Server error: ${f}`, { status: u, url: f }))
    );
  if (!p) throw new Ie(`Empty response: ${f}`, { status: u, url: f });
  const { url: d } = V.fromUrl(f),
    g = { url: d, html: p };
  return (
    !n.cache.write ||
      (e.method && e.method !== "GET") ||
      o !== d ||
      this.cache.set(g.url, g),
    g
  );
}
let Gn = class {
  constructor(e) {
    (this.swup = void 0), (this.pages = new Map()), (this.swup = e);
  }
  get size() {
    return this.pages.size;
  }
  get all() {
    const e = new Map();
    return (
      this.pages.forEach((t, n) => {
        e.set(n, U({}, t));
      }),
      e
    );
  }
  has(e) {
    return this.pages.has(this.resolve(e));
  }
  get(e) {
    const t = this.pages.get(this.resolve(e));
    return t && U({}, t);
  }
  set(e, t) {
    (t = U({}, t, { url: (e = this.resolve(e)) })),
      this.pages.set(e, t),
      this.swup.hooks.callSync("cache:set", void 0, { page: t });
  }
  update(e, t) {
    e = this.resolve(e);
    const n = U({}, this.get(e), t, { url: e });
    this.pages.set(e, n);
  }
  delete(e) {
    this.pages.delete(this.resolve(e));
  }
  clear() {
    this.pages.clear(), this.swup.hooks.callSync("cache:clear", void 0, void 0);
  }
  prune(e) {
    this.pages.forEach((t, n) => {
      e(n, t) && this.delete(n);
    });
  }
  resolve(e) {
    const { url: t } = V.fromUrl(e);
    return this.swup.resolveUrl(t);
  }
};
const at = (o, e = document) => e.querySelector(o),
  mt = (o, e = document) => Array.from(e.querySelectorAll(o)),
  Zt = () =>
    new Promise((o) => {
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          o();
        });
      });
    });
function Jt(o) {
  return (
    !!o &&
    (typeof o == "object" || typeof o == "function") &&
    typeof o.then == "function"
  );
}
function Zn(o, e = []) {
  return new Promise((t, n) => {
    const s = o(...e);
    Jt(s) ? s.then(t, n) : t(s);
  });
}
function Jn(o) {
  var e;
  (e = o = o || document.body) == null || e.getBoundingClientRect();
}
function Ot(o, e) {
  const t = o?.closest(`[${e}]`);
  return t != null && t.hasAttribute(e) ? t?.getAttribute(e) || !0 : void 0;
}
let Xn = class {
    constructor(e) {
      (this.swup = void 0),
        (this.swupClasses = [
          "to-",
          "is-changing",
          "is-rendering",
          "is-popstate",
          "is-animating",
          "is-leaving",
        ]),
        (this.swup = e);
    }
    get selectors() {
      const { scope: e } = this.swup.visit.animation;
      return e === "containers"
        ? this.swup.visit.containers
        : e === "html"
        ? ["html"]
        : Array.isArray(e)
        ? e
        : [];
    }
    get selector() {
      return this.selectors.join(",");
    }
    get targets() {
      return this.selector.trim() ? mt(this.selector) : [];
    }
    add(...e) {
      this.targets.forEach((t) => t.classList.add(...e));
    }
    remove(...e) {
      this.targets.forEach((t) => t.classList.remove(...e));
    }
    clear() {
      this.targets.forEach((e) => {
        const t = e.className.split(" ").filter((n) => this.isSwupClass(n));
        e.classList.remove(...t);
      });
    }
    isSwupClass(e) {
      return this.swupClasses.some((t) => e.startsWith(t));
    }
  },
  Xt = class {
    constructor(e, t) {
      (this.id = void 0),
        (this.state = void 0),
        (this.from = void 0),
        (this.to = void 0),
        (this.containers = void 0),
        (this.animation = void 0),
        (this.trigger = void 0),
        (this.cache = void 0),
        (this.history = void 0),
        (this.scroll = void 0),
        (this.meta = void 0);
      const { to: n, from: s, hash: r, el: a, event: i } = t;
      (this.id = Math.random()),
        (this.state = 1),
        (this.from = { url: s ?? e.location.url, hash: e.location.hash }),
        (this.to = { url: n, hash: r }),
        (this.containers = e.options.containers),
        (this.animation = {
          animate: !0,
          wait: !1,
          name: void 0,
          native: e.options.native,
          scope: e.options.animationScope,
          selector: e.options.animationSelector,
        }),
        (this.trigger = { el: a, event: i }),
        (this.cache = { read: e.options.cache, write: e.options.cache }),
        (this.history = { action: "push", popstate: !1, direction: void 0 }),
        (this.scroll = { reset: !0, target: void 0 }),
        (this.meta = {});
    }
    advance(e) {
      this.state < e && (this.state = e);
    }
    abort() {
      this.state = 8;
    }
    get done() {
      return this.state >= 7;
    }
  };
function Kn(o) {
  return new Xt(this, o);
}
let Qn = class {
  constructor(e) {
    (this.swup = void 0),
      (this.registry = new Map()),
      (this.hooks = [
        "animation:out:start",
        "animation:out:await",
        "animation:out:end",
        "animation:in:start",
        "animation:in:await",
        "animation:in:end",
        "animation:skip",
        "cache:clear",
        "cache:set",
        "content:replace",
        "content:scroll",
        "enable",
        "disable",
        "fetch:request",
        "fetch:error",
        "fetch:timeout",
        "history:popstate",
        "link:click",
        "link:self",
        "link:anchor",
        "link:newtab",
        "page:load",
        "page:view",
        "scroll:top",
        "scroll:anchor",
        "visit:start",
        "visit:transition",
        "visit:abort",
        "visit:end",
      ]),
      (this.swup = e),
      this.init();
  }
  init() {
    this.hooks.forEach((e) => this.create(e));
  }
  create(e) {
    this.registry.has(e) || this.registry.set(e, new Map());
  }
  exists(e) {
    return this.registry.has(e);
  }
  get(e) {
    const t = this.registry.get(e);
    if (t) return t;
    console.error(`Unknown hook '${e}'`);
  }
  clear() {
    this.registry.forEach((e) => e.clear());
  }
  on(e, t, n = {}) {
    const s = this.get(e);
    if (!s) return console.warn(`Hook '${e}' not found.`), () => {};
    const r = U({}, n, { id: s.size + 1, hook: e, handler: t });
    return s.set(t, r), () => this.off(e, t);
  }
  before(e, t, n = {}) {
    return this.on(e, t, U({}, n, { before: !0 }));
  }
  replace(e, t, n = {}) {
    return this.on(e, t, U({}, n, { replace: !0 }));
  }
  once(e, t, n = {}) {
    return this.on(e, t, U({}, n, { once: !0 }));
  }
  off(e, t) {
    const n = this.get(e);
    n && t
      ? n.delete(t) || console.warn(`Handler for hook '${e}' not found.`)
      : n && n.clear();
  }
  async call(e, t, n, s) {
    const [r, a, i] = this.parseCallArgs(e, t, n, s),
      { before: l, handler: c, after: h } = this.getHandlers(e, i);
    await this.run(l, r, a);
    const [u] = await this.run(c, r, a, !0);
    return await this.run(h, r, a), this.dispatchDomEvent(e, r, a), u;
  }
  callSync(e, t, n, s) {
    const [r, a, i] = this.parseCallArgs(e, t, n, s),
      { before: l, handler: c, after: h } = this.getHandlers(e, i);
    this.runSync(l, r, a);
    const [u] = this.runSync(c, r, a, !0);
    return this.runSync(h, r, a), this.dispatchDomEvent(e, r, a), u;
  }
  parseCallArgs(e, t, n, s) {
    return t instanceof Xt || (typeof t != "object" && typeof n != "function")
      ? [t, n, s]
      : [void 0, t, n];
  }
  async run(e, t = this.swup.visit, n, s = !1) {
    const r = [];
    for (const { hook: a, handler: i, defaultHandler: l, once: c } of e)
      if (t == null || !t.done) {
        c && this.off(a, i);
        try {
          const h = await Zn(i, [t, n, l]);
          r.push(h);
        } catch (h) {
          if (s) throw h;
          console.error(`Error in hook '${a}':`, h);
        }
      }
    return r;
  }
  runSync(e, t = this.swup.visit, n, s = !1) {
    const r = [];
    for (const { hook: a, handler: i, defaultHandler: l, once: c } of e)
      if (t == null || !t.done) {
        c && this.off(a, i);
        try {
          const h = i(t, n, l);
          r.push(h),
            Jt(h) &&
              console.warn(
                `Swup will not await Promises in handler for synchronous hook '${a}'.`
              );
        } catch (h) {
          if (s) throw h;
          console.error(`Error in hook '${a}':`, h);
        }
      }
    return r;
  }
  getHandlers(e, t) {
    const n = this.get(e);
    if (!n)
      return { found: !1, before: [], handler: [], after: [], replaced: !1 };
    const s = Array.from(n.values()),
      r = this.sortRegistrations,
      a = s.filter(({ before: u, replace: f }) => u && !f).sort(r),
      i = s
        .filter(({ replace: u }) => u)
        .filter((u) => !0)
        .sort(r),
      l = s.filter(({ before: u, replace: f }) => !u && !f).sort(r),
      c = i.length > 0;
    let h = [];
    if (t && ((h = [{ id: 0, hook: e, handler: t }]), c)) {
      const u = i.length - 1,
        { handler: f, once: p } = i[u],
        d = (g) => {
          const y = i[g - 1];
          return y ? (v, $) => y.handler(v, $, d(g - 1)) : t;
        };
      h = [{ id: 0, hook: e, once: p, handler: f, defaultHandler: d(u) }];
    }
    return { found: !0, before: a, handler: h, after: l, replaced: c };
  }
  sortRegistrations(e, t) {
    var n, s;
    return (
      ((n = e.priority) != null ? n : 0) - ((s = t.priority) != null ? s : 0) ||
      e.id - t.id ||
      0
    );
  }
  dispatchDomEvent(e, t, n) {
    if (t != null && t.done) return;
    const s = { hook: e, args: n, visit: t || this.swup.visit };
    document.dispatchEvent(
      new CustomEvent("swup:any", { detail: s, bubbles: !0 })
    ),
      document.dispatchEvent(
        new CustomEvent(`swup:${e}`, { detail: s, bubbles: !0 })
      );
  }
  parseName(e) {
    const [t, ...n] = e.split(".");
    return [t, n.reduce((s, r) => U({}, s, { [r]: !0 }), {})];
  }
};
const eo = (o) => {
    if ((o && o.charAt(0) === "#" && (o = o.substring(1)), !o)) return null;
    const e = decodeURIComponent(o);
    let t =
      document.getElementById(o) ||
      document.getElementById(e) ||
      at(`a[name='${CSS.escape(o)}']`) ||
      at(`a[name='${CSS.escape(e)}']`);
    return t || o !== "top" || (t = document.body), t;
  },
  De = "transition",
  et = "animation";
async function to({ selector: o, elements: e }) {
  if (o === !1 && !e) return;
  let t = [];
  if (e) t = Array.from(e);
  else if (o && ((t = mt(o, document.body)), !t.length))
    return void console.warn(
      `[swup] No elements found matching animationSelector \`${o}\``
    );
  const n = t.map((s) =>
    (function (r) {
      const {
        type: a,
        timeout: i,
        propCount: l,
      } = (function (c) {
        const h = window.getComputedStyle(c),
          u = He(h, `${De}Delay`),
          f = He(h, `${De}Duration`),
          p = _t(u, f),
          d = He(h, `${et}Delay`),
          g = He(h, `${et}Duration`),
          y = _t(d, g),
          v = Math.max(p, y),
          $ = v > 0 ? (p > y ? De : et) : null;
        return {
          type: $,
          timeout: v,
          propCount: $ ? ($ === De ? f.length : g.length) : 0,
        };
      })(r);
      return (
        !(!a || !i) &&
        new Promise((c) => {
          const h = `${a}end`,
            u = performance.now();
          let f = 0;
          const p = () => {
              r.removeEventListener(h, d), c();
            },
            d = (g) => {
              g.target === r &&
                ((performance.now() - u) / 1e3 < g.elapsedTime ||
                  (++f >= l && p()));
            };
          setTimeout(() => {
            f < l && p();
          }, i + 1),
            r.addEventListener(h, d);
        })
      );
    })(s)
  );
  n.filter(Boolean).length > 0
    ? await Promise.all(n)
    : o &&
      console.warn(
        `[swup] No CSS animation duration defined on elements matching \`${o}\``
      );
}
function He(o, e) {
  return (o[e] || "").split(", ");
}
function _t(o, e) {
  for (; o.length < e.length; ) o = o.concat(o);
  return Math.max(...e.map((t, n) => Rt(t) + Rt(o[n])));
}
function Rt(o) {
  return 1e3 * parseFloat(o);
}
function no(o, e = {}, t = {}) {
  if (typeof o != "string")
    throw new Error("swup.navigate() requires a URL parameter");
  if (this.shouldIgnoreVisit(o, { el: t.el, event: t.event }))
    return void window.location.assign(o);
  const { url: n, hash: s } = V.fromUrl(o),
    r = this.createVisit(U({}, t, { to: n, hash: s }));
  this.performNavigation(r, e);
}
async function oo(o, e = {}) {
  if (this.navigating) {
    if (this.visit.state >= 6)
      return (
        (o.state = 2),
        void (this.onVisitEnd = () => this.performNavigation(o, e))
      );
    await this.hooks.call("visit:abort", this.visit, void 0),
      delete this.visit.to.document,
      (this.visit.state = 8);
  }
  (this.navigating = !0), (this.visit = o);
  const { el: t } = o.trigger;
  (e.referrer = e.referrer || this.location.url),
    e.animate === !1 && (o.animation.animate = !1),
    o.animation.animate || this.classes.clear();
  const n = e.history || Ot(t, "data-swup-history");
  typeof n == "string" &&
    ["push", "replace"].includes(n) &&
    (o.history.action = n);
  const s = e.animation || Ot(t, "data-swup-animation");
  var r, a;
  typeof s == "string" && (o.animation.name = s),
    (o.meta = e.meta || {}),
    typeof e.cache == "object"
      ? ((o.cache.read = (r = e.cache.read) != null ? r : o.cache.read),
        (o.cache.write = (a = e.cache.write) != null ? a : o.cache.write))
      : e.cache !== void 0 && (o.cache = { read: !!e.cache, write: !!e.cache }),
    delete e.cache;
  try {
    await this.hooks.call("visit:start", o, void 0), (o.state = 3);
    const i = this.hooks.call("page:load", o, { options: e }, async (c, h) => {
      let u;
      return (
        c.cache.read && (u = this.cache.get(c.to.url)),
        (h.page = u || (await this.fetchPage(c.to.url, h.options))),
        (h.cache = !!u),
        h.page
      );
    });
    i.then(({ html: c }) => {
      o.advance(5),
        (o.to.html = c),
        (o.to.document = new DOMParser().parseFromString(c, "text/html"));
    });
    const l = o.to.url + o.to.hash;
    if (
      (o.history.popstate ||
        (o.history.action === "replace" || o.to.url === this.location.url
          ? Le(l)
          : (this.currentHistoryIndex++,
            Wn(l, { index: this.currentHistoryIndex }))),
      (this.location = V.fromUrl(l)),
      o.history.popstate && this.classes.add("is-popstate"),
      o.animation.name && this.classes.add(`to-${pt(o.animation.name)}`),
      o.animation.wait && (await i),
      o.done ||
        (await this.hooks.call("visit:transition", o, void 0, async () => {
          if (!o.animation.animate)
            return (
              await this.hooks.call("animation:skip", void 0),
              void (await this.renderPage(o, await i))
            );
          o.advance(4),
            await this.animatePageOut(o),
            o.animation.native && document.startViewTransition
              ? await document.startViewTransition(
                  async () => await this.renderPage(o, await i)
                ).finished
              : await this.renderPage(o, await i),
            await this.animatePageIn(o);
        }),
        o.done))
    )
      return;
    await this.hooks.call("visit:end", o, void 0, () => this.classes.clear()),
      (o.state = 7),
      (this.navigating = !1),
      this.onVisitEnd && (this.onVisitEnd(), (this.onVisitEnd = void 0));
  } catch (i) {
    if (!i || (i != null && i.aborted)) return void (o.state = 8);
    (o.state = 9),
      console.error(i),
      (this.options.skipPopStateHandling = () => (
        window.location.assign(o.to.url + o.to.hash), !0
      )),
      window.history.back();
  } finally {
    delete o.to.document;
  }
}
const ro = async function (o) {
    await this.hooks.call("animation:out:start", o, void 0, () => {
      this.classes.add("is-changing", "is-animating", "is-leaving");
    }),
      await this.hooks.call(
        "animation:out:await",
        o,
        { skip: !1 },
        (e, { skip: t }) => {
          if (!t)
            return this.awaitAnimations({ selector: e.animation.selector });
        }
      ),
      await this.hooks.call("animation:out:end", o, void 0);
  },
  so = function (o) {
    var e;
    const t = o.to.document;
    if (!t) return !1;
    const n =
      ((e = t.querySelector("title")) == null ? void 0 : e.innerText) || "";
    document.title = n;
    const s = mt('[data-swup-persist]:not([data-swup-persist=""])'),
      r = o.containers
        .map((a) => {
          const i = document.querySelector(a),
            l = t.querySelector(a);
          return i && l
            ? (i.replaceWith(l.cloneNode(!0)), !0)
            : (i ||
                console.warn(
                  `[swup] Container missing in current document: ${a}`
                ),
              l ||
                console.warn(
                  `[swup] Container missing in incoming document: ${a}`
                ),
              !1);
        })
        .filter(Boolean);
    return (
      s.forEach((a) => {
        const i = a.getAttribute("data-swup-persist"),
          l = at(`[data-swup-persist="${i}"]`);
        l && l !== a && l.replaceWith(a);
      }),
      r.length === o.containers.length
    );
  },
  io = function (o) {
    const e = { behavior: "auto" },
      { target: t, reset: n } = o.scroll,
      s = t ?? o.to.hash;
    let r = !1;
    return (
      s &&
        (r = this.hooks.callSync(
          "scroll:anchor",
          o,
          { hash: s, options: e },
          (a, { hash: i, options: l }) => {
            const c = this.getAnchorElement(i);
            return c && c.scrollIntoView(l), !!c;
          }
        )),
      n &&
        !r &&
        (r = this.hooks.callSync(
          "scroll:top",
          o,
          { options: e },
          (a, { options: i }) => (
            window.scrollTo(U({ top: 0, left: 0 }, i)), !0
          )
        )),
      r
    );
  },
  ao = async function (o) {
    if (o.done) return;
    const e = this.hooks.call(
      "animation:in:await",
      o,
      { skip: !1 },
      (t, { skip: n }) => {
        if (!n) return this.awaitAnimations({ selector: t.animation.selector });
      }
    );
    await Zt(),
      await this.hooks.call("animation:in:start", o, void 0, () => {
        this.classes.remove("is-animating");
      }),
      await e,
      await this.hooks.call("animation:in:end", o, void 0);
  },
  lo = async function (o, e) {
    if (o.done) return;
    o.advance(6);
    const { url: t } = e;
    this.isSameResolvedUrl(we(), t) ||
      (Le(t),
      (this.location = V.fromUrl(t)),
      (o.to.url = this.location.url),
      (o.to.hash = this.location.hash)),
      await this.hooks.call("content:replace", o, { page: e }, (n, {}) => {
        if (
          (this.classes.remove("is-leaving"),
          n.animation.animate && this.classes.add("is-rendering"),
          !this.replaceContent(n))
        )
          throw new Error("[swup] Container mismatch, aborting");
        n.animation.animate &&
          (this.classes.add("is-changing", "is-animating", "is-rendering"),
          n.animation.name && this.classes.add(`to-${pt(n.animation.name)}`));
      }),
      await this.hooks.call("content:scroll", o, void 0, () =>
        this.scrollToContent(o)
      ),
      await this.hooks.call("page:view", o, {
        url: this.location.url,
        title: document.title,
      });
  },
  co = function (o) {
    var e;
    if (((e = o), !!e?.isSwupPlugin)) {
      if (((o.swup = this), !o._checkRequirements || o._checkRequirements()))
        return (
          o._beforeMount && o._beforeMount(),
          o.mount(),
          this.plugins.push(o),
          this.plugins
        );
    } else console.error("Not a swup plugin instance", o);
  };
function uo(o) {
  const e = this.findPlugin(o);
  if (e)
    return (
      e.unmount(),
      e._afterUnmount && e._afterUnmount(),
      (this.plugins = this.plugins.filter((t) => t !== e)),
      this.plugins
    );
  console.error("No such plugin", e);
}
function ho(o) {
  return this.plugins.find(
    (e) => e === o || e.name === o || e.name === `Swup${String(o)}`
  );
}
function fo(o) {
  if (typeof this.options.resolveUrl != "function")
    return (
      console.warn("[swup] options.resolveUrl expects a callback function."), o
    );
  const e = this.options.resolveUrl(o);
  return e && typeof e == "string"
    ? e.startsWith("//") || e.startsWith("http")
      ? (console.warn(
          "[swup] options.resolveUrl needs to return a relative url"
        ),
        o)
      : e
    : (console.warn("[swup] options.resolveUrl needs to return a url"), o);
}
function po(o, e) {
  return this.resolveUrl(o) === this.resolveUrl(e);
}
const mo = {
  animateHistoryBrowsing: !1,
  animationSelector: '[class*="transition-"]',
  animationScope: "html",
  cache: !0,
  containers: ["#swup"],
  hooks: {},
  ignoreVisit: (o, { el: e } = {}) =>
    !(e == null || !e.closest("[data-no-swup]")),
  linkSelector: "a[href]",
  linkToSelf: "scroll",
  native: !1,
  plugins: [],
  resolveUrl: (o) => o,
  requestHeaders: {
    "X-Requested-With": "swup",
    Accept: "text/html, application/xhtml+xml",
  },
  skipPopStateHandling: (o) => {
    var e;
    return ((e = o.state) == null ? void 0 : e.source) !== "swup";
  },
  timeout: 0,
};
let go = class {
  get currentPageUrl() {
    return this.location.url;
  }
  constructor(e = {}) {
    var t, n;
    (this.version = "4.8.2"),
      (this.options = void 0),
      (this.defaults = mo),
      (this.plugins = []),
      (this.visit = void 0),
      (this.cache = void 0),
      (this.hooks = void 0),
      (this.classes = void 0),
      (this.location = V.fromUrl(window.location.href)),
      (this.currentHistoryIndex = void 0),
      (this.clickDelegate = void 0),
      (this.navigating = !1),
      (this.onVisitEnd = void 0),
      (this.use = co),
      (this.unuse = uo),
      (this.findPlugin = ho),
      (this.log = () => {}),
      (this.navigate = no),
      (this.performNavigation = oo),
      (this.createVisit = Kn),
      (this.delegateEvent = Yn),
      (this.fetchPage = zn),
      (this.awaitAnimations = to),
      (this.renderPage = lo),
      (this.replaceContent = so),
      (this.animatePageIn = ao),
      (this.animatePageOut = ro),
      (this.scrollToContent = io),
      (this.getAnchorElement = eo),
      (this.getCurrentUrl = we),
      (this.resolveUrl = fo),
      (this.isSameResolvedUrl = po),
      (this.options = U({}, this.defaults, e)),
      (this.handleLinkClick = this.handleLinkClick.bind(this)),
      (this.handlePopState = this.handlePopState.bind(this)),
      (this.cache = new Gn(this)),
      (this.classes = new Xn(this)),
      (this.hooks = new Qn(this)),
      (this.visit = this.createVisit({ to: "" })),
      (this.currentHistoryIndex =
        (t = (n = window.history.state) == null ? void 0 : n.index) != null
          ? t
          : 1),
      this.enable();
  }
  async enable() {
    var e;
    const { linkSelector: t } = this.options;
    (this.clickDelegate = this.delegateEvent(t, "click", this.handleLinkClick)),
      window.addEventListener("popstate", this.handlePopState),
      this.options.animateHistoryBrowsing &&
        (window.history.scrollRestoration = "manual"),
      (this.options.native =
        this.options.native && !!document.startViewTransition),
      this.options.plugins.forEach((n) => this.use(n));
    for (const [n, s] of Object.entries(this.options.hooks)) {
      const [r, a] = this.hooks.parseName(n);
      this.hooks.on(r, s, a);
    }
    ((e = window.history.state) == null ? void 0 : e.source) !== "swup" &&
      Le(null, { index: this.currentHistoryIndex }),
      await Zt(),
      await this.hooks.call("enable", void 0, void 0, () => {
        const n = document.documentElement;
        n.classList.add("swup-enabled"),
          n.classList.toggle("swup-native", this.options.native);
      });
  }
  async destroy() {
    this.clickDelegate.destroy(),
      window.removeEventListener("popstate", this.handlePopState),
      this.cache.clear(),
      this.options.plugins.forEach((e) => this.unuse(e)),
      await this.hooks.call("disable", void 0, void 0, () => {
        const e = document.documentElement;
        e.classList.remove("swup-enabled"), e.classList.remove("swup-native");
      }),
      this.hooks.clear();
  }
  shouldIgnoreVisit(e, { el: t, event: n } = {}) {
    const { origin: s, url: r, hash: a } = V.fromUrl(e);
    return (
      s !== window.location.origin ||
      !(!t || !this.triggerWillOpenNewWindow(t)) ||
      !!this.options.ignoreVisit(r + a, { el: t, event: n })
    );
  }
  handleLinkClick(e) {
    const t = e.delegateTarget,
      { href: n, url: s, hash: r } = V.fromElement(t);
    if (this.shouldIgnoreVisit(n, { el: t, event: e })) return;
    if (this.navigating && s === this.visit.to.url)
      return void e.preventDefault();
    const a = this.createVisit({ to: s, hash: r, el: t, event: e });
    e.metaKey || e.ctrlKey || e.shiftKey || e.altKey
      ? this.hooks.callSync("link:newtab", a, { href: n })
      : e.button === 0 &&
        this.hooks.callSync("link:click", a, { el: t, event: e }, () => {
          var i;
          const l = (i = a.from.url) != null ? i : "";
          e.preventDefault(),
            s && s !== l
              ? this.isSameResolvedUrl(s, l) || this.performNavigation(a)
              : r
              ? this.hooks.callSync("link:anchor", a, { hash: r }, () => {
                  Le(s + r), this.scrollToContent(a);
                })
              : this.hooks.callSync("link:self", a, void 0, () => {
                  this.options.linkToSelf === "navigate"
                    ? this.performNavigation(a)
                    : (Le(s), this.scrollToContent(a));
                });
        });
  }
  handlePopState(e) {
    var t, n, s, r;
    const a =
      (t = (n = e.state) == null ? void 0 : n.url) != null
        ? t
        : window.location.href;
    if (
      this.options.skipPopStateHandling(e) ||
      this.isSameResolvedUrl(we(), this.location.url)
    )
      return;
    const { url: i, hash: l } = V.fromUrl(a),
      c = this.createVisit({ to: i, hash: l, event: e });
    c.history.popstate = !0;
    const h = (s = (r = e.state) == null ? void 0 : r.index) != null ? s : 0;
    h &&
      h !== this.currentHistoryIndex &&
      ((c.history.direction =
        h - this.currentHistoryIndex > 0 ? "forwards" : "backwards"),
      (this.currentHistoryIndex = h)),
      (c.animation.animate = !1),
      (c.scroll.reset = !1),
      (c.scroll.target = !1),
      this.options.animateHistoryBrowsing &&
        ((c.animation.animate = !0), (c.scroll.reset = !0)),
      this.hooks.callSync("history:popstate", c, { event: e }, () => {
        this.performNavigation(c);
      });
  }
  triggerWillOpenNewWindow(e) {
    return !!e.matches('[download], [target="_blank"]');
  }
};
function Fe() {
  return (
    (Fe = Object.assign
      ? Object.assign.bind()
      : function (o) {
          for (var e = 1; e < arguments.length; e++) {
            var t = arguments[e];
            for (var n in t) ({}.hasOwnProperty.call(t, n) && (o[n] = t[n]));
          }
          return o;
        }),
    Fe.apply(null, arguments)
  );
}
function Mt() {
  return window.matchMedia("(hover: hover)").matches;
}
function Ve(o) {
  return !!o && (o instanceof HTMLAnchorElement || o instanceof SVGAElement);
}
const It = window.requestIdleCallback || ((o) => setTimeout(o, 1)),
  vo = ["preloadVisibleLinks"];
let wo = class extends Ze {
  constructor(e = {}) {
    var t;
    super(),
      (t = this),
      (this.name = "SwupPreloadPlugin"),
      (this.requires = { swup: ">=4.5" }),
      (this.defaults = {
        throttle: 5,
        preloadInitialPage: !0,
        preloadHoveredLinks: !0,
        preloadVisibleLinks: {
          enabled: !1,
          threshold: 0.2,
          delay: 500,
          containers: ["body"],
          ignore: () => !1,
        },
      }),
      (this.options = void 0),
      (this.queue = void 0),
      (this.preloadObserver = void 0),
      (this.preloadPromises = new Map()),
      (this.mouseEnterDelegate = void 0),
      (this.touchStartDelegate = void 0),
      (this.focusDelegate = void 0),
      (this.onPageLoad = (r, a, i) => {
        const { url: l } = r.to;
        return l && this.preloadPromises.has(l)
          ? this.preloadPromises.get(l)
          : i(r, a);
      }),
      (this.onMouseEnter = async function (r) {
        if (r.target !== r.delegateTarget || !Mt()) return;
        const a = r.delegateTarget;
        if (!Ve(a)) return;
        const { url: i, hash: l } = V.fromElement(a),
          c = t.swup.createVisit({ to: i, hash: l, el: a, event: r });
        t.swup.hooks.callSync("link:hover", c, { el: a, event: r }),
          t.preload(a, { priority: !0 });
      }),
      (this.onTouchStart = (r) => {
        if (Mt()) return;
        const a = r.delegateTarget;
        Ve(a) && this.preload(a, { priority: !0 });
      }),
      (this.onFocus = (r) => {
        const a = r.delegateTarget;
        Ve(a) && this.preload(a, { priority: !0 });
      });
    const { preloadVisibleLinks: n } = e,
      s = (function (r, a) {
        if (r == null) return {};
        var i = {};
        for (var l in r)
          if ({}.hasOwnProperty.call(r, l)) {
            if (a.includes(l)) continue;
            i[l] = r[l];
          }
        return i;
      })(e, vo);
    (this.options = Fe({}, this.defaults, s)),
      typeof n == "object"
        ? (this.options.preloadVisibleLinks = Fe(
            {},
            this.options.preloadVisibleLinks,
            { enabled: !0 },
            n
          ))
        : (this.options.preloadVisibleLinks.enabled = !!n),
      (this.preload = this.preload.bind(this)),
      (this.queue = (function (r = 1) {
        const a = [],
          i = [];
        let l = 0,
          c = 0;
        function h() {
          c < r &&
            l > 0 &&
            ((i.shift() || a.shift() || (() => {}))(), l--, c++);
        }
        return {
          add: function (u, f = !1) {
            if (u.__queued) {
              if (!f) return;
              {
                const p = a.indexOf(u);
                if (p >= 0) {
                  const d = a.splice(p, 1);
                  l -= d.length;
                }
              }
            }
            (u.__queued = !0), (f ? i : a).push(u), l++, l <= 1 && h();
          },
          next: function () {
            c--, h();
          },
        };
      })(this.options.throttle));
  }
  mount() {
    const e = this.swup;
    e.options.cache
      ? (e.hooks.create("page:preload"),
        e.hooks.create("link:hover"),
        (e.preload = this.preload),
        (e.preloadLinks = this.preloadLinks),
        this.replace("page:load", this.onPageLoad),
        this.preloadLinks(),
        this.on("page:view", () => this.preloadLinks()),
        this.options.preloadVisibleLinks.enabled &&
          (this.preloadVisibleLinks(),
          this.on("page:view", () => this.preloadVisibleLinks())),
        this.options.preloadHoveredLinks && this.preloadLinksOnAttention(),
        this.options.preloadInitialPage && this.preload(we()))
      : console.warn(
          "SwupPreloadPlugin: swup cache needs to be enabled for preloading"
        );
  }
  unmount() {
    var e, t, n;
    (this.swup.preload = void 0),
      (this.swup.preloadLinks = void 0),
      this.preloadPromises.clear(),
      (e = this.mouseEnterDelegate) == null || e.destroy(),
      (t = this.touchStartDelegate) == null || t.destroy(),
      (n = this.focusDelegate) == null || n.destroy(),
      this.stopPreloadingVisibleLinks();
  }
  async preload(e, t = {}) {
    var n;
    let s, r;
    const a = (n = t.priority) != null && n;
    if (Array.isArray(e)) return Promise.all(e.map((l) => this.preload(l)));
    if (Ve(e)) (r = e), ({ href: s } = V.fromElement(e));
    else {
      if (typeof e != "string") return;
      s = e;
    }
    if (!s) return;
    if (this.swup.cache.has(s)) return this.swup.cache.get(s);
    if (this.preloadPromises.has(s)) return this.preloadPromises.get(s);
    if (!this.shouldPreload(s, { el: r })) return;
    const i = new Promise((l) => {
      this.queue.add(() => {
        this.performPreload(s)
          .catch(() => {})
          .then((c) => l(c))
          .finally(() => {
            this.queue.next(), this.preloadPromises.delete(s);
          });
      }, a);
    });
    return this.preloadPromises.set(s, i), i;
  }
  preloadLinks() {
    It(() => {
      Array.from(
        document.querySelectorAll(
          "a[data-swup-preload], [data-swup-preload-all] a"
        )
      ).forEach((e) => this.preload(e));
    });
  }
  preloadLinksOnAttention() {
    const { swup: e } = this,
      { linkSelector: t } = e.options,
      n = { passive: !0, capture: !0 };
    (this.mouseEnterDelegate = e.delegateEvent(
      t,
      "mouseenter",
      this.onMouseEnter,
      n
    )),
      (this.touchStartDelegate = e.delegateEvent(
        t,
        "touchstart",
        this.onTouchStart,
        n
      )),
      (this.focusDelegate = e.delegateEvent(t, "focus", this.onFocus, n));
  }
  preloadVisibleLinks() {
    if (this.preloadObserver) return void this.preloadObserver.update();
    const {
      threshold: e,
      delay: t,
      containers: n,
    } = this.options.preloadVisibleLinks;
    (this.preloadObserver = (function ({
      threshold: s,
      delay: r,
      containers: a,
      callback: i,
      filter: l,
    }) {
      const c = new Map(),
        h = new IntersectionObserver(
          (d) => {
            d.forEach((g) => {
              g.isIntersecting ? u(g.target) : f(g.target);
            });
          },
          { threshold: s }
        ),
        u = (d) => {
          var g;
          const { href: y } = V.fromElement(d),
            v = (g = c.get(y)) != null ? g : new Set();
          c.set(y, v),
            v.add(d),
            setTimeout(() => {
              const $ = c.get(y);
              $ != null && $.size && (i(d), h.unobserve(d), $.delete(d));
            }, r);
        },
        f = (d) => {
          var g;
          const { href: y } = V.fromElement(d);
          (g = c.get(y)) == null || g.delete(d);
        },
        p = () => {
          It(() => {
            const d = a.map((g) => `${g} a[*|href]`).join(", ");
            Array.from(document.querySelectorAll(d))
              .filter((g) => l(g))
              .forEach((g) => h.observe(g));
          });
        };
      return {
        start: () => p(),
        stop: () => h.disconnect(),
        update: () => (c.clear(), p()),
      };
    })({
      threshold: e,
      delay: t,
      containers: n,
      callback: (s) => this.preload(s),
      filter: (s) => {
        if (
          this.options.preloadVisibleLinks.ignore(s) ||
          !s.matches(this.swup.options.linkSelector)
        )
          return !1;
        const { href: r } = V.fromElement(s);
        return this.shouldPreload(r, { el: s });
      },
    })),
      this.preloadObserver.start();
  }
  stopPreloadingVisibleLinks() {
    this.preloadObserver && this.preloadObserver.stop();
  }
  shouldPreload(e, { el: t } = {}) {
    const { url: n, href: s } = V.fromUrl(e);
    return !(
      !(function () {
        if (navigator.connection) {
          var r;
          if (
            navigator.connection.saveData ||
            ((r = navigator.connection.effectiveType) != null &&
              r.endsWith("2g"))
          )
            return !1;
        }
        return !0;
      })() ||
      this.swup.cache.has(n) ||
      this.preloadPromises.has(n) ||
      this.swup.shouldIgnoreVisit(s, { el: t }) ||
      (t && this.swup.resolveUrl(n) === this.swup.resolveUrl(we()))
    );
  }
  async performPreload(e) {
    var t = this;
    const { url: n } = V.fromUrl(e),
      s = this.swup.createVisit({ to: n });
    return await this.swup.hooks.call(
      "page:preload",
      s,
      { url: n },
      async function (a, i) {
        return (i.page = await t.swup.fetchPage(e, { visit: a })), i.page;
      }
    );
  }
};
function lt() {
  return (
    (lt = Object.assign
      ? Object.assign.bind()
      : function (o) {
          for (var e = 1; e < arguments.length; e++) {
            var t = arguments[e];
            for (var n in t)
              Object.prototype.hasOwnProperty.call(t, n) && (o[n] = t[n]);
          }
          return o;
        }),
    lt.apply(this, arguments)
  );
}
let yo = class extends Ze {
  constructor(e = {}) {
    super(),
      (this.name = "SwupScriptsPlugin"),
      (this.requires = { swup: ">=4" }),
      (this.defaults = { head: !0, body: !0, optin: !1 }),
      (this.options = void 0),
      (this.options = lt({}, this.defaults, e));
  }
  mount() {
    this.on("content:replace", this.runScripts);
  }
  runScripts() {
    const { head: e, body: t, optin: n } = this.options,
      s = this.getScope({ head: e, body: t });
    if (!s) return;
    const r = Array.from(
      s.querySelectorAll(
        n
          ? "script[data-swup-reload-script]"
          : "script:not([data-swup-ignore-script])"
      )
    );
    r.forEach((a) => this.runScript(a)),
      this.swup.log(`Executed ${r.length} scripts.`);
  }
  runScript(e) {
    const t = document.createElement("script");
    for (const { name: n, value: s } of e.attributes) t.setAttribute(n, s);
    return (t.textContent = e.textContent), e.replaceWith(t), t;
  }
  getScope({ head: e, body: t }) {
    return e && t ? document : e ? document.head : t ? document.body : null;
  }
};
function Te() {
  return (
    (Te = Object.assign
      ? Object.assign.bind()
      : function (o) {
          for (var e = 1; e < arguments.length; e++) {
            var t = arguments[e];
            for (var n in t)
              Object.prototype.hasOwnProperty.call(t, n) && (o[n] = t[n]);
          }
          return o;
        }),
    Te.apply(this, arguments)
  );
}
const Dt = (o) =>
  String(o)
    .split(".")
    .map((e) => String(parseInt(e || "0", 10)))
    .concat(["0", "0"])
    .slice(0, 3)
    .join(".");
let bo = class {
  constructor() {
    (this.isSwupPlugin = !0),
      (this.swup = void 0),
      (this.version = void 0),
      (this.requires = {}),
      (this.handlersToUnregister = []);
  }
  mount() {}
  unmount() {
    this.handlersToUnregister.forEach((e) => e()),
      (this.handlersToUnregister = []);
  }
  _beforeMount() {
    if (!this.name)
      throw new Error(
        "You must define a name of plugin when creating a class."
      );
  }
  _afterUnmount() {}
  _checkRequirements() {
    return (
      typeof this.requires != "object" ||
        Object.entries(this.requires).forEach(([e, t]) => {
          if (
            !(function (n, s, r) {
              const a = (function (i, l) {
                var c;
                if (i === "swup") return (c = l.version) != null ? c : "";
                {
                  var h;
                  const u = l.findPlugin(i);
                  return (h = u?.version) != null ? h : "";
                }
              })(n, r);
              return (
                !!a &&
                ((i, l) =>
                  l.every((c) => {
                    const [, h, u] = c.match(/^([\D]+)?(.*)$/) || [];
                    var f, p;
                    return ((d, g) => {
                      const y = {
                        "": (v) => v === 0,
                        ">": (v) => v > 0,
                        ">=": (v) => v >= 0,
                        "<": (v) => v < 0,
                        "<=": (v) => v <= 0,
                      };
                      return (y[g] || y[""])(d);
                    })(
                      ((p = u),
                      (f = Dt((f = i))),
                      (p = Dt(p)),
                      f.localeCompare(p, void 0, { numeric: !0 })),
                      h || ">="
                    );
                  }))(a, s)
              );
            })(e, (t = Array.isArray(t) ? t : [t]), this.swup)
          ) {
            const n = `${e} ${t.join(", ")}`;
            throw new Error(
              `Plugin version mismatch: ${this.name} requires ${n}`
            );
          }
        }),
      !0
    );
  }
  on(e, t, n = {}) {
    var s;
    t =
      !(s = t).name.startsWith("bound ") || s.hasOwnProperty("prototype")
        ? t.bind(this)
        : t;
    const r = this.swup.hooks.on(e, t, n);
    return this.handlersToUnregister.push(r), r;
  }
  once(e, t, n = {}) {
    return this.on(e, t, Te({}, n, { once: !0 }));
  }
  before(e, t, n = {}) {
    return this.on(e, t, Te({}, n, { before: !0 }));
  }
  replace(e, t, n = {}) {
    return this.on(e, t, Te({}, n, { replace: !0 }));
  }
  off(e, t) {
    return this.swup.hooks.off(e, t);
  }
};
function ct() {
  return (
    (ct = Object.assign
      ? Object.assign.bind()
      : function (o) {
          for (var e = 1; e < arguments.length; e++) {
            var t = arguments[e];
            for (var n in t)
              Object.prototype.hasOwnProperty.call(t, n) && (o[n] = t[n]);
          }
          return o;
        }),
    ct.apply(this, arguments)
  );
}
let So = class extends bo {
  constructor(e = {}) {
    super(),
      (this.name = "SwupParallelPlugin"),
      (this.requires = { swup: ">=4.6" }),
      (this.defaults = { containers: [], keep: 0 }),
      (this.options = void 0),
      (this.originalContainers = null),
      (this.parallelContainers = []),
      (this.startVisit = (t) => {
        (this.originalContainers = null),
          this.visitHasPotentialParallelAnimation(t) &&
            ((t.animation.wait = !0), (t.animation.parallel = !0));
      }),
      (this.skipOutAnimation = (t, n) => {
        this.isParallelVisit(t) && (n.skip = !0);
      }),
      (this.insertContainers = (t) => {
        if (!this.isParallelVisit(t)) return;
        const n = this.getParallelContainersForVisit(t);
        (this.parallelContainers = n),
          this.swup.hooks.call("content:insert", { containers: n }, () => {
            for (const {
              all: r,
              next: a,
              previous: i,
              keep: l,
              remove: c,
            } of n)
              r.forEach((h, u) =>
                h.style.setProperty("--swup-parallel-container", `${u}`)
              ),
                i.setAttribute("aria-hidden", "true"),
                i.before(a),
                t.animation.animate &&
                  (a.classList.add("is-next-container"),
                  Jn(a),
                  a.classList.remove("is-next-container")),
                i.classList.add("is-previous-container"),
                l.forEach((h) => h.classList.add("is-kept-container")),
                c.forEach((h) => h.classList.add("is-removing-container"));
          }),
          (this.originalContainers = t.containers);
        const s = this.parallelContainers.map(({ selector: r }) => r);
        t.containers = t.containers.filter((r) => !s.includes(r));
      }),
      (this.resetContainers = (t) => {
        this.originalContainers && (t.containers = this.originalContainers);
      }),
      (this.cleanupContainers = () => {
        const t = this.parallelContainers;
        this.swup.hooks.call("content:remove", { containers: t }, () => {
          for (const { remove: n, next: s } of t)
            n.forEach((r) => r.remove()),
              s.classList.remove("is-next-container");
        }),
          (this.parallelContainers = []);
      }),
      (this.options = ct({}, this.defaults, e));
  }
  mount() {
    this.options.containers.length ||
      (this.options.containers = this.swup.options.containers),
      this.swup.hooks.create("content:insert"),
      this.swup.hooks.create("content:remove"),
      this.on("visit:start", this.startVisit, { priority: 1 }),
      this.before("animation:out:await", this.skipOutAnimation, {
        priority: 1,
      }),
      this.before("content:replace", this.insertContainers, { priority: 1 }),
      this.on("content:replace", this.resetContainers),
      this.on("visit:end", this.cleanupContainers);
  }
  getParallelContainersForVisit(e) {
    const { containers: t } = this.options,
      n = t.filter((s) => e.containers.includes(s));
    return n.length
      ? n.reduce((s, r) => {
          let { keep: a } = this.options;
          (a = typeof a == "object" ? a[r] : a), (a = Math.max(0, Number(a)));
          const i = e.to.document.querySelector(r),
            l = Array.from(document.querySelectorAll(r)),
            c = l[0],
            h = l.slice(0, a),
            u = l.slice(a),
            f = [...new Set([i, c, ...h, ...u])];
          return i && c
            ? [
                ...s,
                {
                  selector: r,
                  next: i,
                  previous: c,
                  keep: h,
                  remove: u,
                  all: f,
                },
              ]
            : (console.warn(`Parallel container ${r} not found`), s);
        }, [])
      : (console.warn(
          "No parallel containers found in list of replaced containers"
        ),
        []);
  }
  isParallelVisit(e) {
    return e.animation.parallel;
  }
  markVisitAsParallelAnimation(e) {
    (e.animation.wait = !0), (e.animation.parallel = !0);
  }
  visitHasPotentialParallelAnimation(e) {
    return e.animation.parallel !== !1 && this.visitHasParallelContainers(e);
  }
  visitHasParallelContainers(e) {
    return this.options.containers.some((t) => {
      const n = document.querySelector(t);
      return n?.matches(e.containers.join(","));
    });
  }
};
function ye() {
  return (
    (ye = Object.assign
      ? Object.assign.bind()
      : function (o) {
          for (var e = 1; e < arguments.length; e++) {
            var t = arguments[e];
            for (var n in t) ({}.hasOwnProperty.call(t, n) && (o[n] = t[n]));
          }
          return o;
        }),
    ye.apply(null, arguments)
  );
}
window.process || (window.process = {}),
  window.process.env || (window.process.env = {});
const Kt = ["test"].includes("production"),
  R = ["development", "test"].includes("production"),
  Qt = (o, e, t) => (o == null ? o : `\x1B[${e}m${String(o)}\x1B[${t}m`),
  tt = (o) => (Kt ? o : `🧩 ${((e) => Qt(e, 1, 22))(o)}`),
  j = (o) => (Kt ? o : ((e) => Qt(e, 94, 39))(o));
let ko = class {
  log(...e) {
    const t = e.shift();
    console.log(tt(t), ...e);
  }
  warn(...e) {
    const t = e.shift();
    console.warn(tt(t), ...e);
  }
  error(...e) {
    const t = e.shift();
    console.error(tt(t), ...e);
  }
  logIf(e, ...t) {
    e && this.log(...t);
  }
  warnIf(e, ...t) {
    e && this.warn(...t);
  }
  errorIf(e, ...t) {
    e && this.error(...t);
  }
};
const en = (o) => {
    (function ({ parsedRules: e, swup: t, logger: n }) {
      const s = t.getCurrentUrl();
      e.filter((r) => r.matchesFrom(s) || r.matchesTo(s)).forEach((r) => {
        r.containers.forEach((a) => {
          const i = We(`${a}:not([data-swup-fragment])`, t);
          if (!i) return;
          const l = i.getAttribute("data-swup-fragment-url");
          l &&
            R &&
            n?.log(`fragment url ${j(l)} for ${j(a)} provided by server`);
          const { url: c } = V.fromUrl(l || s);
          i.setAttribute("data-swup-fragment", ""),
            (i.__swupFragment = { url: c, selector: a });
        });
      });
    })(o),
      (function ({ logger: e, swup: t }) {
        const n = "data-swup-link-to-fragment";
        document.querySelectorAll(`a[${n}]`).forEach((s) => {
          var r;
          const a = s.getAttribute(n);
          if (!a)
            return void (
              R &&
              (e == null ||
                e.warn(`[${n}] needs to contain a valid fragment selector`))
            );
          const i = We(a, t);
          if (!i)
            return void (
              R &&
              (e == null ||
                e.log(`ignoring ${j(`[${n}="${a}"]`)} as ${j(a)} is missing`))
            );
          const l = (r = i.__swupFragment) == null ? void 0 : r.url;
          l
            ? (gt(l, t.getCurrentUrl()) &&
                R &&
                e?.warn(
                  `The fragment URL of ${a} is identical to the current URL. This could mean that [data-swup-fragment-url] needs to be provided by the server.`
                ),
              (s.href = l))
            : R && e?.warn(`no fragment infos found on ${a}`);
        });
      })(o),
      (function ({ logger: e }) {
        document
          .querySelectorAll("dialog[data-swup-fragment][open]")
          .forEach((t) => {
            t.__swupFragment
              ? t.__swupFragment.modalShown ||
                ((t.__swupFragment.modalShown = !0),
                t.removeAttribute("open"),
                t.showModal == null || t.showModal(),
                t.addEventListener(
                  "keydown",
                  (n) => n.key === "Escape" && n.preventDefault()
                ))
              : R && e?.warn("fragment properties missing on element:", t);
          });
      })(o);
  },
  ut = (o, e) => {
    var t;
    const n = (t = o.__swupFragment) == null ? void 0 : t.url;
    return !!n && gt(n, e);
  },
  gt = (o, e) => Ht(o) === Ht(e),
  Ht = (o) => {
    if (!o.trim()) return o;
    const e = V.fromUrl(o);
    return e.searchParams.sort(), e.pathname.replace(/\/+$/g, "") + e.search;
  },
  tn = (o) => {
    const e = o.from.url,
      t = o.to.url;
    if (e && t) return { from: e, to: t };
  },
  vt = (o, e) => {
    if (o == null || !o.name) return;
    const { name: t, containers: n } = o;
    n.forEach((s) => {
      var r;
      (r = document.querySelector(s)) == null ||
        r.classList.toggle(`to-${t}`, e);
    });
  },
  nn = (o, e, t) => e.find((n) => n.matches(o, t));
function on(o) {
  return (
    !!o &&
    o.containers.every((e) => {
      var t;
      return (
        ((t = document.querySelector(e)) == null || (t = t.tagName) == null
          ? void 0
          : t.toLowerCase()) === "template"
      );
    })
  );
}
function We(o, e) {
  for (const t of e.options.containers) {
    const n = document.querySelector(t);
    if (n != null && n.matches(o)) return n;
    const s = n?.querySelector(o);
    if (s) return s;
  }
}
function Vt(o) {
  if (!Array.isArray(o))
    throw new Error("cloneRules() expects an array of rules");
  return o.map((e) =>
    ye({}, e, {
      from: Array.isArray(e.from) ? [...e.from] : e.from,
      to: Array.isArray(e.to) ? [...e.to] : e.to,
      containers: [...e.containers],
    })
  );
}
let $o = class {
  constructor(e) {
    var t, n;
    (this.matchesFrom = void 0),
      (this.matchesTo = void 0),
      (this.swup = void 0),
      (this.from = void 0),
      (this.to = void 0),
      (this.containers = void 0),
      (this.name = void 0),
      (this.scroll = !1),
      (this.focus = void 0),
      (this.logger = void 0),
      (this.if = () => !0),
      (this.swup = e.swup),
      (this.logger = e.logger),
      (this.from = e.from || ""),
      (this.to = e.to || ""),
      e.name && (this.name = pt(e.name)),
      e.scroll !== void 0 && (this.scroll = e.scroll),
      e.focus !== void 0 && (this.focus = e.focus),
      typeof e.if == "function" && (this.if = e.if),
      (this.containers = this.parseContainers(e.containers)),
      R &&
        ((t = this.logger) == null ||
          t.errorIf(
            !this.to,
            "Every fragment rule must contain a 'to' path",
            this
          ),
        (n = this.logger) == null ||
          n.errorIf(
            !this.from,
            "Every fragment rule must contain a 'from' path",
            this
          )),
      (this.matchesFrom = Tt(this.from)),
      (this.matchesTo = Tt(this.to));
  }
  parseContainers(e) {
    var t, n;
    return Array.isArray(e) && e.length
      ? ((n = e.map((s) => s.trim())), [...new Set(n)]).filter((s) => {
          var r;
          const a = this.validateSelector(s);
          return (
            (r = this.logger) == null || r.errorIf(a instanceof Error, a),
            a === !0
          );
        })
      : (R &&
          ((t = this.logger) == null ||
            t.error(
              "Every fragment rule must contain an array of containers",
              this.getDebugInfo()
            )),
        []);
  }
  validateSelector(e) {
    return e.startsWith("#")
      ? !e.match(/\s|>/) ||
          new Error(`fragment selectors must not be nested: ${e}`)
      : new Error(`fragment selectors must be IDs: ${e}`);
  }
  getDebugInfo() {
    const { from: e, to: t, containers: n } = this;
    return { from: String(e), to: String(t), containers: String(n) };
  }
  matches(e, t) {
    var n;
    if (!this.if(t))
      return (
        R &&
          ((n = this.logger) == null ||
            n.log("ignoring fragment rule due to custom rule.if:", this)),
        !1
      );
    const { url: s } = V.fromUrl(e.from),
      { url: r } = V.fromUrl(e.to);
    if (!this.matchesFrom(s) || !this.matchesTo(r)) return !1;
    for (const i of this.containers) {
      const l = this.validateFragmentSelectorForMatch(i);
      var a;
      if (l instanceof Error)
        return (
          R && ((a = this.logger) == null || a.error(l, this.getDebugInfo())),
          !1
        );
    }
    return !0;
  }
  validateFragmentSelectorForMatch(e) {
    return document.querySelector(e)
      ? !!We(e, this.swup) ||
          new Error(
            `skipping rule since ${j(
              e
            )} is outside of swup's default containers`
          )
      : new Error(
          `skipping rule since ${j(e)} doesn't exist in the current document`
        );
  }
};
const Eo = function (o) {
    const e = tn(o);
    e && nn(e, this.parsedRules, o) && (o.scroll.reset = !1);
  },
  Co = async function (o) {
    const e = tn(o);
    if (!e) return;
    const t = this.getFragmentVisit(e, o);
    if (!t) return;
    var n;
    (o.fragmentVisit = t),
      R &&
        ((n = this.logger) == null ||
          n.log(`fragment visit: ${j(o.fragmentVisit.containers.join(", "))}`)),
      (o.scroll = (function (a, i) {
        return typeof a.scroll == "boolean"
          ? ye({}, i, { reset: a.scroll })
          : typeof a.scroll != "string" || i.target
          ? i
          : ye({}, i, { target: a.scroll });
      })(t, o.scroll));
    const s = o.a11y;
    var r;
    t.focus !== void 0 &&
      (R &&
        ((r = this.logger) == null ||
          r.errorIf(
            !s,
            "Can't set visit.a11y.focus. Is @swup/a11y-plugin installed?"
          )),
      s && (s.focus = t.focus)),
      (o.animation.scope = o.fragmentVisit.containers),
      (o.containers = o.fragmentVisit.containers),
      (o.animation.selector = o.fragmentVisit.containers.join(",")),
      vt(t, !0);
  },
  Ao = function (o, e) {
    var t, n;
    o.fragmentVisit &&
      on(o.fragmentVisit) &&
      (R &&
        ((t = this.logger) == null ||
          t.log(
            `${j("out")}-animation skipped for ${j(
              (n = o.fragmentVisit) == null ? void 0 : n.containers.toString()
            )}`
          )),
      (e.skip = !0));
  },
  Po = function (o, e) {
    var t, n;
    o.fragmentVisit &&
      on(o.fragmentVisit) &&
      (R &&
        ((t = this.logger) == null ||
          t.log(
            `${j("in")}-animation skipped for ${j(
              (n = o.fragmentVisit) == null ? void 0 : n.containers.toString()
            )}`
          )),
      (e.skip = !0));
  },
  xo = function (o, e) {
    var t;
    if (o.trigger.el || !o.to.url) return;
    const n = this.swup.cache.get(o.to.url);
    n &&
      n.fragmentHtml &&
      ((o.to.document = new DOMParser().parseFromString(
        n.fragmentHtml,
        "text/html"
      )),
      (o.to.html = n.fragmentHtml),
      R &&
        ((t = this.logger) == null ||
          t.log(`fragment cache used for ${j(o.to.url)}`)));
  },
  Lo = function (o) {
    vt(o.fragmentVisit, !0),
      en(this),
      (({ swup: e, logger: t }) => {
        const n = e.getCurrentUrl(),
          s = e.cache,
          r = s.get(n);
        if (!r) return;
        const a = new DOMParser().parseFromString(r.html, "text/html"),
          i = [],
          l = Array.from(
            document.querySelectorAll("[data-swup-fragment]")
          ).filter((c) => !c.matches("template") && !ut(c, n));
        l.length &&
          (e.options.cache
            ? (l.forEach((c) => {
                var h, u;
                if (c.querySelector("[data-swup-fragment]") != null) return;
                const f = (h = c.__swupFragment) == null ? void 0 : h.url;
                if (!f)
                  return void (
                    R &&
                    (t == null || t.warn("no fragment url found:", c))
                  );
                const p = (u = c.__swupFragment) == null ? void 0 : u.selector;
                if (!p)
                  return void (
                    R &&
                    (t == null || t.warn("no fragment selector found:", c))
                  );
                const d = s.get(f);
                if (!d) return;
                const g = a.querySelector(p);
                if (!g) return;
                const y = new DOMParser()
                  .parseFromString(d.html, "text/html")
                  .querySelector(p);
                y &&
                  (y.setAttribute("data-swup-fragment-url", f),
                  g.replaceWith(y),
                  i.push(c));
              }),
              i.length &&
                (s.update(n, { fragmentHtml: a.documentElement.outerHTML }),
                i.forEach((c) => {
                  var h, u;
                  const f =
                      ((h = c.__swupFragment) == null ? void 0 : h.url) || "",
                    p =
                      ((u = c.__swupFragment) == null ? void 0 : u.selector) ||
                      "";
                  R && t?.log(`updated cache with ${j(p)} from ${j(f)}`);
                })))
            : R &&
              t?.warn(
                "can't cache foreign fragment elements without swup's cache"
              ));
      })(this);
  },
  To = function (o) {
    vt(o.fragmentVisit, !1);
  };
let Oo = class extends Ze {
  get parsedRules() {
    return this._parsedRules;
  }
  constructor(e) {
    super(),
      (this.name = "SwupFragmentPlugin"),
      (this.requires = { swup: ">=4.6" }),
      (this._rawRules = []),
      (this._parsedRules = []),
      (this.options = void 0),
      (this.defaults = { rules: [], debug: !1 }),
      (this.logger = void 0),
      (this.options = ye({}, this.defaults, e));
  }
  mount() {
    const e = this.swup;
    var t;
    this.setRules(this.options.rules),
      R && this.options.debug && (this.logger = new ko()),
      this.before("link:self", Eo),
      this.on("visit:start", Co),
      this.before("animation:out:await", Ao),
      this.before("animation:in:await", Po),
      this.before("content:replace", xo),
      this.on("content:replace", Lo),
      this.on("visit:end", To),
      R &&
        ((t = this.logger) == null ||
          t.warnIf(
            !e.options.cache,
            "fragment caching will only work with swup's cache being active"
          )),
      en(this);
  }
  unmount() {
    super.unmount(),
      document.querySelectorAll("[data-swup-fragment]").forEach((e) => {
        e.removeAttribute("data-swup-fragment-url"), delete e.__swupFragment;
      });
  }
  setRules(e) {
    var t;
    (this._rawRules = Vt(e)),
      (this._parsedRules = e.map((n) => this.parseRule(n))),
      R &&
        ((t = this.logger) == null ||
          t.log("Updated fragment rules", this.getRules()));
  }
  getRules() {
    return Vt(this._rawRules);
  }
  prependRule(e) {
    this.setRules([e, ...this.getRules()]);
  }
  appendRule(e) {
    this.setRules([...this.getRules(), e]);
  }
  parseRule(e) {
    return new $o(ye({}, e, { logger: this.logger, swup: this.swup }));
  }
  getFragmentVisit(e, t) {
    const n = nn(e, this.parsedRules, t || this.swup.createVisit(e));
    if (!n) return;
    const s = ((l, c, h, u) => {
      let f = c
        .map((d) => {
          const g = document.querySelector(d);
          return g
            ? We(d, h)
              ? { selector: d, el: g }
              : (R &&
                  u?.error(`${j(d)} is outside of swup's default containers`),
                !1)
            : (R && u?.log(`${j(d)} missing in current document`), !1);
        })
        .filter((d) => !!d);
      const p = f.every((d) => ut(d.el, l.to));
      return (
        gt(l.from, l.to) ||
          (p && h.options.linkToSelf === "navigate") ||
          (f = f.filter(
            (d) =>
              !ut(d.el, l.to) ||
              (R &&
                u?.log(
                  `ignoring fragment ${j(
                    d.selector
                  )} as it already matches the current URL`
                ),
              !1)
          )),
        f.map((d) => d.selector)
      );
    })(e, n.containers, this.swup, this.logger);
    if (!s.length) return;
    const { name: r, scroll: a, focus: i } = n;
    return { containers: s, name: r, scroll: a, focus: i };
  }
};
class ge {
  static READY_CLASS = "is-ready";
  static TRANSITION_CLASS = "is-transitioning";
  onVisitStartBind;
  beforeContentReplaceBind;
  onContentReplaceBind;
  onAnimationInEndBind;
  onAnimationOutStartBind;
  swup;
  constructor() {
    (this.onVisitStartBind = this.onVisitStart.bind(this)),
      (this.beforeContentReplaceBind = this.beforeContentReplace.bind(this)),
      (this.onContentReplaceBind = this.onContentReplace.bind(this)),
      (this.onAnimationInEndBind = this.onAnimationInEnd.bind(this)),
      (this.onAnimationOutStartBind = this.onAnimationOutStart.bind(this));
  }
  init() {
    this.initSwup(),
      requestAnimationFrame(() => {
        document.documentElement.classList.add(ge.READY_CLASS);
      });
  }
  destroy() {
    this.swup?.destroy();
  }
  initSwup() {
    (this.swup = new go({
      animateHistoryBrowsing: !0,
      linkToSelf: "navigate",
      plugins: [
        new So(),
        new Mn({ persistAssets: !0, awaitAssets: !0 }),
        new wo({
          preloadHoveredLinks: !0,
          preloadInitialPage: !0,
          throttle: 100,
        }),
        new yo(),
        new Oo({
          rules: [
            {
              from: ["/articles(.*)"],
              to: ["/articles(.*)"],
              containers: ["#listing"],
              name: "listing-update",
              if: (e) =>
                e.to.url == "/articles" || e.to.url.match(/^\/articles\?.*$/)
                  ? !0
                  : !(
                      e.to.url.includes("/articles") &&
                      !e.to.url.includes("/page/")
                    ),
            },
          ],
        }),
      ],
    })),
      this.swup.hooks.on("visit:start", this.onVisitStartBind),
      this.swup.hooks.before("content:replace", this.beforeContentReplaceBind),
      this.swup.hooks.on("content:replace", this.onContentReplaceBind),
      this.swup.hooks.on("animation:in:end", this.onAnimationInEndBind),
      this.swup.hooks.on("animation:out:start", this.onAnimationOutStartBind),
      this.swup.hooks.on("fetch:error", (e) => {
        console.log("fetch:error:", e);
        debugger;
      }),
      this.swup.hooks.on("fetch:timeout", (e) => {
        console.log("fetch:timeout:", e);
        debugger;
      });
  }
  updateDocumentAttributes(e) {
    if (e.fragmentVisit) return;
    const s = {
      ...new DOMParser()
        .parseFromString(e.to.html, "text/html")
        .querySelector("html")?.dataset,
    };
    Object.entries(s).forEach(([r, a]) => {
      document.documentElement.setAttribute(`data-${_n(r)}`, a ?? "");
    });
  }
  onVisitStart(e) {
    e.fragmentVisit ||
      ((e.scroll.reset = !1),
      document.documentElement.classList.add(ge.TRANSITION_CLASS),
      document.documentElement.classList.remove(ge.READY_CLASS)),
      e.fragmentVisit &&
        e.fragmentVisit.name == "listing-update" &&
        qe.scrollTo("#listing", { offset: -200 });
    const t = document.querySelector("c-menu-mobile"),
      n = document.querySelector("c-menu-desktop");
    t && t.closeMenu(), n && n.closeMenu();
  }
  beforeContentReplace(e) {
    e.fragmentVisit || qe?.destroy();
  }
  onContentReplace(e) {
    e.fragmentVisit ||
      (this.updateDocumentAttributes(e),
      setTimeout(() => {
        qe?.init();
      }, 850));
  }
  onAnimationOutStart(e) {
    if (
      (document.activeElement instanceof HTMLElement &&
        document.activeElement.blur(),
      !e.fragmentVisit)
    ) {
      const t = window.scrollY;
      document.documentElement.style.setProperty("--scroll-y", `${t}px`);
      const n = t + window.innerHeight / 2;
      document.documentElement.style.setProperty(
        "--transform-origin",
        `50% ${n}px`
      );
    }
  }
  onAnimationInEnd(e) {
    if (!e.fragmentVisit) {
      document.documentElement.classList.remove(ge.TRANSITION_CLASS),
        document.documentElement.classList.add(ge.READY_CLASS),
        window.scrollTo({ top: 0, behavior: "instant" });
      const t = document.querySelector("c-menu-desktop");
      t && t.updateCurrentPageItem(window.location.pathname);
    }
  }
  navigate(e, t = {}) {
    this.swup?.navigate(e, t);
  }
}
/*!
 * CookieConsent 3.1.0
 * https://github.com/orestbida/cookieconsent
 * Author Orest Bida
 * Released under the MIT License
 */ const rn = "opt-in",
  Pe = "opt-out",
  sn = "show--consent",
  an = "show--preferences",
  qt = "disable--interaction",
  Ye = "data-category",
  x = "div",
  te = "button",
  ne = "aria-hidden",
  Oe = "btn-group",
  W = "click",
  $e = "data-role",
  wt = "consentModal",
  yt = "preferencesModal";
class _o {
  constructor() {
    (this.t = {
      mode: rn,
      revision: 0,
      autoShow: !0,
      lazyHtmlGeneration: !0,
      autoClearCookies: !0,
      manageScriptTags: !0,
      hideFromBots: !0,
      cookie: {
        name: "cc_cookie",
        expiresAfterDays: 182,
        domain: "",
        path: "/",
        secure: !0,
        sameSite: "Lax",
      },
    }),
      (this.o = {
        i: {},
        l: "",
        _: {},
        u: {},
        p: {},
        m: [],
        v: !1,
        h: null,
        C: null,
        S: null,
        M: "",
        D: !0,
        T: !1,
        k: !1,
        A: !1,
        N: !1,
        H: [],
        V: !1,
        I: !0,
        L: [],
        j: !1,
        F: "",
        P: !1,
        O: [],
        R: [],
        B: [],
        $: [],
        G: !1,
        J: !1,
        U: !1,
        q: [],
        K: [],
        W: [],
        X: {},
        Y: {},
        Z: {},
        ee: {},
        te: {},
        oe: [],
      }),
      (this.ne = { ae: {}, se: {} }),
      (this.ce = {}),
      (this.re = {
        ie: "cc:onFirstConsent",
        le: "cc:onConsent",
        de: "cc:onChange",
        fe: "cc:onModalShow",
        _e: "cc:onModalHide",
        ue: "cc:onModalReady",
      });
  }
}
const m = new _o(),
  ln = (o, e) => o.indexOf(e),
  T = (o, e) => ln(o, e) !== -1,
  Je = (o) => Array.isArray(o),
  Ee = (o) => typeof o == "string",
  ht = (o) => !!o && typeof o == "object" && !Je(o),
  oe = (o) => typeof o == "function",
  ve = (o) => Object.keys(o),
  cn = (o) => Array.from(new Set(o)),
  ze = () => document.activeElement,
  ke = (o) => o.preventDefault(),
  bt = (o, e) => o.querySelectorAll(e),
  k = (o) => {
    const e = document.createElement(o);
    return o === te && (e.type = o), e;
  },
  E = (o, e, t) => o.setAttribute(e, t),
  nt = (o, e, t) => {
    o.removeAttribute(t ? "data-" + e : e);
  },
  Be = (o, e, t) => o.getAttribute(t ? "data-" + e : e),
  S = (o, e) => o.appendChild(e),
  O = (o, e) => o.classList.add(e),
  Y = (o, e) => O(o, "cm__" + e),
  P = (o, e) => O(o, "pm__" + e),
  fe = (o, e) => o.classList.remove(e),
  de = (o) => {
    if (typeof o != "object") return o;
    if (o instanceof Date) return new Date(o.getTime());
    let e = Array.isArray(o) ? [] : {};
    for (let t in o) {
      let n = o[t];
      e[t] = de(n);
    }
    return e;
  },
  Ut = (o, e) => dispatchEvent(new CustomEvent(o, { detail: e })),
  I = (o, e, t, n) => {
    o.addEventListener(e, t), n && m.o.m.push({ pe: o, ge: e, me: t });
  },
  Ro = () => {
    const o = m.t.cookie.expiresAfterDays;
    return oe(o) ? o(m.o.F) : o;
  },
  ot = (o, e) => {
    const t = o || [],
      n = e || [];
    return t.filter((s) => !T(n, s)).concat(n.filter((s) => !T(t, s)));
  },
  un = (o) => {
    (m.o.R = cn(o)),
      (m.o.F = (() => {
        let e = "custom";
        const { R: t, O: n, B: s } = m.o,
          r = t.length;
        return (
          r === n.length ? (e = "all") : r === s.length && (e = "necessary"), e
        );
      })());
  },
  hn = (o, e, t, n) => {
    const s = "accept-",
      {
        show: r,
        showPreferences: a,
        hide: i,
        hidePreferences: l,
        acceptCategory: c,
      } = e,
      h = o || document,
      u = (w) => bt(h, `[data-cc="${w}"]`),
      f = (w, b) => {
        ke(w), c(b), l(), i();
      },
      p = u("show-preferencesModal"),
      d = u("show-consentModal"),
      g = u(s + "all"),
      y = u(s + "necessary"),
      v = u(s + "custom"),
      $ = m.t.lazyHtmlGeneration;
    for (const w of p)
      E(w, "aria-haspopup", "dialog"),
        I(w, W, (b) => {
          ke(b), a();
        }),
        $ &&
          (I(
            w,
            "mouseenter",
            (b) => {
              ke(b), m.o.N || t(e, n);
            },
            !0
          ),
          I(w, "focus", () => {
            m.o.N || t(e, n);
          }));
    for (let w of d)
      E(w, "aria-haspopup", "dialog"),
        I(
          w,
          W,
          (b) => {
            ke(b), r(!0);
          },
          !0
        );
    for (let w of g)
      I(
        w,
        W,
        (b) => {
          f(b, "all");
        },
        !0
      );
    for (let w of v)
      I(
        w,
        W,
        (b) => {
          f(b);
        },
        !0
      );
    for (let w of y)
      I(
        w,
        W,
        (b) => {
          f(b, []);
        },
        !0
      );
  },
  re = (o, e) => {
    o &&
      (e && (o.tabIndex = -1), o.focus(), e && o.removeAttribute("tabindex"));
  },
  dn = (o, e) => {
    const t = (n) => {
      n.target.removeEventListener("transitionend", t),
        n.propertyName === "opacity" &&
          getComputedStyle(o).opacity === "1" &&
          re(((s) => (s === 1 ? m.ne.be : m.ne.ve))(e));
    };
    I(o, "transitionend", t);
  };
let Bt;
const fn = (o) => {
    clearTimeout(Bt),
      o
        ? O(m.ne.ye, qt)
        : (Bt = setTimeout(() => {
            fe(m.ne.ye, qt);
          }, 500));
  },
  Mo = [
    "M 19.5 4.5 L 4.5 19.5 M 4.5 4.501 L 19.5 19.5",
    "M 3.572 13.406 L 8.281 18.115 L 20.428 5.885",
    "M 21.999 6.94 L 11.639 17.18 L 2.001 6.82 ",
  ],
  Re = (o = 0, e = 1.5) =>
    `<svg viewBox="0 0 24 24" stroke-width="${e}"><path d="${Mo[o]}"/></svg>`,
  pn = (o) => {
    const e = m.ne,
      t = m.o;
    ((n) => {
      const s = n === e.he,
        r = t.i.disablePageInteraction ? e.ye : s ? e.Ce : e.ye;
      I(
        r,
        "keydown",
        (a) => {
          if (a.key !== "Tab" || !(s ? t.k && !t.A : t.A)) return;
          const i = ze(),
            l = s ? t.q : t.K;
          l.length !== 0 &&
            (a.shiftKey
              ? (i !== l[0] && n.contains(i)) || (ke(a), re(l[1]))
              : (i !== l[1] && n.contains(i)) || (ke(a), re(l[0])));
        },
        !0
      );
    })(o);
  },
  Io = ["[href]", te, "input", "details", "[tabindex]"]
    .map((o) => o + ':not([tabindex="-1"])')
    .join(","),
  mn = (o) => {
    const { o: e, ne: t } = m,
      n = (s, r) => {
        const a = bt(s, Io);
        (r[0] = a[0]), (r[1] = a[a.length - 1]);
      };
    o === 1 && e.T && n(t.he, e.q), o === 2 && e.N && n(t.we, e.K);
  },
  se = (o, e, t) => {
    const { de: n, le: s, ie: r, _e: a, ue: i, fe: l } = m.ce,
      c = m.re;
    if (e) {
      const u = { modalName: e };
      return (
        o === c.fe
          ? oe(l) && l(u)
          : o === c._e
          ? oe(a) && a(u)
          : ((u.modal = t), oe(i) && i(u)),
        Ut(o, u)
      );
    }
    const h = { cookie: m.o.p };
    o === c.ie
      ? oe(r) && r(de(h))
      : o === c.le
      ? oe(s) && s(de(h))
      : ((h.changedCategories = m.o.L),
        (h.changedServices = m.o.ee),
        oe(n) && n(de(h))),
      Ut(o, de(h));
  },
  Ge = (o, e) => {
    try {
      return o();
    } catch (t) {
      return !e && console.warn("CookieConsent:", t), !1;
    }
  },
  dt = (o) => {
    const { Y: e, ee: t, O: n, X: s, oe: r, p: a, L: i } = m.o;
    for (const u of n) {
      const f = t[u] || e[u] || [];
      for (const p of f) {
        const d = s[u][p];
        if (!d) continue;
        const { onAccept: g, onReject: y } = d;
        !d.Se && T(e[u], p)
          ? ((d.Se = !0), oe(g) && g())
          : d.Se && !T(e[u], p) && ((d.Se = !1), oe(y) && y());
      }
    }
    if (!m.t.manageScriptTags) return;
    const l = r,
      c = o || a.categories || [],
      h = (u, f) => {
        if (f >= u.length) return;
        const p = r[f];
        if (p.xe) return h(u, f + 1);
        const d = p.Me,
          g = p.De,
          y = p.Te,
          v = T(c, g),
          $ = !!y && T(e[g], y);
        if (
          (!y && !p.ke && v) ||
          (!y && p.ke && !v && T(i, g)) ||
          (y && !p.ke && $) ||
          (y && p.ke && !$ && T(t[g] || [], y))
        ) {
          p.xe = !0;
          const w = Be(d, "type", !0);
          nt(d, "type", !!w), nt(d, Ye);
          let b = Be(d, "src", !0);
          b && nt(d, "src", !0);
          const C = k("script");
          C.textContent = d.innerHTML;
          for (const { nodeName: A } of d.attributes) E(C, A, d[A] || Be(d, A));
          w && (C.type = w), b ? (C.src = b) : (b = d.src);
          const L = !!b && (!w || ["text/javascript", "module"].includes(w));
          if (
            (L &&
              (C.onload = C.onerror =
                () => {
                  h(u, ++f);
                }),
            d.replaceWith(C),
            L)
          )
            return;
        }
        h(u, ++f);
      };
    h(l, 0);
  },
  je = "bottom",
  ft = "left",
  gn = "center",
  St = "right",
  rt = "inline",
  vn = "wide",
  wn = "pm--",
  st = ["middle", "top", je],
  jt = [ft, gn, St],
  Do = {
    box: { Ee: [vn, rt], Ae: st, Ne: jt, He: je, Ve: St },
    cloud: { Ee: [rt], Ae: st, Ne: jt, He: je, Ve: gn },
    bar: { Ee: [rt], Ae: st.slice(1), Ne: [], He: je, Ve: "" },
  },
  Ho = {
    box: { Ee: [], Ae: [], Ne: [], He: "", Ve: "" },
    bar: { Ee: [vn], Ae: [], Ne: [ft, St], He: "", Ve: ft },
  },
  yn = (o) => {
    const e = m.o.i.guiOptions,
      t = e && e.consentModal,
      n = e && e.preferencesModal;
    o === 0 && Nt(m.ne.he, Do, t, "cm--", "box", "cm"),
      o === 1 && Nt(m.ne.we, Ho, n, wn, "box", "pm");
  },
  Nt = (o, e, t, n, s, r) => {
    o.className = r;
    const a = t && t.layout,
      i = t && t.position,
      l = t && t.flipButtons,
      c = !t || t.equalWeightButtons !== !1,
      h = (a && a.split(" ")) || [],
      u = h[0],
      f = h[1],
      p = u in e ? u : s,
      d = e[p],
      g = T(d.Ee, f) && f,
      y = (i && i.split(" ")) || [],
      v = y[0],
      $ = n === wn ? y[0] : y[1],
      w = T(d.Ae, v) ? v : d.He,
      b = T(d.Ne, $) ? $ : d.Ve,
      C = (A) => {
        A && O(o, n + A);
      };
    C(p), C(g), C(w), C(b), l && C("flip");
    const L = r + "__btn--secondary";
    if (r === "cm") {
      const { Ie: A, Le: D } = m.ne;
      A && (c ? fe(A, L) : O(A, L)), D && (c ? fe(D, L) : O(D, L));
    } else {
      const { je: A } = m.ne;
      A && (c ? fe(A, L) : O(A, L));
    }
  },
  Me = (o, e) => {
    const t = m.o,
      n = m.ne,
      { hide: s, hidePreferences: r, acceptCategory: a } = o,
      i = (b) => {
        a(b), r(), s();
      },
      l = t.u && t.u.preferencesModal;
    if (!l) return;
    const c = l.title,
      h = l.closeIconLabel,
      u = l.acceptAllBtn,
      f = l.acceptNecessaryBtn,
      p = l.savePreferencesBtn,
      d = l.sections || [],
      g = u || f || p;
    if (n.Fe) (n.Pe = k(x)), P(n.Pe, "body");
    else {
      (n.Fe = k(x)), O(n.Fe, "pm-wrapper");
      const b = k("div");
      O(b, "pm-overlay"),
        S(n.Fe, b),
        I(b, W, r),
        (n.we = k(x)),
        O(n.we, "pm"),
        E(n.we, "role", "dialog"),
        E(n.we, ne, !0),
        E(n.we, "aria-modal", !0),
        E(n.we, "aria-labelledby", "pm__title"),
        I(
          n.ye,
          "keydown",
          (C) => {
            C.keyCode === 27 && r();
          },
          !0
        ),
        (n.Oe = k(x)),
        P(n.Oe, "header"),
        (n.Re = k("h2")),
        P(n.Re, "title"),
        (n.Re.id = "pm__title"),
        (n.Be = k(te)),
        P(n.Be, "close-btn"),
        E(n.Be, "aria-label", l.closeIconLabel || ""),
        I(n.Be, W, r),
        (n.$e = k("span")),
        (n.$e.innerHTML = Re()),
        S(n.Be, n.$e),
        (n.Ge = k(x)),
        P(n.Ge, "body"),
        (n.Je = k(x)),
        P(n.Je, "footer");
      var y = k(x);
      O(y, "btns");
      var v = k(x),
        $ = k(x);
      P(v, Oe),
        P($, Oe),
        S(n.Je, v),
        S(n.Je, $),
        S(n.Oe, n.Re),
        S(n.Oe, n.Be),
        (n.ve = k(x)),
        E(n.ve, "tabIndex", -1),
        S(n.we, n.ve),
        S(n.we, n.Oe),
        S(n.we, n.Ge),
        g && S(n.we, n.Je),
        S(n.Fe, n.we);
    }
    let w;
    c && ((n.Re.innerHTML = c), h && E(n.Be, "aria-label", h)),
      d.forEach((b, C) => {
        const L = b.title,
          A = b.description,
          D = b.linkedCategory,
          q = D && t.P[D],
          _ = b.cookieTable,
          M = _ && _.body,
          K = _ && _.caption,
          z = M && M.length > 0,
          N = !!q,
          G = N && t.X[D],
          ae = (ht(G) && ve(G)) || [],
          B = N && (!!A || !!z || ve(G).length > 0);
        var ee = k(x);
        if ((P(ee, "section"), B || A)) {
          var Q = k(x);
          P(Q, "section-desc-wrapper");
        }
        let le = ae.length;
        if (B && le > 0) {
          const F = k(x);
          P(F, "section-services");
          for (const X of ae) {
            const H = G[X],
              Z = (H && H.label) || X,
              pe = k(x),
              me = k(x),
              Ce = k(x),
              be = k(x);
            P(pe, "service"),
              P(be, "service-title"),
              P(me, "service-header"),
              P(Ce, "service-icon");
            const ie = Ft(Z, X, q, !0, D);
            (be.innerHTML = Z),
              S(me, Ce),
              S(me, be),
              S(pe, me),
              S(pe, ie),
              S(F, pe);
          }
          S(Q, F);
        }
        if (L) {
          var ce = k(x),
            J = k(N ? te : x);
          if (
            (P(ce, "section-title-wrapper"),
            P(J, "section-title"),
            (J.innerHTML = L),
            S(ce, J),
            N)
          ) {
            const F = k("span");
            (F.innerHTML = Re(2, 3.5)),
              P(F, "section-arrow"),
              S(ce, F),
              (ee.className += "--toggle");
            const X = Ft(L, D, q);
            let H = l.serviceCounterLabel;
            if (le > 0 && Ee(H)) {
              let Z = k("span");
              P(Z, "badge"),
                P(Z, "service-counter"),
                E(Z, ne, !0),
                E(Z, "data-servicecounter", le),
                H &&
                  ((H = H.split("|")),
                  (H = H.length > 1 && le > 1 ? H[1] : H[0]),
                  E(Z, "data-counterlabel", H)),
                (Z.innerHTML = le + (H ? " " + H : "")),
                S(J, Z);
            }
            if (B) {
              P(ee, "section--expandable");
              var $t = D + "-desc";
              E(J, "aria-expanded", !1), E(J, "aria-controls", $t);
            }
            S(ce, X);
          } else E(J, "role", "heading"), E(J, "aria-level", "3");
          S(ee, ce);
        }
        if (A) {
          var Xe = k("p");
          P(Xe, "section-desc"), (Xe.innerHTML = A), S(Q, Xe);
        }
        if (
          B &&
          (E(Q, ne, "true"),
          (Q.id = $t),
          ((F, X, H) => {
            I(J, W, () => {
              X.classList.contains("is-expanded")
                ? (fe(X, "is-expanded"),
                  E(H, "aria-expanded", "false"),
                  E(F, ne, "true"))
                : (O(X, "is-expanded"),
                  E(H, "aria-expanded", "true"),
                  E(F, ne, "false"));
            });
          })(Q, ee, J),
          z)
        ) {
          const F = k("table"),
            X = k("thead"),
            H = k("tbody");
          if (K) {
            const ie = k("caption");
            P(ie, "table-caption"), (ie.innerHTML = K), F.appendChild(ie);
          }
          P(F, "section-table"), P(X, "table-head"), P(H, "table-body");
          const Z = _.headers,
            pe = ve(Z),
            me = n.Ue.createDocumentFragment(),
            Ce = k("tr");
          for (const ie of pe) {
            const Se = Z[ie],
              ue = k("th");
            (ue.id = "cc__row-" + Se + C),
              E(ue, "scope", "col"),
              P(ue, "table-th"),
              (ue.innerHTML = Se),
              S(me, ue);
          }
          S(Ce, me), S(X, Ce);
          const be = n.Ue.createDocumentFragment();
          for (const ie of M) {
            const Se = k("tr");
            P(Se, "table-tr");
            for (const ue of pe) {
              const Et = Z[ue],
                Tn = ie[ue],
                Ae = k("td"),
                Ct = k(x);
              P(Ae, "table-td"),
                E(Ae, "data-column", Et),
                E(Ae, "headers", "cc__row-" + Et + C),
                Ct.insertAdjacentHTML("beforeend", Tn),
                S(Ae, Ct),
                S(Se, Ae);
            }
            S(be, Se);
          }
          S(H, be), S(F, X), S(F, H), S(Q, F);
        }
        (B || A) && S(ee, Q);
        const Ln = n.Pe || n.Ge;
        N
          ? (w || ((w = k(x)), P(w, "section-toggles")), w.appendChild(ee))
          : (w = null),
          S(Ln, w || ee);
      }),
      u &&
        (n.ze ||
          ((n.ze = k(te)),
          P(n.ze, "btn"),
          E(n.ze, $e, "all"),
          S(v, n.ze),
          I(n.ze, W, () => i("all"))),
        (n.ze.innerHTML = u)),
      f &&
        (n.je ||
          ((n.je = k(te)),
          P(n.je, "btn"),
          E(n.je, $e, "necessary"),
          S(v, n.je),
          I(n.je, W, () => i([]))),
        (n.je.innerHTML = f)),
      p &&
        (n.qe ||
          ((n.qe = k(te)),
          P(n.qe, "btn"),
          P(n.qe, "btn--secondary"),
          E(n.qe, $e, "save"),
          S($, n.qe),
          I(n.qe, W, () => i())),
        (n.qe.innerHTML = p)),
      n.Pe && (n.we.replaceChild(n.Pe, n.Ge), (n.Ge = n.Pe)),
      yn(1),
      t.N ||
        ((t.N = !0),
        se(m.re.ue, yt, n.we),
        e(o),
        S(n.Ce, n.Fe),
        pn(n.we),
        setTimeout(() => O(n.Fe, "cc--anim"), 100)),
      mn(2);
  };
function Ft(o, e, t, n, s) {
  const r = m.o,
    a = m.ne,
    i = k("label"),
    l = k("input"),
    c = k("span"),
    h = k("span"),
    u = k("span"),
    f = k("span"),
    p = k("span");
  if (
    ((f.innerHTML = Re(1, 3)),
    (p.innerHTML = Re(0, 3)),
    (l.type = "checkbox"),
    O(i, "section__toggle-wrapper"),
    O(l, "section__toggle"),
    O(f, "toggle__icon-on"),
    O(p, "toggle__icon-off"),
    O(c, "toggle__icon"),
    O(h, "toggle__icon-circle"),
    O(u, "toggle__label"),
    E(c, ne, "true"),
    n ? (O(i, "toggle-service"), E(l, Ye, s), (a.se[s][e] = l)) : (a.ae[e] = l),
    n
      ? ((d) => {
          I(l, "change", () => {
            const g = a.se[d],
              y = a.ae[d];
            r.Z[d] = [];
            for (let v in g) {
              const $ = g[v];
              $.checked && r.Z[d].push($.value);
            }
            y.checked = r.Z[d].length > 0;
          });
        })(s)
      : ((d) => {
          I(l, W, () => {
            const g = a.se[d],
              y = l.checked;
            r.Z[d] = [];
            for (let v in g) (g[v].checked = y), y && r.Z[d].push(v);
          });
        })(e),
    (l.value = e),
    (u.textContent = o.replace(/<.*>.*<\/.*>/gm, "")),
    S(h, p),
    S(h, f),
    S(c, h),
    r.D)
  )
    (t.readOnly || t.enabled) && (l.checked = !0);
  else if (n) {
    const d = r.Y[s];
    l.checked = t.readOnly || T(d, e);
  } else T(r.R, e) && (l.checked = !0);
  return t.readOnly && (l.disabled = !0), S(i, l), S(i, c), S(i, u), i;
}
const it = () => {
    const o = k("span");
    return m.ne.Ke || (m.ne.Ke = o), o;
  },
  bn = (o, e) => {
    const t = m.o,
      n = m.ne,
      { hide: s, showPreferences: r, acceptCategory: a } = o,
      i = t.u && t.u.consentModal;
    if (!i) return;
    const l = i.acceptAllBtn,
      c = i.acceptNecessaryBtn,
      h = i.showPreferencesBtn,
      u = i.closeIconLabel,
      f = i.footer,
      p = i.label,
      d = i.title,
      g = (v) => {
        s(), a(v);
      };
    if (!n.Qe) {
      (n.Qe = k(x)),
        (n.he = k(x)),
        (n.We = k(x)),
        (n.Xe = k(x)),
        (n.Ye = k(x)),
        O(n.Qe, "cm-wrapper"),
        O(n.he, "cm"),
        Y(n.We, "body"),
        Y(n.Xe, "texts"),
        Y(n.Ye, "btns"),
        E(n.he, "role", "dialog"),
        E(n.he, "aria-modal", "true"),
        E(n.he, ne, "false"),
        E(n.he, "aria-describedby", "cm__desc"),
        p
          ? E(n.he, "aria-label", p)
          : d && E(n.he, "aria-labelledby", "cm__title");
      const v = "box",
        $ = t.i.guiOptions,
        w = $ && $.consentModal,
        b = ((w && w.layout) || v).split(" ")[0] === v;
      d &&
        u &&
        b &&
        (n.Le ||
          ((n.Le = k(te)),
          (n.Le.innerHTML = Re()),
          Y(n.Le, "btn"),
          Y(n.Le, "btn--close"),
          I(n.Le, W, () => {
            g([]);
          }),
          S(n.We, n.Le)),
        E(n.Le, "aria-label", u)),
        S(n.We, n.Xe),
        (l || c || h) && S(n.We, n.Ye),
        (n.be = k(x)),
        E(n.be, "tabIndex", -1),
        S(n.he, n.be),
        S(n.he, n.We),
        S(n.Qe, n.he);
    }
    d &&
      (n.Ze ||
        ((n.Ze = k("h2")),
        (n.Ze.className = n.Ze.id = "cm__title"),
        S(n.Xe, n.Ze)),
      (n.Ze.innerHTML = d));
    let y = i.description;
    if (
      (y &&
        (t.V &&
          (y = y.replace(
            "{{revisionMessage}}",
            t.I ? "" : i.revisionMessage || ""
          )),
        n.et ||
          ((n.et = k("p")),
          (n.et.className = n.et.id = "cm__desc"),
          S(n.Xe, n.et)),
        (n.et.innerHTML = y)),
      l &&
        (n.tt ||
          ((n.tt = k(te)),
          S(n.tt, it()),
          Y(n.tt, "btn"),
          E(n.tt, $e, "all"),
          I(n.tt, W, () => {
            g("all");
          })),
        (n.tt.firstElementChild.innerHTML = l)),
      c &&
        (n.Ie ||
          ((n.Ie = k(te)),
          S(n.Ie, it()),
          Y(n.Ie, "btn"),
          E(n.Ie, $e, "necessary"),
          I(n.Ie, W, () => {
            g([]);
          })),
        (n.Ie.firstElementChild.innerHTML = c)),
      h &&
        (n.ot ||
          ((n.ot = k(te)),
          S(n.ot, it()),
          Y(n.ot, "btn"),
          Y(n.ot, "btn--secondary"),
          E(n.ot, $e, "show"),
          I(n.ot, "mouseenter", () => {
            t.N || Me(o, e);
          }),
          I(n.ot, W, r)),
        (n.ot.firstElementChild.innerHTML = h)),
      n.nt ||
        ((n.nt = k(x)),
        Y(n.nt, Oe),
        l && S(n.nt, n.tt),
        c && S(n.nt, n.Ie),
        (l || c) && S(n.We, n.nt),
        S(n.Ye, n.nt)),
      n.ot &&
        !n.st &&
        ((n.st = k(x)),
        n.Ie && n.tt
          ? (Y(n.st, Oe), S(n.st, n.ot), S(n.Ye, n.st))
          : (S(n.nt, n.ot), Y(n.nt, Oe + "--uneven"))),
      f)
    ) {
      if (!n.ct) {
        let v = k(x),
          $ = k(x);
        (n.ct = k(x)),
          Y(v, "footer"),
          Y($, "links"),
          Y(n.ct, "link-group"),
          S($, n.ct),
          S(v, $),
          S(n.he, v);
      }
      n.ct.innerHTML = f;
    }
    yn(0),
      t.T ||
        ((t.T = !0),
        se(m.re.ue, wt, n.he),
        e(o),
        S(n.Ce, n.Qe),
        pn(n.he),
        setTimeout(() => O(n.Qe, "cc--anim"), 100)),
      mn(1),
      hn(n.We, o, Me, e);
  },
  Sn = (o) => {
    if (!Ee(o)) return null;
    if (o in m.o._) return o;
    let e = o.slice(0, 2);
    return e in m.o._ ? e : null;
  },
  kn = () => m.o.l || m.o.i.language.default,
  $n = (o) => {
    o && (m.o.l = o);
  },
  Vo = async (o) => {
    const e = m.o;
    let t = Sn(o) ? o : kn(),
      n = e._[t];
    if (
      (Ee(n)
        ? (n = await (async (s) => {
            try {
              return await (await fetch(s)).json();
            } catch (r) {
              return console.error(r), !1;
            }
          })(n))
        : oe(n) && (n = await n()),
      !n)
    )
      throw `Could not load translation for the '${t}' language`;
    return (e.u = n), $n(t), !0;
  },
  qo = () => {
    let o = m.o.i.language.rtl,
      e = m.ne.Ce;
    o &&
      e &&
      (Je(o) || (o = [o]), T(o, m.o.l) ? O(e, "cc--rtl") : fe(e, "cc--rtl"));
  },
  _e = () => {
    const o = m.ne;
    if (o.Ce) return;
    (o.Ce = k(x)),
      (o.Ce.id = "cc-main"),
      o.Ce.setAttribute("data-nosnippet", ""),
      qo();
    let e = m.o.i.root;
    e && Ee(e) && (e = document.querySelector(e)),
      (e || o.Ue.body).appendChild(o.Ce);
  },
  Uo = (o) => Ge(() => localStorage.removeItem(o)),
  Wt = (o, e) => {
    if (e instanceof RegExp) return o.filter((t) => e.test(t));
    {
      const t = ln(o, e);
      return t > -1 ? [o[t]] : [];
    }
  },
  Bo = (o) => {
    const { hostname: e, protocol: t } = location,
      {
        name: n,
        path: s,
        domain: r,
        sameSite: a,
        useLocalStorage: i,
        secure: l,
      } = m.t.cookie,
      c = 864e5 * Ro(),
      h = new Date();
    h.setTime(h.getTime() + c), (m.o.p.expirationTime = h.getTime());
    const u = JSON.stringify(m.o.p);
    let f =
      n +
      "=" +
      encodeURIComponent(u) +
      (c !== 0 ? "; expires=" + h.toUTCString() : "") +
      "; Path=" +
      s +
      "; SameSite=" +
      a;
    T(e, ".") && (f += "; Domain=" + r),
      l && t === "https:" && (f += "; Secure"),
      i
        ? ((p, d) => {
            Ge(() => localStorage.setItem(p, d));
          })(n, u)
        : (document.cookie = f),
      m.o.p;
  },
  Yt = (o, e, t) => {
    if (o.length === 0) return;
    const n = t || m.t.cookie.domain,
      s = e || m.t.cookie.path,
      r = n.slice(0, 4) === "www.",
      a = r && n.substring(4),
      i = (l, c) => {
        c && c.slice(0, 1) !== "." && (c = "." + c),
          (document.cookie =
            l +
            "=; path=" +
            s +
            (c ? "; domain=" + c : "") +
            "; expires=Thu, 01 Jan 1970 00:00:01 GMT;");
      };
    for (const l of o) i(l, t), t || i(l, n), r && i(l, a);
  },
  jo = (o) => {
    const e = m.t.cookie.name,
      t = m.t.cookie.useLocalStorage;
    return ((s, r) => {
      let a;
      return (
        (a = Ge(() => JSON.parse(r ? s : decodeURIComponent(s)), !0) || {}), a
      );
    })(t ? ((n = e), Ge(() => localStorage.getItem(n)) || "") : No(e), t);
    var n;
  },
  No = (o, e) => {
    const t = document.cookie.match("(^|;)\\s*" + o + "\\s*=\\s*([^;]+)");
    return t ? t.pop() : "";
  },
  Fo = (o) => {
    const e = document.cookie.split(/;\s*/),
      t = [];
    for (const n of e) {
      let s = n.split("=")[0];
      t.push(s);
    }
    return t;
  },
  Wo = (o, e = []) => {
    ((t, n) => {
      const { O: s, R: r, B: a, N: i, Z: l, $: c, X: h } = m.o;
      let u = [];
      if (t) {
        Je(t) ? u.push(...t) : Ee(t) && (u = t === "all" ? s : [t]);
        for (const f of s) l[f] = T(u, f) ? ve(h[f]) : [];
      } else
        (u = [...r, ...c]),
          i &&
            (u = (() => {
              const f = m.ne.ae;
              if (!f) return [];
              let p = [];
              for (let d in f) f[d].checked && p.push(d);
              return p;
            })());
      (u = u.filter((f) => !T(s, f) || !T(n, f))), u.push(...a), un(u);
    })(o, e),
      (() => {
        const t = m.o,
          { Z: n, B: s, Y: r, X: a, O: i } = t,
          l = i;
        t.te = de(r);
        for (const c of l) {
          const h = a[c],
            u = ve(h),
            f = n[c] && n[c].length > 0,
            p = T(s, c);
          if (u.length !== 0) {
            if (((r[c] = []), p)) r[c].push(...u);
            else if (f) {
              const d = n[c];
              r[c].push(...d);
            } else r[c] = t.Z[c];
            r[c] = cn(r[c]);
          }
        }
      })(),
      (() => {
        const t = m.o;
        t.L = m.t.mode === Pe && t.D ? ot(t.$, t.R) : ot(t.R, t.p.categories);
        let n = t.L.length > 0,
          s = !1;
        for (const l of t.O)
          (t.ee[l] = ot(t.Y[l], t.te[l])), t.ee[l].length > 0 && (s = !0);
        const r = m.ne.ae;
        for (const l in r) r[l].checked = T(t.R, l);
        for (const l of t.O) {
          const c = m.ne.se[l],
            h = t.Y[l];
          for (const u in c) c[u].checked = T(h, u);
        }
        t.C || (t.C = new Date()),
          t.M ||
            (t.M = ("10000000-1000-4000-8000" + -1e11).replace(/[018]/g, (l) =>
              (
                l ^
                (crypto.getRandomValues(new Uint8Array(1))[0] & (15 >> (l / 4)))
              ).toString(16)
            )),
          (t.p = {
            categories: de(t.R),
            revision: m.t.revision,
            data: t.h,
            consentTimestamp: t.C.toISOString(),
            consentId: t.M,
            services: de(t.Y),
            languageCode: m.o.l,
          }),
          t.S && (t.p.lastConsentTimestamp = t.S.toISOString());
        let a = !1;
        const i = n || s;
        (t.D || i) &&
          (t.D && ((t.D = !1), (a = !0)),
          (t.S = t.S ? new Date() : t.C),
          (t.p.lastConsentTimestamp = t.S.toISOString()),
          Bo(),
          m.t.autoClearCookies &&
            (a || i) &&
            ((l) => {
              const c = m.o,
                h = Fo(),
                u = ((f) => {
                  const p = m.o;
                  return (f ? p.O : p.L).filter((d) => {
                    const g = p.P[d];
                    return !!g && !g.readOnly && !!g.autoClear;
                  });
                })(l);
              for (const f in c.ee)
                for (const p of c.ee[f]) {
                  const d = c.X[f][p].cookies;
                  if (!T(c.Y[f], p) && d)
                    for (const g of d) {
                      const y = Wt(h, g.name);
                      Yt(y, g.path, g.domain);
                    }
                }
              for (const f of u) {
                const p = c.P[f].autoClear,
                  d = (p && p.cookies) || [],
                  g = T(c.L, f),
                  y = !T(c.R, f),
                  v = g && y;
                if (l ? y : v) {
                  p.reloadPage && v && (c.j = !0);
                  for (const $ of d) {
                    const w = Wt(h, $.name);
                    Yt(w, $.path, $.domain);
                  }
                }
              }
            })(a),
          dt()),
          (a && (se(m.re.ie), se(m.re.le), m.t.mode === rn)) ||
            (i && se(m.re.de), t.j && ((t.j = !1), location.reload()));
      })();
  },
  Yo = (o) => {
    const e = m.o.D ? [] : m.o.R;
    return T(e, o);
  },
  zo = (o, e) => {
    const t = m.o.D ? [] : m.o.Y[e] || [];
    return T(t, o);
  },
  En = (o) => {
    const { ne: e, o: t } = m;
    if (!t.k) {
      if (!t.T) {
        if (!o) return;
        bn(kt, _e);
      }
      (t.k = !0),
        (t.J = ze()),
        t.v && fn(!0),
        dn(e.he, 1),
        O(e.ye, sn),
        E(e.he, ne, "false"),
        setTimeout(() => {
          re(m.ne.be);
        }, 100),
        se(m.re.fe, wt);
    }
  },
  Go = () => {
    const { ne: o, o: e, re: t } = m;
    e.k &&
      ((e.k = !1),
      e.v && fn(),
      re(o.Ke, !0),
      fe(o.ye, sn),
      E(o.he, ne, "true"),
      re(e.J),
      (e.J = null),
      se(t._e, wt));
  },
  Cn = () => {
    const o = m.o;
    o.A ||
      (o.N || Me(kt, _e),
      (o.A = !0),
      o.k ? (o.U = ze()) : (o.J = ze()),
      dn(m.ne.we, 2),
      O(m.ne.ye, an),
      E(m.ne.we, ne, "false"),
      setTimeout(() => {
        re(m.ne.ve);
      }, 100),
      se(m.re.fe, yt));
  },
  An = () => {
    const o = m.o;
    o.A &&
      ((o.A = !1),
      (() => {
        const e = Pn(),
          t = m.o.P,
          n = m.ne.ae,
          s = m.ne.se,
          r = (a) => T(m.o.$, a);
        for (const a in n) {
          const i = !!t[a].readOnly;
          n[a].checked = i || (e ? Yo(a) : r(a));
          for (const l in s[a]) s[a][l].checked = i || (e ? zo(l, a) : r(a));
        }
      })(),
      re(m.ne.$e, !0),
      fe(m.ne.ye, an),
      E(m.ne.we, ne, "true"),
      o.k ? (re(o.U), (o.U = null)) : (re(o.J), (o.J = null)),
      se(m.re._e, yt));
  };
var kt = {
  show: En,
  hide: Go,
  showPreferences: Cn,
  hidePreferences: An,
  acceptCategory: Wo,
};
const Pn = () => !m.o.D,
  Zo = async (o) => {
    const { o: e, t, re: n } = m,
      s = window;
    if (!s._ccRun) {
      if (
        ((s._ccRun = !0),
        ((i) => {
          const { ne: l, t: c, o: h } = m,
            u = c,
            f = h,
            { cookie: p } = u,
            d = m.ce,
            g = i.cookie,
            y = i.categories,
            v = ve(y) || [],
            $ = navigator,
            w = document;
          (l.Ue = w),
            (l.ye = w.documentElement),
            (p.domain = location.hostname),
            (f.i = i),
            (f.P = y),
            (f.O = v),
            (f._ = i.language.translations),
            (f.v = !!i.disablePageInteraction),
            (d.ie = i.onFirstConsent),
            (d.le = i.onConsent),
            (d.de = i.onChange),
            (d._e = i.onModalHide),
            (d.fe = i.onModalShow),
            (d.ue = i.onModalReady);
          const {
            mode: b,
            autoShow: C,
            lazyHtmlGeneration: L,
            autoClearCookies: A,
            revision: D,
            manageScriptTags: q,
            hideFromBots: _,
          } = i;
          b === Pe && (u.mode = b),
            typeof A == "boolean" && (u.autoClearCookies = A),
            typeof q == "boolean" && (u.manageScriptTags = q),
            typeof D == "number" && D >= 0 && ((u.revision = D), (f.V = !0)),
            typeof C == "boolean" && (u.autoShow = C),
            typeof L == "boolean" && (u.lazyHtmlGeneration = L),
            _ === !1 && (u.hideFromBots = !1),
            u.hideFromBots === !0 &&
              $ &&
              (f.G =
                ($.userAgent &&
                  /bot|crawl|spider|slurp|teoma/i.test($.userAgent)) ||
                $.webdriver),
            ht(g) && (u.cookie = { ...p, ...g }),
            u.autoClearCookies,
            f.V,
            u.manageScriptTags,
            ((M) => {
              const { P: K, X: z, Y: N, Z: G, B: ae } = m.o;
              for (let B of M) {
                const ee = K[B],
                  Q = ee.services || {},
                  le = (ht(Q) && ve(Q)) || [];
                (z[B] = {}),
                  (N[B] = []),
                  (G[B] = []),
                  ee.readOnly && (ae.push(B), (N[B] = le)),
                  (m.ne.se[B] = {});
                for (let ce of le) {
                  const J = Q[ce];
                  (J.Se = !1), (z[B][ce] = J);
                }
              }
            })(v),
            (() => {
              if (!m.t.manageScriptTags) return;
              const M = m.o,
                K = bt(document, "script[" + Ye + "]");
              for (const z of K) {
                let N = Be(z, Ye),
                  G = z.dataset.service || "",
                  ae = !1;
                if (
                  (N && N.charAt(0) === "!" && ((N = N.slice(1)), (ae = !0)),
                  G.charAt(0) === "!" && ((G = G.slice(1)), (ae = !0)),
                  T(M.O, N) &&
                    (M.oe.push({ Me: z, xe: !1, ke: ae, De: N, Te: G }), G))
                ) {
                  const B = M.X[N];
                  B[G] || (B[G] = { Se: !1 });
                }
              }
            })(),
            $n(
              (() => {
                const M = m.o.i.language.autoDetect;
                if (M) {
                  const K = {
                      browser: navigator.language,
                      document: document.documentElement.lang,
                    },
                    z = Sn(K[M]);
                  if (z) return z;
                }
                return kn();
              })()
            );
        })(o),
        e.G)
      )
        return;
      (() => {
        const i = m.o,
          l = m.t,
          c = jo(),
          {
            categories: h,
            services: u,
            consentId: f,
            consentTimestamp: p,
            lastConsentTimestamp: d,
            data: g,
            revision: y,
          } = c,
          v = Je(h);
        (i.p = c), (i.M = f);
        const $ = !!f && Ee(f);
        (i.C = p),
          i.C && (i.C = new Date(p)),
          (i.S = d),
          i.S && (i.S = new Date(d)),
          (i.h = g !== void 0 ? g : null),
          i.V && $ && y !== l.revision && (i.I = !1),
          (i.D = !($ && i.I && i.C && i.S && v)),
          l.cookie.useLocalStorage &&
            !i.D &&
            ((i.D = new Date().getTime() > (c.expirationTime || 0)),
            i.D && Uo(l.cookie.name)),
          i.D,
          (() => {
            const w = m.o;
            for (const b of w.O) {
              const C = w.P[b];
              if (C.readOnly || C.enabled) {
                w.$.push(b);
                const L = w.X[b] || {};
                for (let A in L)
                  w.Z[b].push(A), w.i.mode === Pe && w.Y[b].push(A);
              }
            }
          })(),
          i.D
            ? l.mode === Pe && (i.R = [...i.$])
            : ((i.Y = { ...i.Y, ...u }),
              (i.Z = { ...i.Y }),
              un([...i.B, ...h]));
      })();
      const a = Pn();
      if (!(await Vo())) return !1;
      if (
        (hn(null, (r = kt), Me, _e),
        m.o.D && bn(r, _e),
        m.t.lazyHtmlGeneration || Me(r, _e),
        t.autoShow && !a && En(!0),
        a)
      )
        return dt(), se(n.le);
      t.mode === Pe && dt(e.$);
    }
    var r;
  };
class xn {
  static init() {
    Zo({
      categories: {
        necessary: { enabled: !0, readOnly: !0 },
        analytics: {
          enabled: !1,
          readOnly: !1,
          services: {
            ga: {
              label: "Google Analytics",
              onAccept: () => {
                typeof window?.gtag == "function" &&
                  window?.gtag("consent", "update", {
                    ad_storage: "granted",
                    ad_user_data: "granted",
                    ad_personalization: "granted",
                    analytics_storage: "granted",
                  });
              },
              onReject: () => {
                typeof window?.gtag == "function" &&
                  window?.gtag("consent", "update", {
                    ad_storage: "denied",
                    ad_user_data: "denied",
                    ad_personalization: "denied",
                    analytics_storage: "denied",
                  });
              },
            },
          },
        },
      },
      guiOptions: {
        consentModal: {
          layout: "box inline",
          equalWeightButtons: !1,
          position: "bottom right",
        },
        preferencesModal: { equalWeightButtons: !1 },
      },
      language: {
        default: "en",
        autoDetect: "document",
        translations: {
          en: {
            consentModal: {
              title: "We value your privacy",
              description:
                "We use essential cookies to make this site work properly. Analytics may be added later and will require your consent.",
              acceptAllBtn: "Accept all",
              acceptNecessaryBtn: "Reject all",
              showPreferencesBtn: "Settings",
              footer:
                '<a href="/privacy-policy" data-no-swup>Privacy Policy</a>',
              closeIconLabel: "Close modal",
            },
            preferencesModal: {
              title: "Cookie preferences",
              acceptAllBtn: "Accept all",
              acceptNecessaryBtn: "Decline all",
              savePreferencesBtn: "Save my choices",
              closeIconLabel: "Close modal",
              sections: [
                {
                  title: "You control your data",
                  description:
                    'You can control how your data is used on our website. Learn more below about the cookies we use and choose which cookies work for you. For more information on how we use cookies, please visit our <a href="/privacy-policy" data-no-swup>Privacy Policy</a>',
                },
                {
                  title: "Operate the website",
                  description:
                    "These cookies are set to ensure that our Web site works correctly. They cannot be disabled.",
                  linkedCategory: "necessary",
                },
                {
                  title: "Performance and Analytics",
                  description:
                    "These cookies are used to analyze site browsing to improve how well it works.",
                  linkedCategory: "analytics",
                },
              ],
            },
          },
        },
      },
    });
  }
  static openCookiePreferences() {
    Cn();
  }
  static closeCookiePreferences() {
    An();
  }
}
xn.init();
window.CookieBanner = xn;
const Jo = new ge();
Jo.init();
qe.init();
On() && document.body.classList.add("firefox");
export { Jo as t };
