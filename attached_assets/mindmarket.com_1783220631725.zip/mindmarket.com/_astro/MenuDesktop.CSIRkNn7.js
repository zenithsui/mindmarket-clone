import { i } from "./component-manager.modern.i7ixt_80.js";
import "./index.BSdFiPHn.js";
class c extends HTMLElement {
  $dropdowns;
  $dropdownButtons;
  activeDropdown = null;
  isMouseInteraction = !1;
  constructor() {
    super(),
      (this.$dropdowns = this.querySelectorAll('[data-has-children="true"]')),
      (this.$dropdownButtons = this.querySelectorAll(
        "[data-dropdown-trigger]"
      ));
  }
  connectedCallback() {
    this.$dropdowns.forEach((e) => {
      const t = e.querySelector("[data-dropdown-trigger]"),
        o = e.querySelector(".c-menu-desktop_dropdown");
      t &&
        o &&
        (e.addEventListener("mouseenter", () => {
          (this.isMouseInteraction = !0), this.openDropdown(e);
        }),
        e.addEventListener("mouseleave", () => {
          this.isMouseInteraction && this.closeDropdown(e);
        }),
        t.addEventListener("keydown", (s) => this.handleButtonKeydown(s, e)),
        t.addEventListener("focus", () => this.handleButtonFocus(e)));
    }),
      document.addEventListener("click", this.handleClickOutside),
      document.addEventListener("keydown", (e) => {
        e.key === "Escape" && this.closeAllDropdowns();
      }),
      this.addEventListener("focusout", this.handleFocusOut);
  }
  handleClickOutside = (e) => {
    if (!this.activeDropdown) return;
    const t = e.target;
    this.activeDropdown.contains(t) || this.closeDropdown(this.activeDropdown);
  };
  handleFocusOut = (e) => {
    setTimeout(() => {
      const t = document.activeElement;
      this.contains(t) || this.closeAllDropdowns();
    }, 0);
  };
  disconnectedCallback() {
    document.removeEventListener("click", this.handleClickOutside);
  }
  openDropdown(e) {
    this.closeAllDropdowns(),
      e.classList.add("active"),
      (this.activeDropdown = e);
  }
  closeDropdown(e) {
    e.classList.remove("active"),
      this.activeDropdown === e && (this.activeDropdown = null);
  }
  closeAllDropdowns() {
    this.$dropdowns.forEach((e) => {
      this.closeDropdown(e);
    });
  }
  handleButtonKeydown(e, t) {
    switch (((this.isMouseInteraction = !1), e.key)) {
      case "Enter":
      case " ":
        e.preventDefault(),
          t.classList.contains("active")
            ? this.closeDropdown(t)
            : (this.openDropdown(t), this.focusFirstDropdownItem(t));
        break;
    }
  }
  handleButtonFocus(e) {
    this.isMouseInteraction || this.openDropdown(e);
  }
  focusFirstDropdownItem(e) {
    const t = e.querySelector(".c-menu-desktop_dropdown_link");
    t && t.focus();
  }
  closeMenu() {
    this.closeAllDropdowns();
  }
  isMenuOpen() {
    return this.activeDropdown !== null;
  }
  getActiveDropdown() {
    return this.activeDropdown;
  }
  updateCurrentPageItem(e) {
    const t = this.querySelectorAll(".c-menu-desktop_link"),
      o = this.querySelectorAll(".c-menu-desktop_dropdown_link");
    [...o, ...t].forEach((s) => {
      s.classList.remove("is-current-page");
    }),
      e !== "/" &&
        (t.forEach((s) => {
          new URL(s.href).pathname === e && s.classList.add("is-current-page");
        }),
        o.forEach((s) => {
          new URL(s.href).pathname === e && s.classList.add("is-current-page");
        }));
  }
}
customElements.define("c-menu-desktop", i(c, "MenuDesktop"));
export { c as default };
