const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "_astro/MenuDesktop.CSIRkNn7.js",
      "_astro/component-manager.modern.i7ixt_80.js",
      "_astro/index.BSdFiPHn.js",
    ])
) => i.map((i) => d[i]);
import { _ } from "./preload-helper.BlTxHScW.js";
_(() => import("./MenuDesktop.CSIRkNn7.js"), __vite__mapDeps([0, 1, 2]));
