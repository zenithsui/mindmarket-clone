const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "_astro/MenuMobile.mSJs35Qy.js",
      "_astro/component-manager.modern.i7ixt_80.js",
      "_astro/index.BSdFiPHn.js",
      "_astro/index.CsVyfrhj.js",
    ])
) => i.map((i) => d[i]);
import { _ } from "./preload-helper.BlTxHScW.js";
_(() => import("./MenuMobile.mSJs35Qy.js"), __vite__mapDeps([0, 1, 2, 3]));
