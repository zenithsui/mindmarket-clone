import { i as s } from "./component-manager.modern.i7ixt_80.js";
import { g as i } from "./index.CsVyfrhj.js";
import "./index.BSdFiPHn.js";
class c extends HTMLElement {
  $toggler;
  $nav;
  $accordions;
  constructor() {
    super();
  }
  connectedCallback() {
    (this.$toggler = this.querySelector("[data-menu-mobile-toggler]")),
      (this.$nav = this.querySelector(".c-menu-mobile_nav")),
      (this.$accordions = this.querySelectorAll(
        "[data-menu-mobile-accordion-button]"
      )),
      (this._onToggleClick = this._onToggleClick.bind(this)),
      this.bindEvents();
  }
  disconnectedCallback() {
    this.unbindEvents();
  }
  _onToggleClick() {
    this.toggleMenu();
  }
  _onAccordionClick = (e) => {
    const t = e.currentTarget,
      n = t.nextElementSibling,
      o = t.getAttribute("aria-expanded") === "true";
    this.closeAllAccordions(), o || this.openAccordion(t, n);
  };
  bindEvents() {
    this.$toggler?.addEventListener("click", this._onToggleClick),
      this.$accordions.forEach((e) => {
        e.addEventListener("click", this._onAccordionClick);
      });
  }
  unbindEvents() {
    this.$toggler?.removeEventListener("click", this._onToggleClick),
      this.$accordions.forEach((e) => {
        e.removeEventListener("click", this._onAccordionClick);
      });
  }
  openMenu() {
    document.documentElement.classList.add("has-menu-mobile-open"),
      this.$toggler.setAttribute("aria-expanded", "true"),
      this.$nav.setAttribute("aria-hidden", "false");
  }
  closeMenu() {
    document.documentElement.classList.remove("has-menu-mobile-open"),
      this.$toggler.setAttribute("aria-expanded", "false"),
      this.$nav.setAttribute("aria-hidden", "true"),
      this.closeAllAccordions();
  }
  toggleMenu() {
    document.documentElement.classList.contains("has-menu-mobile-open")
      ? this.closeMenu()
      : this.openMenu();
  }
  openAccordion(e, t) {
    e.setAttribute("aria-expanded", "true"),
      t.setAttribute("aria-hidden", "false"),
      e.parentElement?.classList.add("is-open"),
      i.fromTo(
        t,
        { height: 0, autoAlpha: 0 },
        { height: "auto", autoAlpha: 1, duration: 0.4, ease: "power4.inOut" }
      );
  }
  closeAccordion(e, t) {
    e.setAttribute("aria-expanded", "false"),
      t.setAttribute("aria-hidden", "true"),
      e.parentElement?.classList.remove("is-open"),
      i.to(t, { height: 0, autoAlpha: 0, duration: 0.3, ease: "power4.inOut" });
  }
  closeAllAccordions() {
    this.$accordions.forEach((e) => {
      const t = e.nextElementSibling;
      this.closeAccordion(e, t);
    });
  }
}
customElements.define("c-menu-mobile", s(c, "MenuMobile"));
export { c as default };
