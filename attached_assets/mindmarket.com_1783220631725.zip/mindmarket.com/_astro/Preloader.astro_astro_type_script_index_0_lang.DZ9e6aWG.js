import { g as c } from "./index.CsVyfrhj.js";
import { D as m } from "./DrawSVGPlugin.C1ayHBcE.js";
import { $ as s } from "./preloader.DyWePj1f.js";
import { m as a } from "./index.DtsRjIc2.js";
import "./index.BSdFiPHn.js";
const u = document.documentElement,
  l = getComputedStyle(u).getPropertyValue("--breakpoint-sm").trim(),
  p = a({ sm: l }),
  o = a({
    reducedMotion: "(prefers-reduced-motion: reduce)",
    touchScreen: "(hover: none)",
    touchOrSmall: `(max-width: ${p.value?.sm}), (hover: none)`,
  }),
  t = {
    reducedMotion: matchMedia(o.value?.reducedMotion || ""),
    touchScreen: matchMedia(o.value?.touchScreen || ""),
    touchOrSmall: matchMedia(o.value?.touchOrSmall || ""),
  },
  n = a({
    isReducedMotion: t.reducedMotion.matches,
    isTouchScreen: t.touchScreen.matches,
    isTouchOrSmall: t.touchOrSmall.matches,
  });
for (const e in t)
  t[e].addEventListener("change", () => {
    const d = `is${e.charAt(0).toUpperCase() + e.slice(1)}`;
    n.setKey(d, t[e].matches);
  });
c.registerPlugin(m);
const r = document.querySelector("[data-preloader-svg]"),
  h = document.querySelector("[data-main-path]"),
  S = document.querySelector("[data-shadow-path-1]"),
  y = document.querySelector("[data-shadow-path-2]"),
  f = document.querySelector("[data-path-circle]"),
  g = document.querySelector("[data-preloader-svg-wrap]"),
  i = c.timeline({
    paused: !1,
    onComplete: () => {
      s.set(0);
    },
  });
n.subscribe((e) => {
  e.isTouchOrSmall &&
    (i.kill(),
    document.documentElement.classList.add("is-first-loaded"),
    s.set(0));
});
i.set(g, { opacity: 1 })
  .addLabel("start")
  .fromTo(
    r,
    { y: "15%", opacity: 0 },
    { y: "0%", opacity: 1, ease: "power2.inOut", duration: 1 }
  )
  .fromTo(
    h,
    { drawSVG: "0%" },
    { drawSVG: "100%", ease: "power1.inOut", duration: 1 },
    "start"
  )
  .fromTo(
    S,
    { opacity: 0 },
    { opacity: 1, ease: "none", duration: 0.25 },
    "start+=0.39"
  )
  .fromTo(
    y,
    { opacity: 0 },
    { opacity: 1, ease: "none", duration: 0.25 },
    "start+=0.58"
  )
  .fromTo(
    f,
    { scaleY: "0" },
    { scaleY: "1", ease: "elastic.out(1,0.3)", duration: 1 },
    "-=0.25"
  )
  .fromTo(
    r,
    { y: "0%" },
    { y: "-15%", ease: "power2.inOut", duration: 1 },
    "-=0.45"
  )
  .call(
    () => {
      document.documentElement.classList.add("is-first-loaded");
    },
    [],
    1.25
  );
