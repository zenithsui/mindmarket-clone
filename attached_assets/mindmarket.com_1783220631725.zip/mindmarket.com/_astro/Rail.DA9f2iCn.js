import { i as G } from "./component-manager.modern.i7ixt_80.js";
import { $ as Z } from "./screen.B17Nb0Vk.js";
import { c as J, g as Q } from "./_commonjsHelpers.Cpj98o6Y.js";
import { $ } from "./scroll.C7dNMCy6.js";
import "./index.BSdFiPHn.js";
import "./index.esm.Fld8o4I5.js";
import "./index.DtsRjIc2.js";
var q = { exports: {} },
  M = { exports: {} },
  x = { exports: {} },
  X = x.exports,
  D;
function Y() {
  return (
    D ||
      ((D = 1),
      function () {
        var p, i, u, l, d, c;
        typeof performance < "u" && performance !== null && performance.now
          ? (x.exports = function () {
              return performance.now();
            })
          : typeof process < "u" && process !== null && process.hrtime
          ? ((x.exports = function () {
              return (p() - d) / 1e6;
            }),
            (i = process.hrtime),
            (p = function () {
              var h;
              return (h = i()), h[0] * 1e9 + h[1];
            }),
            (l = p()),
            (c = process.uptime() * 1e9),
            (d = l - c))
          : Date.now
          ? ((x.exports = function () {
              return Date.now() - u;
            }),
            (u = Date.now()))
          : ((x.exports = function () {
              return new Date().getTime() - u;
            }),
            (u = new Date().getTime()));
      }.call(X)),
    x.exports
  );
}
var A;
function ee() {
  if (A) return M.exports;
  A = 1;
  for (
    var p = Y(),
      i = typeof window > "u" ? J : window,
      u = ["moz", "webkit"],
      l = "AnimationFrame",
      d = i["request" + l],
      c = i["cancel" + l] || i["cancelRequest" + l],
      h = 0;
    !d && h < u.length;
    h++
  )
    (d = i[u[h] + "Request" + l]),
      (c = i[u[h] + "Cancel" + l] || i[u[h] + "CancelRequest" + l]);
  if (!d || !c) {
    var g = 0,
      m = 0,
      a = [],
      n = 1e3 / 60;
    (d = function (e) {
      if (a.length === 0) {
        var t = p(),
          r = Math.max(0, n - (t - g));
        (g = r + t),
          setTimeout(function () {
            var s = a.slice(0);
            a.length = 0;
            for (var o = 0; o < s.length; o++)
              if (!s[o].cancelled)
                try {
                  s[o].callback(g);
                } catch (f) {
                  setTimeout(function () {
                    throw f;
                  }, 0);
                }
          }, Math.round(r));
      }
      return a.push({ handle: ++m, callback: e, cancelled: !1 }), m;
    }),
      (c = function (e) {
        for (var t = 0; t < a.length; t++)
          a[t].handle === e && (a[t].cancelled = !0);
      });
  }
  return (
    (M.exports = function (e) {
      return d.call(i, e);
    }),
    (M.exports.cancel = function () {
      c.apply(i, arguments);
    }),
    (M.exports.polyfill = function (e) {
      e || (e = i), (e.requestAnimationFrame = d), (e.cancelAnimationFrame = c);
    }),
    M.exports
  );
}
var R = { exports: {} },
  k = {},
  S = { exports: {} },
  L = {},
  z;
function B() {
  if (z) return L;
  (z = 1),
    Object.defineProperty(L, "__esModule", { value: !0 }),
    (L.camelToKebab = p),
    (L.capitalize = i),
    (L.isBrowser = u);
  function p(l) {
    return l.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase();
  }
  function i(l) {
    return l.charAt(0).toUpperCase() + l.slice(1);
  }
  function u() {
    return !(typeof process < "u" && process.title === "node");
  }
  return L;
}
var H;
function te() {
  return (
    H ||
      ((H = 1),
      (function (p, i) {
        Object.defineProperty(i, "__esModule", { value: !0 });
        var u =
            typeof Symbol == "function" && typeof Symbol.iterator == "symbol"
              ? function (a) {
                  return typeof a;
                }
              : function (a) {
                  return a &&
                    typeof Symbol == "function" &&
                    a.constructor === Symbol &&
                    a !== Symbol.prototype
                    ? "symbol"
                    : typeof a;
                },
          l =
            Object.assign ||
            function (a) {
              for (var n = 1; n < arguments.length; n++) {
                var e = arguments[n];
                for (var t in e)
                  Object.prototype.hasOwnProperty.call(e, t) && (a[t] = e[t]);
              }
              return a;
            },
          d = (function () {
            function a(n, e) {
              for (var t = 0; t < e.length; t++) {
                var r = e[t];
                (r.enumerable = r.enumerable || !1),
                  (r.configurable = !0),
                  "value" in r && (r.writable = !0),
                  Object.defineProperty(n, r.key, r);
              }
            }
            return function (n, e, t) {
              return e && a(n.prototype, e), t && a(n, t), n;
            };
          })(),
          c = B();
        function h(a) {
          if (Array.isArray(a)) {
            for (var n = 0, e = Array(a.length); n < a.length; n++) e[n] = a[n];
            return e;
          } else return Array.from(a);
        }
        function g(a, n) {
          if (!(a instanceof n))
            throw new TypeError("Cannot call a class as a function");
        }
        /**
         * Logger class.
         *
         * @class
         *
         * @license https://opensource.org/licenses/MIT
         *
         * @author Patrick Heng & Fabien Motte <hengpatrick.pro@gmail.com / contact@fabienmotte.com>
         *
         * @example
         * const logger = new Logger()
         * logger.log('Test')
         */ var m = (function () {
          function a() {
            g(this, a),
              (this._enabled = !0),
              (this._defaultsLevels = {
                log: {},
                info: {},
                warn: {},
                error: {},
              }),
              (this._levels = { log: {}, info: {}, warn: {}, error: {} }),
              (this._commands = ["group", "time"]),
              (this._plugins = {}),
              (this._logHandler = null),
              this._bindLevels(),
              this._bindCommands();
          }
          return (
            d(a, [
              {
                key: "on",
                value: function () {
                  return (this._enabled = !0), this;
                },
              },
              {
                key: "off",
                value: function () {
                  return (this._enabled = !1), this;
                },
              },
              {
                key: "reset",
                value: function () {
                  (this._levels = { log: {}, info: {}, warn: {}, error: {} }),
                    (this._plugins = {}),
                    this._bindLevels();
                },
              },
              {
                key: "br",
                value: function () {
                  return this._print("log", {}, ""), this;
                },
              },
              {
                key: "level",
                value: function (e) {
                  var t =
                    arguments.length > 1 && arguments[1] !== void 0
                      ? arguments[1]
                      : {};
                  return typeof e != "string"
                    ? this._printError(
                        "Logger.level() : 'name' argument is required"
                      )
                    : (typeof this._levels[e] < "u"
                        ? (this._levels[e] = l({}, this._levels[e], t))
                        : (this._levels[e] = t),
                      this._bindLevel(e, t),
                      this);
                },
              },
              {
                key: "plugin",
                value: function (e, t) {
                  var r =
                    arguments.length > 2 && arguments[2] !== void 0
                      ? arguments[2]
                      : {};
                  return typeof e != "string"
                    ? this._printError(
                        "Logger.plugin() : 'name' argument is required"
                      )
                    : typeof this._plugins[e] < "u" &&
                      (typeof t > "u" ? "undefined" : u(t)) === "object" &&
                      t !== null
                    ? ((this._plugins[e].options = l(
                        {},
                        this._plugins[e].options,
                        t
                      )),
                      this)
                    : typeof t != "function"
                    ? this._printError(
                        "Logger.plugin() : 'fn' argument must be a function"
                      )
                    : ((this._plugins[e] = {
                        fn: t.bind(this),
                        options: l({ enabled: !0 }, r),
                      }),
                      this);
                },
              },
              {
                key: "setHandler",
                value: function (e) {
                  return (this._logHandler = e), this;
                },
              },
              {
                key: "_bindLevels",
                value: function () {
                  for (var e in this._levels) {
                    var t = this._levels[e];
                    this._bindLevel(e, t);
                  }
                },
              },
              {
                key: "_bindLevel",
                value: function (e, t) {
                  var r = this;
                  this[e] = function () {
                    for (
                      var s = arguments.length, o = Array(s), f = 0;
                      f < s;
                      f++
                    )
                      o[f] = arguments[f];
                    return r._levelCallback(e, t, o);
                  };
                },
              },
              {
                key: "_levelCallback",
                value: function (e, t, r) {
                  if (this._enabled) {
                    var s = r;
                    this._logHandler !== null && this._logHandler(s);
                    var o = this._applyPlugins(e, t, s),
                      f = o.msgs,
                      v = o.before,
                      _ = o.after,
                      y = o.styles;
                    return this._print(e, t, f, v, _, y);
                  }
                },
              },
              {
                key: "_bindCommands",
                value: function () {
                  for (
                    var e = this,
                      t = function (f, v) {
                        var _ = e._commands[f];
                        (e[_] = function (y) {
                          return console[_](y);
                        }),
                          (e[_ + "End"] = function (y) {
                            return console[_ + "End"](y);
                          });
                      },
                      r = 0,
                      s = this._commands.length;
                    r < s;
                    r++
                  )
                    t(r);
                },
              },
              {
                key: "_applyPlugins",
                value: function (e, t, r) {
                  var s = [],
                    o = [],
                    f = [];
                  for (var v in this._plugins) {
                    var _ = this._plugins[v],
                      y = { name: e, options: t };
                    if (_.options.enabled) {
                      var b = _.fn(r, _.options, y),
                        T = b.msgs,
                        w = b.before,
                        E = b.after,
                        K = b.styles;
                      T && (r = T),
                        w && (o = o.concat("<styles>" + w + "</styles>")),
                        E && (f = f.concat(E)),
                        (s = s.concat(K || {}));
                    }
                  }
                  return { msgs: r, before: o, after: f, styles: s };
                },
              },
              {
                key: "_print",
                value: function (e) {
                  var t =
                      arguments.length > 1 && arguments[1] !== void 0
                        ? arguments[1]
                        : {},
                    r =
                      arguments.length > 2 && arguments[2] !== void 0
                        ? arguments[2]
                        : [],
                    s =
                      arguments.length > 3 && arguments[3] !== void 0
                        ? arguments[3]
                        : [],
                    o =
                      arguments.length > 4 && arguments[4] !== void 0
                        ? arguments[4]
                        : [],
                    f =
                      arguments.length > 5 && arguments[5] !== void 0
                        ? arguments[5]
                        : {},
                    v = [],
                    _ = [];
                  t.styles && (f = this._mergeStyles(t.styles, f)),
                    (f = this._parsePluginsStyles(f)),
                    (_ = _.concat(f)),
                    t.styles &&
                      (_.push(this._parseStyles(t.styles)), _.push("")),
                    s.length && v.push(this._parseMsgTags(s).join(" "));
                  var y = this._sortMsgs(r),
                    b = y.stringMsgs,
                    T = y.othersMsgs;
                  t.styles &&
                    ((b[0] = "<styles>" + b[0]),
                    (b[b.length - 1] += "</styles>")),
                    v.push(this._parseMsgTags(b).join(" ")),
                    o.length && v.push(this._parseMsgTags(o).join(" ")),
                    (v = v.join(" ")),
                    (0, c.isBrowser)() || (v = v.replace(/%c/g, ""));
                  var w = [v];
                  return (
                    (0, c.isBrowser)()
                      ? w.push.apply(w, h(_).concat(h(T)))
                      : w.push.apply(w, h(T)),
                    typeof console > "u"
                      ? this
                      : (typeof this._defaultsLevels[e] < "u"
                          ? console[e].apply(console, w)
                          : console.log.apply(console, w),
                        !(e === "error" || e === "warn"))
                  );
                },
              },
              {
                key: "_mergeStyles",
                value: function (e, t) {
                  for (var r = [], s = 0, o = t.length; s < o; s++) {
                    var f = t[s];
                    r.push(l({}, f, e));
                  }
                  return r;
                },
              },
              {
                key: "_parseStyles",
                value: function (e) {
                  var t = "";
                  for (var r in e) {
                    var s = e[r];
                    t += (0, c.camelToKebab)(r) + ": " + s + ";";
                  }
                  return t;
                },
              },
              {
                key: "_parsePluginsStyles",
                value: function (e) {
                  for (var t = [], r = 0, s = e.length; r < s; r++) {
                    var o = e[r];
                    t.push(this._parseStyles(o)), t.push("");
                  }
                  return t;
                },
              },
              {
                key: "_parseMsgTags",
                value: function (e) {
                  for (var t = 0, r = e.length; t < r; t++)
                    typeof e[t] == "string" &&
                      (e[t] = e[t].replace(/<(\/)?styles>/gi, "%c"));
                  return e;
                },
              },
              {
                key: "_sortMsgs",
                value: function (e) {
                  for (var t = [], r = [], s = 0, o = e.length; s < o; s++) {
                    var f = e[s];
                    typeof f == "string" ? t.push(f) : r.push(f);
                  }
                  return { stringMsgs: t, othersMsgs: r };
                },
              },
              {
                key: "_printError",
                value: function (e) {
                  this.reset(), this.error(e);
                },
              },
            ]),
            a
          );
        })();
        (i.default = m), (p.exports = i.default);
      })(S, S.exports)),
    S.exports
  );
}
var P = { exports: {} },
  C = { exports: {} },
  j;
function re() {
  return (
    j ||
      ((j = 1),
      (function (p, i) {
        Object.defineProperty(i, "__esModule", { value: !0 }), (i.default = l);
        var u = function (c) {
          return ("0" + c).slice(-2);
        };
        function l(d, c, h) {
          var g = new Date(),
            m = u(g.getHours()),
            a = u(g.getMinutes()),
            n = u(g.getSeconds()),
            e = m + ":" + a + ":" + n,
            t = "[" + e + "]";
          return { before: t };
        }
        p.exports = i.default;
      })(C, C.exports)),
    C.exports
  );
}
var O = { exports: {} },
  F;
function ne() {
  return (
    F ||
      ((F = 1),
      (function (p, i) {
        Object.defineProperty(i, "__esModule", { value: !0 });
        var u =
          Object.assign ||
          function (g) {
            for (var m = 1; m < arguments.length; m++) {
              var a = arguments[m];
              for (var n in a)
                Object.prototype.hasOwnProperty.call(a, n) && (g[n] = a[n]);
            }
            return g;
          };
        i.default = d;
        var l = B();
        function d(g, m, a) {
          var n = m.name,
            e = n === void 0 ? null : n,
            t = m.capitalize,
            r = t === void 0 ? !1 : t,
            s = m.styles,
            o = s === void 0 ? {} : s,
            f = "",
            v = {};
          return (
            e &&
              (r && (e = (0, l.capitalize)(e)),
              (f = "[" + e + "]"),
              (v = u({}, c, h[a.name], o || {}))),
            { before: f, styles: v }
          );
        }
        var c = { color: "white", background: "#000000", padding: "3px 5px" },
          h = {
            log: { background: "#000000" },
            info: { background: "#219bff" },
            warn: { background: "#ffea2d", color: "inherit" },
            error: { background: "#e52d34" },
          };
        p.exports = i.default;
      })(O, O.exports)),
    O.exports
  );
}
var U;
function se() {
  return (
    U ||
      ((U = 1),
      (function (p, i) {
        Object.defineProperty(i, "__esModule", { value: !0 });
        var u = re(),
          l = h(u),
          d = ne(),
          c = h(d);
        function h(g) {
          return g && g.__esModule ? g : { default: g };
        }
        (i.default = { time: l.default, namespace: c.default }),
          (p.exports = i.default);
      })(P, P.exports)),
    P.exports
  );
}
var V;
function ie() {
  if (V) return k;
  (V = 1),
    Object.defineProperty(k, "__esModule", { value: !0 }),
    (k.plugins = k.Logger = void 0);
  var p = te(),
    i = d(p),
    u = se(),
    l = d(u);
  function d(c) {
    return c && c.__esModule ? c : { default: c };
  }
  return (k.Logger = i.default), (k.plugins = l.default), k;
}
var W;
function ae() {
  return (
    W ||
      ((W = 1),
      (function (p, i) {
        Object.defineProperty(i, "__esModule", { value: !0 });
        var u = ie(),
          l = new u.Logger();
        l.plugin("namespace", u.plugins.namespace, { name: "quark-raf" }),
          (i.default = l),
          (p.exports = i.default);
      })(R, R.exports)),
    R.exports
  );
}
var I;
function oe() {
  return (
    I ||
      ((I = 1),
      (function (p, i) {
        Object.defineProperty(i, "__esModule", { value: !0 });
        var u = (function () {
            function n(e, t) {
              for (var r = 0; r < t.length; r++) {
                var s = t[r];
                (s.enumerable = s.enumerable || !1),
                  (s.configurable = !0),
                  "value" in s && (s.writable = !0),
                  Object.defineProperty(e, s.key, s);
              }
            }
            return function (e, t, r) {
              return t && n(e.prototype, t), r && n(e, r), e;
            };
          })(),
          l = ee(),
          d = g(l),
          c = ae(),
          h = g(c);
        function g(n) {
          return n && n.__esModule ? n : { default: n };
        }
        function m(n, e) {
          if (!(n instanceof e))
            throw new TypeError("Cannot call a class as a function");
        }
        /**
         * Raf class.
         *
         * @class
         *
         * @license https://opensource.org/licenses/MIT
         *
         * @author Patrick Heng & Fabien Motte <hengpatrick.pro@gmail.com/contact@fabienmotte.com>
         *
         * @example
         * const callback = () => { }
         * Raf.add(callback)
         */ var a = (function () {
          function n() {
            m(this, n),
              (this._listeners = []),
              (this._binded = !1),
              (this._raf = null);
          }
          return (
            u(n, [
              {
                key: "bind",
                value: function () {
                  if (this._binded === !0)
                    return h.default.warn("Raf instance is already binded");
                  (this._binded = !0),
                    (this._update = this._update.bind(this)),
                    (this._baseTime = Date.now()),
                    (this._raf = (0, d.default)(this._update));
                },
              },
              {
                key: "unbind",
                value: function () {
                  (this._binded = !1),
                    this._raf !== null &&
                      (d.default.cancel(this._raf), (this._raf = null)),
                    (this._listeners = []);
                },
              },
              {
                key: "add",
                value: function (t) {
                  var r =
                      arguments.length > 1 && arguments[1] !== void 0
                        ? arguments[1]
                        : 60,
                    s =
                      arguments.length > 2 && arguments[2] !== void 0
                        ? arguments[2]
                        : 0,
                    o =
                      arguments.length > 3 && arguments[3] !== void 0
                        ? arguments[3]
                        : !1;
                  if (typeof t != "function")
                    return h.default.error(
                      "add() : Callback argument must be a function"
                    );
                  var f = new Date(),
                    v = {
                      id: this._listeners.length,
                      callback: t,
                      fps: r,
                      delay: s,
                      once: o,
                      deltaTargeted: 1e3 / r,
                      lastTime: f.getTime(),
                    };
                  return (
                    this._listeners.push(v), this._binded || this.bind(), v
                  );
                },
              },
              {
                key: "addOnce",
                value: function (t) {
                  var r =
                      arguments.length > 1 && arguments[1] !== void 0
                        ? arguments[1]
                        : 60,
                    s =
                      arguments.length > 2 && arguments[2] !== void 0
                        ? arguments[2]
                        : 0;
                  return this.add(t, r, s, !0);
                },
              },
              {
                key: "remove",
                value: function (t) {
                  if (typeof t != "function")
                    return h.default.error(
                      "remove() : Callback argument must be a function"
                    );
                  for (var r = 0, s = this._listeners.length; r < s; r++)
                    if (this._listeners[r].callback === t) {
                      this._listeners.splice(r, 1);
                      break;
                    }
                },
              },
              {
                key: "_update",
                value: function () {
                  for (
                    var t = Date.now(), r = t - this._baseTime, s = 0;
                    s < this._listeners.length;
                    s++
                  ) {
                    var o = this._listeners[s],
                      f = t - o.lastTime;
                    (f < o.deltaTargeted && o.fps < 60) ||
                      ((o.lastTime = t),
                      !(o.delay > 0 && r < o.delay) &&
                        (o.callback(f, r, t),
                        o.once && this.remove(o.callback)));
                  }
                  this._binded && (0, d.default)(this._update);
                },
              },
            ]),
            n
          );
        })();
        (i.default = new a()), (p.exports = i.default);
      })(q, q.exports)),
    q.exports
  );
}
var ue = oe();
const N = Q(ue);
class le extends HTMLElement {
  $container;
  $pattern;
  prevRepeatCount = null;
  currentTranslate = 0;
  idleVelocity = Number(this.dataset.velocity) || 0.35;
  direction = Number(this.dataset.direction) || 1;
  isPlaying = !1;
  unbindScreenListener = null;
  intersectionObserver;
  constructor() {
    super(),
      (this.$container = this.querySelector("[data-container]")),
      (this.$pattern = this.querySelector("[data-pattern]")),
      (this.intersectionObserver = null);
  }
  connectedCallback() {
    this.bindEvents();
  }
  disconnectedCallback() {
    this.stop(), this.unbindEvents();
  }
  bindEvents() {
    (this.unbindScreenListener = Z.subscribe(this.onResize)),
      this.setIntersectionObserver();
  }
  unbindEvents() {
    this.unbindScreenListener?.(),
      (this.unbindScreenListener = null),
      this.intersectionObserver?.disconnect();
  }
  setIntersectionObserver() {
    if (!this.$container) {
      console.error("Rail-Container is required");
      return;
    }
    (this.intersectionObserver = new IntersectionObserver((i) => {
      i.forEach((u) => {
        u.isIntersecting ? this.start() : this.stop();
      });
    })),
      this.intersectionObserver?.observe(this);
  }
  onResize = () => {
    this.repeatPattern();
  };
  onUpdate = () => {
    const i = this.$pattern.offsetWidth,
      u = Math.abs($.get().velocity) * 0.5,
      l = $.get().direction === 0 ? 1 : $.get().direction,
      c = this.idleVelocity + u * this.idleVelocity * 0.6;
    (this.currentTranslate += c * this.direction * l),
      this.currentTranslate <= -i
        ? (this.currentTranslate += i)
        : this.currentTranslate >= 0 && (this.currentTranslate -= i),
      (this.$container.style.transform = `translate3d(${this.currentTranslate}px,0,0)`);
  };
  start() {
    this.isPlaying || ((this.isPlaying = !0), N.add(this.onUpdate));
  }
  stop() {
    this.isPlaying && ((this.isPlaying = !1), N.remove(this.onUpdate));
  }
  repeatPattern() {
    const i = this.$pattern.offsetWidth,
      u = Math.ceil(window.innerWidth / i) + 1;
    if (u === this.prevRepeatCount) return;
    (this.prevRepeatCount = u),
      this.$container
        .querySelectorAll("[data-clone]")
        .forEach((d) => d.remove());
    for (let d = 0; d < u - 1; d++) {
      const c = this.$pattern.cloneNode(!0);
      c.setAttribute("data-clone", ""),
        c.setAttribute("aria-hidden", "true"),
        this.$container.appendChild(c);
    }
    this.currentTranslate = this.direction === 1 ? -i : 0;
  }
}
customElements.define("c-rail", G(le, "Rail"));
export { le as Rail };
