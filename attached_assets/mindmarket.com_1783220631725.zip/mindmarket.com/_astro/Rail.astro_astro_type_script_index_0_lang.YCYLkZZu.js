const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "_astro/Rail.DA9f2iCn.js",
      "_astro/component-manager.modern.i7ixt_80.js",
      "_astro/index.BSdFiPHn.js",
      "_astro/screen.B17Nb0Vk.js",
      "_astro/index.esm.Fld8o4I5.js",
      "_astro/index.DtsRjIc2.js",
      "_astro/_commonjsHelpers.Cpj98o6Y.js",
      "_astro/scroll.C7dNMCy6.js",
    ])
) => i.map((i) => d[i]);
import { _ } from "./preload-helper.BlTxHScW.js";
_(
  () => import("./Rail.DA9f2iCn.js"),
  __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7])
);
