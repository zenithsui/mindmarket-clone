import { i as r } from "./component-manager.modern.i7ixt_80.js";
import { r as s } from "./rive.CThzgbxe.js";
import { $ as a } from "./screen.B17Nb0Vk.js";
import { g as n } from "./index.CsVyfrhj.js";
import { $ as l } from "./preloader.DyWePj1f.js";
import { i as t } from "./context.BMvvpewv.js";
import "./index.BSdFiPHn.js";
import "./index.esm.Fld8o4I5.js";
import "./index.DtsRjIc2.js";
class o extends HTMLElement {
  src;
  autoplay;
  reveal;
  revealDelay;
  $canvas;
  rive;
  intersectionObserver;
  unbindScreenListener = null;
  hasRevealed;
  isReadyToReveal;
  timeline;
  revealDelayWithPreloader = !1;
  revealTranslateX = "0%";
  disableFirefoxRenderer = !1;
  constructor() {
    super(),
      (this.src = this.getAttribute("data-src")),
      (this.autoplay = this.getAttribute("data-autoplay") === "true"),
      (this.reveal = this.getAttribute("data-reveal") === "true"),
      (this.revealDelayWithPreloader =
        this.getAttribute("data-reveal-delay-with-preloader") === "true"),
      this.revealDelayWithPreloader
        ? (this.revealDelay =
            parseFloat(this.getAttribute("data-reveal-delay") || "0") +
            l.get() / 1e3)
        : (this.revealDelay = parseFloat(
            this.getAttribute("data-reveal-delay") || "0"
          )),
      (this.disableFirefoxRenderer =
        this.getAttribute("data-disable-firefox-renderer") === "true"),
      (this.revealTranslateX =
        this.getAttribute("data-reveal-translate-x") || "0%"),
      (this.$canvas = this.querySelector("canvas")),
      (this.rive = null),
      (this.intersectionObserver = null),
      (this.hasRevealed = !1),
      (this.isReadyToReveal = !1),
      (this.timeline = null);
  }
  connectedCallback() {
    this.initRive(), this.bindEvents();
  }
  disconnectedCallback() {
    this.unbindEvents(),
      this.rive?.cleanup(),
      this.timeline?.kill(),
      (this.timeline = null);
  }
  bindEvents() {
    this.setIntersectionObserver(),
      (this.unbindScreenListener = a.listen(this.onResize));
  }
  unbindEvents() {
    this.intersectionObserver?.disconnect(), this.unbindScreenListener?.();
  }
  setTimeline() {
    this.timeline = n.timeline({
      paused: !0,
      delay: this.revealDelay,
      onStart: () => {
        this.hasRevealed = !0;
      },
    });
    const e = this.$canvas?.parentElement;
    this.timeline
      .fromTo(
        e,
        { scale: 0.75, y: 100 },
        { scale: 1, y: 0, duration: 1.75, ease: "elastic.out(1, 0.3)" }
      )
      .fromTo(
        e,
        { x: this.revealTranslateX },
        { x: "0%", duration: 1.75, ease: "power3.inOut" },
        0
      )
      .fromTo(
        this.$canvas?.parentElement,
        { opacity: 0 },
        { opacity: 1, duration: 0.15, ease: "power1.out" },
        0
      );
  }
  setIntersectionObserver() {
    if (!(t() && this.disableFirefoxRenderer)) {
      if (!this.$canvas) {
        console.error("Rive: canvas is required");
        return;
      }
      (this.intersectionObserver = new IntersectionObserver((e) => {
        e.forEach((i) => {
          i.isIntersecting
            ? (this.rive?.startRendering(),
              this.reveal &&
                !this.hasRevealed &&
                (this.playReveal(), (this.isReadyToReveal = !0)))
            : this.rive?.stopRendering();
        });
      })),
        this.intersectionObserver?.observe(this.$canvas);
    }
  }
  onResize = () => {
    this.rive?.resizeDrawingSurfaceToCanvas();
  };
  initRive() {
    if (!this.src) {
      console.error("Rive: src is required");
      return;
    }
    if (!this.$canvas) {
      console.error("Rive: canvas is required");
      return;
    }
    this.rive = new s.Rive({
      src: this.src,
      canvas: this.$canvas,
      autoplay: !(t() && this.disableFirefoxRenderer),
      onLoad: () => {
        this.rive?.resizeDrawingSurfaceToCanvas(),
          !(t() && this.disableFirefoxRenderer) &&
            this.reveal &&
            (this.setTimeline(), this.isReadyToReveal && this.playReveal());
      },
    });
  }
  playReveal() {
    this.timeline?.play();
  }
}
customElements.define("c-rive", r(o, "Rive"));
export { o as default };
