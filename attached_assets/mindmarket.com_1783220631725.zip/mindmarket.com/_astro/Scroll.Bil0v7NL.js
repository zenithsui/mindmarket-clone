import { $ as F } from "./scroll.C7dNMCy6.js";
var N = "1.3.17";
function k(s, t, e) {
  return Math.max(s, Math.min(t, e));
}
function W(s, t, e) {
  return (1 - e) * s + e * t;
}
function x(s, t, e, i) {
  return W(s, t, 1 - Math.exp(-e * i));
}
function H(s, t) {
  return ((s % t) + t) % t;
}
var U = class {
  isRunning = !1;
  value = 0;
  from = 0;
  to = 0;
  currentTime = 0;
  lerp;
  duration;
  easing;
  onUpdate;
  advance(s) {
    if (!this.isRunning) return;
    let t = !1;
    if (this.duration && this.easing) {
      this.currentTime += s;
      const e = k(0, this.currentTime / this.duration, 1);
      t = e >= 1;
      const i = t ? 1 : this.easing(e);
      this.value = this.from + (this.to - this.from) * i;
    } else
      this.lerp
        ? ((this.value = x(this.value, this.to, this.lerp * 60, s)),
          Math.round(this.value) === this.to &&
            ((this.value = this.to), (t = !0)))
        : ((this.value = this.to), (t = !0));
    t && this.stop(), this.onUpdate?.(this.value, t);
  }
  stop() {
    this.isRunning = !1;
  }
  fromTo(s, t, { lerp: e, duration: i, easing: o, onStart: n, onUpdate: r }) {
    (this.from = this.value = s),
      (this.to = t),
      (this.lerp = e),
      (this.duration = i),
      (this.easing = o),
      (this.currentTime = 0),
      (this.isRunning = !0),
      n?.(),
      (this.onUpdate = r);
  }
};
function V(s, t) {
  let e;
  return function (...i) {
    let o = this;
    clearTimeout(e),
      (e = setTimeout(() => {
        (e = void 0), s.apply(o, i);
      }, t));
  };
}
var D = class {
    constructor(s, t, { autoResize: e = !0, debounce: i = 250 } = {}) {
      (this.wrapper = s),
        (this.content = t),
        e &&
          ((this.debouncedResize = V(this.resize, i)),
          this.wrapper instanceof Window
            ? window.addEventListener("resize", this.debouncedResize, !1)
            : ((this.wrapperResizeObserver = new ResizeObserver(
                this.debouncedResize
              )),
              this.wrapperResizeObserver.observe(this.wrapper)),
          (this.contentResizeObserver = new ResizeObserver(
            this.debouncedResize
          )),
          this.contentResizeObserver.observe(this.content)),
        this.resize();
    }
    width = 0;
    height = 0;
    scrollHeight = 0;
    scrollWidth = 0;
    debouncedResize;
    wrapperResizeObserver;
    contentResizeObserver;
    destroy() {
      this.wrapperResizeObserver?.disconnect(),
        this.contentResizeObserver?.disconnect(),
        this.wrapper === window &&
          this.debouncedResize &&
          window.removeEventListener("resize", this.debouncedResize, !1);
    }
    resize = () => {
      this.onWrapperResize(), this.onContentResize();
    };
    onWrapperResize = () => {
      this.wrapper instanceof Window
        ? ((this.width = window.innerWidth), (this.height = window.innerHeight))
        : ((this.width = this.wrapper.clientWidth),
          (this.height = this.wrapper.clientHeight));
    };
    onContentResize = () => {
      this.wrapper instanceof Window
        ? ((this.scrollHeight = this.content.scrollHeight),
          (this.scrollWidth = this.content.scrollWidth))
        : ((this.scrollHeight = this.wrapper.scrollHeight),
          (this.scrollWidth = this.wrapper.scrollWidth));
    };
    get limit() {
      return {
        x: this.scrollWidth - this.width,
        y: this.scrollHeight - this.height,
      };
    }
  },
  $ = class {
    events = {};
    emit(s, ...t) {
      let e = this.events[s] || [];
      for (let i = 0, o = e.length; i < o; i++) e[i]?.(...t);
    }
    on(s, t) {
      return (
        this.events[s]?.push(t) || (this.events[s] = [t]),
        () => {
          this.events[s] = this.events[s]?.filter((e) => t !== e);
        }
      );
    }
    off(s, t) {
      this.events[s] = this.events[s]?.filter((e) => t !== e);
    }
    destroy() {
      this.events = {};
    }
  },
  _ = 100 / 6,
  E = { passive: !1 },
  B = class {
    constructor(s, t = { wheelMultiplier: 1, touchMultiplier: 1 }) {
      (this.element = s),
        (this.options = t),
        window.addEventListener("resize", this.onWindowResize, !1),
        this.onWindowResize(),
        this.element.addEventListener("wheel", this.onWheel, E),
        this.element.addEventListener("touchstart", this.onTouchStart, E),
        this.element.addEventListener("touchmove", this.onTouchMove, E),
        this.element.addEventListener("touchend", this.onTouchEnd, E);
    }
    touchStart = { x: 0, y: 0 };
    lastDelta = { x: 0, y: 0 };
    window = { width: 0, height: 0 };
    emitter = new $();
    on(s, t) {
      return this.emitter.on(s, t);
    }
    destroy() {
      this.emitter.destroy(),
        window.removeEventListener("resize", this.onWindowResize, !1),
        this.element.removeEventListener("wheel", this.onWheel, E),
        this.element.removeEventListener("touchstart", this.onTouchStart, E),
        this.element.removeEventListener("touchmove", this.onTouchMove, E),
        this.element.removeEventListener("touchend", this.onTouchEnd, E);
    }
    onTouchStart = (s) => {
      const { clientX: t, clientY: e } = s.targetTouches
        ? s.targetTouches[0]
        : s;
      (this.touchStart.x = t),
        (this.touchStart.y = e),
        (this.lastDelta = { x: 0, y: 0 }),
        this.emitter.emit("scroll", { deltaX: 0, deltaY: 0, event: s });
    };
    onTouchMove = (s) => {
      const { clientX: t, clientY: e } = s.targetTouches
          ? s.targetTouches[0]
          : s,
        i = -(t - this.touchStart.x) * this.options.touchMultiplier,
        o = -(e - this.touchStart.y) * this.options.touchMultiplier;
      (this.touchStart.x = t),
        (this.touchStart.y = e),
        (this.lastDelta = { x: i, y: o }),
        this.emitter.emit("scroll", { deltaX: i, deltaY: o, event: s });
    };
    onTouchEnd = (s) => {
      this.emitter.emit("scroll", {
        deltaX: this.lastDelta.x,
        deltaY: this.lastDelta.y,
        event: s,
      });
    };
    onWheel = (s) => {
      let { deltaX: t, deltaY: e, deltaMode: i } = s;
      const o = i === 1 ? _ : i === 2 ? this.window.width : 1,
        n = i === 1 ? _ : i === 2 ? this.window.height : 1;
      (t *= o),
        (e *= n),
        (t *= this.options.wheelMultiplier),
        (e *= this.options.wheelMultiplier),
        this.emitter.emit("scroll", { deltaX: t, deltaY: e, event: s });
    };
    onWindowResize = () => {
      this.window = { width: window.innerWidth, height: window.innerHeight };
    };
  },
  O = (s) => Math.min(1, 1.001 - Math.pow(2, -10 * s)),
  X = class {
    _isScrolling = !1;
    _isStopped = !1;
    _isLocked = !1;
    _preventNextNativeScrollEvent = !1;
    _resetVelocityTimeout = null;
    _rafId = null;
    isTouching;
    time = 0;
    userData = {};
    lastVelocity = 0;
    velocity = 0;
    direction = 0;
    options;
    targetScroll;
    animatedScroll;
    animate = new U();
    emitter = new $();
    dimensions;
    virtualScroll;
    constructor({
      wrapper: s = window,
      content: t = document.documentElement,
      eventsTarget: e = s,
      smoothWheel: i = !0,
      syncTouch: o = !1,
      syncTouchLerp: n = 0.075,
      touchInertiaExponent: r = 1.7,
      duration: l,
      easing: u,
      lerp: d = 0.1,
      infinite: f = !1,
      orientation: v = "vertical",
      gestureOrientation: h = v === "horizontal" ? "both" : "vertical",
      touchMultiplier: a = 1,
      wheelMultiplier: c = 1,
      autoResize: p = !0,
      prevent: m,
      virtualScroll: g,
      overscroll: S = !0,
      autoRaf: w = !1,
      anchors: I = !1,
      autoToggle: b = !1,
      allowNestedScroll: y = !1,
      __experimental__naiveDimensions: R = !1,
      naiveDimensions: L = R,
      stopInertiaOnNavigate: A = !1,
    } = {}) {
      (window.lenisVersion = N),
        (!s || s === document.documentElement) && (s = window),
        typeof l == "number" && typeof u != "function"
          ? (u = O)
          : typeof u == "function" && typeof l != "number" && (l = 1),
        (this.options = {
          wrapper: s,
          content: t,
          eventsTarget: e,
          smoothWheel: i,
          syncTouch: o,
          syncTouchLerp: n,
          touchInertiaExponent: r,
          duration: l,
          easing: u,
          lerp: d,
          infinite: f,
          gestureOrientation: h,
          orientation: v,
          touchMultiplier: a,
          wheelMultiplier: c,
          autoResize: p,
          prevent: m,
          virtualScroll: g,
          overscroll: S,
          autoRaf: w,
          anchors: I,
          autoToggle: b,
          allowNestedScroll: y,
          naiveDimensions: L,
          stopInertiaOnNavigate: A,
        }),
        (this.dimensions = new D(s, t, { autoResize: p })),
        this.updateClassName(),
        (this.targetScroll = this.animatedScroll = this.actualScroll),
        this.options.wrapper.addEventListener(
          "scroll",
          this.onNativeScroll,
          !1
        ),
        this.options.wrapper.addEventListener("scrollend", this.onScrollEnd, {
          capture: !0,
        }),
        (this.options.anchors || this.options.stopInertiaOnNavigate) &&
          this.options.wrapper.addEventListener("click", this.onClick, !1),
        this.options.wrapper.addEventListener(
          "pointerdown",
          this.onPointerDown,
          !1
        ),
        (this.virtualScroll = new B(e, {
          touchMultiplier: a,
          wheelMultiplier: c,
        })),
        this.virtualScroll.on("scroll", this.onVirtualScroll),
        this.options.autoToggle &&
          (this.checkOverflow(),
          this.rootElement.addEventListener(
            "transitionend",
            this.onTransitionEnd,
            { passive: !0 }
          )),
        this.options.autoRaf && (this._rafId = requestAnimationFrame(this.raf));
    }
    destroy() {
      this.emitter.destroy(),
        this.options.wrapper.removeEventListener(
          "scroll",
          this.onNativeScroll,
          !1
        ),
        this.options.wrapper.removeEventListener(
          "scrollend",
          this.onScrollEnd,
          { capture: !0 }
        ),
        this.options.wrapper.removeEventListener(
          "pointerdown",
          this.onPointerDown,
          !1
        ),
        (this.options.anchors || this.options.stopInertiaOnNavigate) &&
          this.options.wrapper.removeEventListener("click", this.onClick, !1),
        this.virtualScroll.destroy(),
        this.dimensions.destroy(),
        this.cleanUpClassName(),
        this._rafId && cancelAnimationFrame(this._rafId);
    }
    on(s, t) {
      return this.emitter.on(s, t);
    }
    off(s, t) {
      return this.emitter.off(s, t);
    }
    onScrollEnd = (s) => {
      s instanceof CustomEvent ||
        ((this.isScrolling === "smooth" || this.isScrolling === !1) &&
          s.stopPropagation());
    };
    dispatchScrollendEvent = () => {
      this.options.wrapper.dispatchEvent(
        new CustomEvent("scrollend", {
          bubbles: this.options.wrapper === window,
          detail: { lenisScrollEnd: !0 },
        })
      );
    };
    get overflow() {
      const s = this.isHorizontal ? "overflow-x" : "overflow-y";
      return getComputedStyle(this.rootElement)[s];
    }
    checkOverflow() {
      ["hidden", "clip"].includes(this.overflow)
        ? this.internalStop()
        : this.internalStart();
    }
    onTransitionEnd = (s) => {
      s.propertyName.includes("overflow") && this.checkOverflow();
    };
    setScroll(s) {
      this.isHorizontal
        ? this.options.wrapper.scrollTo({ left: s, behavior: "instant" })
        : this.options.wrapper.scrollTo({ top: s, behavior: "instant" });
    }
    onClick = (s) => {
      const e = s
        .composedPath()
        .filter(
          (i) => i instanceof HTMLAnchorElement && i.getAttribute("href")
        );
      if (this.options.anchors) {
        const i = e.find((o) => o.getAttribute("href")?.includes("#"));
        if (i) {
          const o = i.getAttribute("href");
          if (o) {
            const n =
                typeof this.options.anchors == "object" && this.options.anchors
                  ? this.options.anchors
                  : void 0,
              r = `#${o.split("#")[1]}`;
            this.scrollTo(r, n);
          }
        }
      }
      this.options.stopInertiaOnNavigate &&
        e.find((o) => o.host === window.location.host) &&
        this.reset();
    };
    onPointerDown = (s) => {
      s.button === 1 && this.reset();
    };
    onVirtualScroll = (s) => {
      if (
        typeof this.options.virtualScroll == "function" &&
        this.options.virtualScroll(s) === !1
      )
        return;
      const { deltaX: t, deltaY: e, event: i } = s;
      if (
        (this.emitter.emit("virtual-scroll", {
          deltaX: t,
          deltaY: e,
          event: i,
        }),
        i.ctrlKey || i.lenisStopPropagation)
      )
        return;
      const o = i.type.includes("touch"),
        n = i.type.includes("wheel");
      this.isTouching = i.type === "touchstart" || i.type === "touchmove";
      const r = t === 0 && e === 0;
      if (
        this.options.syncTouch &&
        o &&
        i.type === "touchstart" &&
        r &&
        !this.isStopped &&
        !this.isLocked
      ) {
        this.reset();
        return;
      }
      const u =
        (this.options.gestureOrientation === "vertical" && e === 0) ||
        (this.options.gestureOrientation === "horizontal" && t === 0);
      if (r || u) return;
      let d = i.composedPath();
      d = d.slice(0, d.indexOf(this.rootElement));
      const f = this.options.prevent;
      if (
        d.find(
          (m) =>
            m instanceof HTMLElement &&
            ((typeof f == "function" && f?.(m)) ||
              m.hasAttribute?.("data-lenis-prevent") ||
              (o && m.hasAttribute?.("data-lenis-prevent-touch")) ||
              (n && m.hasAttribute?.("data-lenis-prevent-wheel")) ||
              (this.options.allowNestedScroll &&
                this.checkNestedScroll(m, { deltaX: t, deltaY: e })))
        )
      )
        return;
      if (this.isStopped || this.isLocked) {
        i.cancelable && i.preventDefault();
        return;
      }
      if (!((this.options.syncTouch && o) || (this.options.smoothWheel && n))) {
        (this.isScrolling = "native"),
          this.animate.stop(),
          (i.lenisStopPropagation = !0);
        return;
      }
      let h = e;
      this.options.gestureOrientation === "both"
        ? (h = Math.abs(e) > Math.abs(t) ? e : t)
        : this.options.gestureOrientation === "horizontal" && (h = t),
        (!this.options.overscroll ||
          this.options.infinite ||
          (this.options.wrapper !== window &&
            this.limit > 0 &&
            ((this.animatedScroll > 0 && this.animatedScroll < this.limit) ||
              (this.animatedScroll === 0 && e > 0) ||
              (this.animatedScroll === this.limit && e < 0)))) &&
          (i.lenisStopPropagation = !0),
        i.cancelable && i.preventDefault();
      const a = o && this.options.syncTouch,
        p = o && i.type === "touchend";
      p &&
        (h =
          Math.sign(this.velocity) *
          Math.pow(Math.abs(this.velocity), this.options.touchInertiaExponent)),
        this.scrollTo(this.targetScroll + h, {
          programmatic: !1,
          ...(a
            ? { lerp: p ? this.options.syncTouchLerp : 1 }
            : {
                lerp: this.options.lerp,
                duration: this.options.duration,
                easing: this.options.easing,
              }),
        });
    };
    resize() {
      this.dimensions.resize(),
        (this.animatedScroll = this.targetScroll = this.actualScroll),
        this.emit();
    }
    emit() {
      this.emitter.emit("scroll", this);
    }
    onNativeScroll = () => {
      if (
        (this._resetVelocityTimeout !== null &&
          (clearTimeout(this._resetVelocityTimeout),
          (this._resetVelocityTimeout = null)),
        this._preventNextNativeScrollEvent)
      ) {
        this._preventNextNativeScrollEvent = !1;
        return;
      }
      if (this.isScrolling === !1 || this.isScrolling === "native") {
        const s = this.animatedScroll;
        (this.animatedScroll = this.targetScroll = this.actualScroll),
          (this.lastVelocity = this.velocity),
          (this.velocity = this.animatedScroll - s),
          (this.direction = Math.sign(this.animatedScroll - s)),
          this.isStopped || (this.isScrolling = "native"),
          this.emit(),
          this.velocity !== 0 &&
            (this._resetVelocityTimeout = setTimeout(() => {
              (this.lastVelocity = this.velocity),
                (this.velocity = 0),
                (this.isScrolling = !1),
                this.emit();
            }, 400));
      }
    };
    reset() {
      (this.isLocked = !1),
        (this.isScrolling = !1),
        (this.animatedScroll = this.targetScroll = this.actualScroll),
        (this.lastVelocity = this.velocity = 0),
        this.animate.stop();
    }
    start() {
      if (this.isStopped) {
        if (this.options.autoToggle) {
          this.rootElement.style.removeProperty("overflow");
          return;
        }
        this.internalStart();
      }
    }
    internalStart() {
      this.isStopped && (this.reset(), (this.isStopped = !1), this.emit());
    }
    stop() {
      if (!this.isStopped) {
        if (this.options.autoToggle) {
          this.rootElement.style.setProperty("overflow", "clip");
          return;
        }
        this.internalStop();
      }
    }
    internalStop() {
      this.isStopped || (this.reset(), (this.isStopped = !0), this.emit());
    }
    raf = (s) => {
      const t = s - (this.time || s);
      (this.time = s),
        this.animate.advance(t * 0.001),
        this.options.autoRaf && (this._rafId = requestAnimationFrame(this.raf));
    };
    scrollTo(
      s,
      {
        offset: t = 0,
        immediate: e = !1,
        lock: i = !1,
        programmatic: o = !0,
        lerp: n = o ? this.options.lerp : void 0,
        duration: r = o ? this.options.duration : void 0,
        easing: l = o ? this.options.easing : void 0,
        onStart: u,
        onComplete: d,
        force: f = !1,
        userData: v,
      } = {}
    ) {
      if (!((this.isStopped || this.isLocked) && !f)) {
        if (typeof s == "string" && ["top", "left", "start", "#"].includes(s))
          s = 0;
        else if (typeof s == "string" && ["bottom", "right", "end"].includes(s))
          s = this.limit;
        else {
          let h;
          if (
            (typeof s == "string"
              ? ((h = document.querySelector(s)),
                h ||
                  (s === "#top"
                    ? (s = 0)
                    : console.warn("Lenis: Target not found", s)))
              : s instanceof HTMLElement && s?.nodeType && (h = s),
            h)
          ) {
            if (this.options.wrapper !== window) {
              const c = this.rootElement.getBoundingClientRect();
              t -= this.isHorizontal ? c.left : c.top;
            }
            const a = h.getBoundingClientRect();
            s = (this.isHorizontal ? a.left : a.top) + this.animatedScroll;
          }
        }
        if (typeof s == "number") {
          if (((s += t), (s = Math.round(s)), this.options.infinite)) {
            if (o) {
              this.targetScroll = this.animatedScroll = this.scroll;
              const h = s - this.animatedScroll;
              h > this.limit / 2
                ? (s = s - this.limit)
                : h < -this.limit / 2 && (s = s + this.limit);
            }
          } else s = k(0, s, this.limit);
          if (s === this.targetScroll) {
            u?.(this), d?.(this);
            return;
          }
          if (((this.userData = v ?? {}), e)) {
            (this.animatedScroll = this.targetScroll = s),
              this.setScroll(this.scroll),
              this.reset(),
              this.preventNextNativeScrollEvent(),
              this.emit(),
              d?.(this),
              (this.userData = {}),
              requestAnimationFrame(() => {
                this.dispatchScrollendEvent();
              });
            return;
          }
          o || (this.targetScroll = s),
            typeof r == "number" && typeof l != "function"
              ? (l = O)
              : typeof l == "function" && typeof r != "number" && (r = 1),
            this.animate.fromTo(this.animatedScroll, s, {
              duration: r,
              easing: l,
              lerp: n,
              onStart: () => {
                i && (this.isLocked = !0),
                  (this.isScrolling = "smooth"),
                  u?.(this);
              },
              onUpdate: (h, a) => {
                (this.isScrolling = "smooth"),
                  (this.lastVelocity = this.velocity),
                  (this.velocity = h - this.animatedScroll),
                  (this.direction = Math.sign(this.velocity)),
                  (this.animatedScroll = h),
                  this.setScroll(this.scroll),
                  o && (this.targetScroll = h),
                  a || this.emit(),
                  a &&
                    (this.reset(),
                    this.emit(),
                    d?.(this),
                    (this.userData = {}),
                    requestAnimationFrame(() => {
                      this.dispatchScrollendEvent();
                    }),
                    this.preventNextNativeScrollEvent());
              },
            });
        }
      }
    }
    preventNextNativeScrollEvent() {
      (this._preventNextNativeScrollEvent = !0),
        requestAnimationFrame(() => {
          this._preventNextNativeScrollEvent = !1;
        });
    }
    checkNestedScroll(s, { deltaX: t, deltaY: e }) {
      const i = Date.now(),
        o = (s._lenis ??= {});
      let n, r, l, u, d, f, v, h;
      const a = this.options.gestureOrientation;
      if (i - (o.time ?? 0) > 2e3) {
        o.time = Date.now();
        const b = window.getComputedStyle(s);
        o.computedStyle = b;
        const y = b.overflowX,
          R = b.overflowY;
        if (
          ((n = ["auto", "overlay", "scroll"].includes(y)),
          (r = ["auto", "overlay", "scroll"].includes(R)),
          (o.hasOverflowX = n),
          (o.hasOverflowY = r),
          (!n && !r) || (a === "vertical" && !r) || (a === "horizontal" && !n))
        )
          return !1;
        (d = s.scrollWidth),
          (f = s.scrollHeight),
          (v = s.clientWidth),
          (h = s.clientHeight),
          (l = d > v),
          (u = f > h),
          (o.isScrollableX = l),
          (o.isScrollableY = u),
          (o.scrollWidth = d),
          (o.scrollHeight = f),
          (o.clientWidth = v),
          (o.clientHeight = h);
      } else
        (l = o.isScrollableX),
          (u = o.isScrollableY),
          (n = o.hasOverflowX),
          (r = o.hasOverflowY),
          (d = o.scrollWidth),
          (f = o.scrollHeight),
          (v = o.clientWidth),
          (h = o.clientHeight);
      if (
        (!n && !r) ||
        (!l && !u) ||
        (a === "vertical" && (!r || !u)) ||
        (a === "horizontal" && (!n || !l))
      )
        return !1;
      let c;
      if (a === "horizontal") c = "x";
      else if (a === "vertical") c = "y";
      else {
        const b = t !== 0,
          y = e !== 0;
        b && n && l && (c = "x"), y && r && u && (c = "y");
      }
      if (!c) return !1;
      let p, m, g, S, w;
      if (c === "x") (p = s.scrollLeft), (m = d - v), (g = t), (S = n), (w = l);
      else if (c === "y")
        (p = s.scrollTop), (m = f - h), (g = e), (S = r), (w = u);
      else return !1;
      return (g > 0 ? p < m : p > 0) && S && w;
    }
    get rootElement() {
      return this.options.wrapper === window
        ? document.documentElement
        : this.options.wrapper;
    }
    get limit() {
      return this.options.naiveDimensions
        ? this.isHorizontal
          ? this.rootElement.scrollWidth - this.rootElement.clientWidth
          : this.rootElement.scrollHeight - this.rootElement.clientHeight
        : this.dimensions.limit[this.isHorizontal ? "x" : "y"];
    }
    get isHorizontal() {
      return this.options.orientation === "horizontal";
    }
    get actualScroll() {
      const s = this.options.wrapper;
      return this.isHorizontal
        ? s.scrollX ?? s.scrollLeft
        : s.scrollY ?? s.scrollTop;
    }
    get scroll() {
      return this.options.infinite
        ? H(this.animatedScroll, this.limit)
        : this.animatedScroll;
    }
    get progress() {
      return this.limit === 0 ? 1 : this.scroll / this.limit;
    }
    get isScrolling() {
      return this._isScrolling;
    }
    set isScrolling(s) {
      this._isScrolling !== s &&
        ((this._isScrolling = s), this.updateClassName());
    }
    get isStopped() {
      return this._isStopped;
    }
    set isStopped(s) {
      this._isStopped !== s && ((this._isStopped = s), this.updateClassName());
    }
    get isLocked() {
      return this._isLocked;
    }
    set isLocked(s) {
      this._isLocked !== s && ((this._isLocked = s), this.updateClassName());
    }
    get isSmooth() {
      return this.isScrolling === "smooth";
    }
    get className() {
      let s = "lenis";
      return (
        this.options.autoToggle && (s += " lenis-autoToggle"),
        this.isStopped && (s += " lenis-stopped"),
        this.isLocked && (s += " lenis-locked"),
        this.isScrolling && (s += " lenis-scrolling"),
        this.isScrolling === "smooth" && (s += " lenis-smooth"),
        s
      );
    }
    updateClassName() {
      this.cleanUpClassName(),
        (this.rootElement.className =
          `${this.rootElement.className} ${this.className}`.trim());
    }
    cleanUpClassName() {
      this.rootElement.className = this.rootElement.className
        .replace(/lenis(-\w+)?/g, "")
        .trim();
    }
  };
function T() {
  return (
    (T = Object.assign
      ? Object.assign.bind()
      : function (s) {
          for (var t = 1; t < arguments.length; t++) {
            var e = arguments[t];
            for (var i in e) ({}.hasOwnProperty.call(e, i) && (s[i] = e[i]));
          }
          return s;
        }),
    T.apply(null, arguments)
  );
}
class z {
  constructor({
    scrollElements: t,
    rootMargin: e = "-1px -1px -1px -1px",
    root: i = null,
    IORaf: o,
  }) {
    (this.scrollElements = void 0),
      (this.rootMargin = void 0),
      (this.root = void 0),
      (this.IORaf = void 0),
      (this.observer = void 0),
      (this.scrollElements = t),
      (this.rootMargin = e),
      (this.root = i),
      (this.IORaf = o),
      this._init();
  }
  _init() {
    this.observer = new IntersectionObserver(
      (t) => {
        t.forEach((e) => {
          const i = this.scrollElements.find((o) => o.$el === e.target);
          e.isIntersecting
            ? (i && (i.isAlreadyIntersected = !0), this._setInview(e))
            : i && i.isAlreadyIntersected && this._setOutOfView(e);
        });
      },
      { root: this.root, rootMargin: this.rootMargin }
    );
    for (const t of this.scrollElements) this.observe(t.$el);
  }
  destroy() {
    this.observer.disconnect();
  }
  observe(t) {
    t && this.observer.observe(t);
  }
  unobserve(t) {
    t && this.observer.unobserve(t);
  }
  _setInview(t) {
    const e = this.scrollElements.find((i) => i.$el === t.target);
    this.IORaf && e?.setInteractivityOn(), !this.IORaf && e?.setInview();
  }
  _setOutOfView(t) {
    const e = this.scrollElements.find((i) => i.$el === t.target);
    this.IORaf && e?.setInteractivityOff(),
      !this.IORaf && e?.setOutOfView(),
      (e != null && e.attributes.scrollRepeat) ||
        this.IORaf ||
        this.unobserve(t.target);
  }
}
function C(s, t, e, i, o) {
  return e + (((o - s) / (t - s)) * (i - e) || 0);
}
function P(s, t) {
  return s.reduce((e, i) => (Math.abs(i - t) < Math.abs(e - t) ? i : e));
}
const M = "--progress";
class Y {
  constructor({
    $el: t,
    id: e,
    subscribeElementUpdateFn: i,
    unsubscribeElementUpdateFn: o,
    needRaf: n,
    scrollOrientation: r,
    lenisInstance: l,
  }) {
    var u, d, f, v, h;
    (this.$el = void 0),
      (this.id = void 0),
      (this.needRaf = void 0),
      (this.attributes = void 0),
      (this.scrollOrientation = void 0),
      (this.isAlreadyIntersected = void 0),
      (this.intersection = void 0),
      (this.metrics = void 0),
      (this.currentScroll = void 0),
      (this.translateValue = void 0),
      (this.progress = void 0),
      (this.lastProgress = void 0),
      (this.isInview = void 0),
      (this.isInteractive = void 0),
      (this.isInFold = void 0),
      (this.isFirstResize = void 0),
      (this.subscribeElementUpdateFn = void 0),
      (this.unsubscribeElementUpdateFn = void 0),
      (this.lenisInstance = void 0),
      (this.getWindowSize = void 0),
      (this.getMetricsStart = void 0),
      (this.getMetricsSize = void 0),
      (this.startPositionHandlers = {
        start: (a, c, p) => a - c + p,
        middle: (a, c, p, m) => a - c + p + 0.5 * m,
        end: (a, c, p, m) => a - c + p + m,
        fold: () => 0,
      }),
      (this.endPositionHandlers = {
        start: (a, c) => a - c,
        middle: (a, c, p) => a - c + 0.5 * p,
        end: (a, c, p) => a - c + p,
      }),
      (this.$el = t),
      (this.id = e),
      (this.needRaf = n),
      (this.scrollOrientation = r),
      (this.lenisInstance = l),
      (this.subscribeElementUpdateFn = i),
      (this.unsubscribeElementUpdateFn = o),
      (this.attributes = {
        scrollClass:
          (u = this.$el.dataset.scrollClass) != null ? u : "is-inview",
        scrollOffset: (d = this.$el.dataset.scrollOffset) != null ? d : "0,0",
        scrollPosition:
          (f = this.$el.dataset.scrollPosition) != null ? f : "start,end",
        scrollCssProgress: this.$el.dataset.scrollCssProgress !== void 0,
        scrollEventProgress:
          (v = this.$el.dataset.scrollEventProgress) != null ? v : null,
        scrollSpeed:
          this.$el.dataset.scrollSpeed !== void 0
            ? parseFloat(this.$el.dataset.scrollSpeed)
            : null,
        scrollRepeat: this.$el.dataset.scrollRepeat !== void 0,
        scrollCall: (h = this.$el.dataset.scrollCall) != null ? h : null,
        scrollIgnoreFold: this.$el.dataset.scrollIgnoreFold !== void 0,
        scrollEnableTouchSpeed:
          this.$el.dataset.scrollEnableTouchSpeed !== void 0,
      }),
      (this.intersection = { start: 0, end: 0 }),
      (this.metrics = { offsetStart: 0, offsetEnd: 0, bcr: {} }),
      (this.currentScroll = this.lenisInstance.scroll),
      (this.translateValue = 0),
      (this.progress = 0),
      (this.lastProgress = null),
      (this.isInview = !1),
      (this.isInteractive = !1),
      (this.isAlreadyIntersected = !1),
      (this.isInFold = !1),
      (this.isFirstResize = !0),
      (this.getWindowSize =
        this.scrollOrientation === "vertical"
          ? () => this.lenisInstance.dimensions.height
          : () => this.lenisInstance.dimensions.width),
      (this.getMetricsStart =
        this.scrollOrientation === "vertical" ? (a) => a.top : (a) => a.left),
      (this.getMetricsSize =
        this.scrollOrientation === "vertical"
          ? (a) => a.height
          : (a) => a.width),
      this._init();
  }
  _init() {
    this.needRaf && this._resize();
  }
  onResize({ currentScroll: t }) {
    (this.currentScroll = t), this._resize();
  }
  onRender({ currentScroll: t, smooth: e }) {
    const i = this.getWindowSize();
    if (
      ((this.currentScroll = t),
      this._computeProgress(),
      this.attributes.scrollSpeed && !isNaN(this.attributes.scrollSpeed))
    )
      if (this.attributes.scrollEnableTouchSpeed || e) {
        if (this.isInFold) {
          const o = Math.max(0, this.progress);
          this.translateValue = o * i * this.attributes.scrollSpeed * -1;
        } else {
          const o = C(0, 1, -1, 1, this.progress);
          this.translateValue = o * i * this.attributes.scrollSpeed * -1;
        }
        this.$el.style.transform =
          this.scrollOrientation === "vertical"
            ? `translate3d(0, ${this.translateValue}px, 0)`
            : `translate3d(${this.translateValue}px, 0, 0)`;
      } else
        this.translateValue &&
          (this.$el.style.transform = "translate3d(0, 0, 0)"),
          (this.translateValue = 0);
  }
  setInview() {
    if (this.isInview) return;
    (this.isInview = !0), this.$el.classList.add(this.attributes.scrollClass);
    const t = this._getScrollCallFrom();
    this.attributes.scrollCall && this._dispatchCall("enter", t);
  }
  setOutOfView() {
    if (!this.isInview || !this.attributes.scrollRepeat) return;
    (this.isInview = !1),
      this.$el.classList.remove(this.attributes.scrollClass);
    const t = this._getScrollCallFrom();
    this.attributes.scrollCall && this._dispatchCall("leave", t);
  }
  setInteractivityOn() {
    this.isInteractive ||
      ((this.isInteractive = !0), this.subscribeElementUpdateFn(this));
  }
  setInteractivityOff() {
    this.isInteractive &&
      ((this.isInteractive = !1),
      this.unsubscribeElementUpdateFn(this),
      this.lastProgress !== null &&
        this._computeProgress(P([0, 1], this.lastProgress)));
  }
  _resize() {
    (this.metrics.bcr = this.$el.getBoundingClientRect()),
      this._computeMetrics(),
      this._computeIntersection(),
      this.isFirstResize &&
        ((this.isFirstResize = !1), this.isInFold && this.setInview());
  }
  _computeMetrics() {
    const t = this.getWindowSize(),
      e = this.getMetricsStart(this.metrics.bcr),
      i = this.getMetricsSize(this.metrics.bcr);
    (this.metrics.offsetStart = this.currentScroll + e - this.translateValue),
      (this.metrics.offsetEnd = this.metrics.offsetStart + i),
      (this.isInFold =
        this.metrics.offsetStart < t && !this.attributes.scrollIgnoreFold);
  }
  _computeIntersection() {
    var t, e, i, o, n, r, l, u;
    const d = this.getWindowSize(),
      f = this.getMetricsSize(this.metrics.bcr),
      v = this.attributes.scrollOffset.split(","),
      h = (t = (e = v[0]) == null ? void 0 : e.trim()) != null ? t : "0",
      a = (i = (o = v[1]) == null ? void 0 : o.trim()) != null ? i : "0",
      c = this.attributes.scrollPosition.split(",");
    let p = (n = (r = c[0]) == null ? void 0 : r.trim()) != null ? n : "start";
    const m = (l = (u = c[1]) == null ? void 0 : u.trim()) != null ? l : "end",
      g = h.includes("%")
        ? d * parseInt(h.replace("%", "").trim()) * 0.01
        : parseInt(h),
      S = a.includes("%")
        ? d * parseInt(a.replace("%", "").trim()) * 0.01
        : parseInt(a);
    this.isInFold && (p = "fold");
    const w = this.startPositionHandlers[p];
    this.intersection.start = w
      ? w(this.metrics.offsetStart, d, g, f)
      : this.metrics.offsetStart - d + g;
    const I = this.endPositionHandlers[m];
    if (
      ((this.intersection.end = I
        ? I(this.metrics.offsetStart, S, f)
        : this.metrics.offsetStart - S + f),
      this.intersection.end <= this.intersection.start)
    )
      switch (m) {
        case "start":
        default:
          this.intersection.end = this.intersection.start + 1;
          break;
        case "middle":
          this.intersection.end = this.intersection.start + 0.5 * f;
          break;
        case "end":
          this.intersection.end = this.intersection.start + f;
      }
  }
  _computeProgress(t) {
    const e =
      t ??
      ((i = C(
        this.intersection.start,
        this.intersection.end,
        0,
        1,
        this.currentScroll
      )) < 0
        ? 0
        : i > 1
        ? 1
        : i);
    var i;
    (this.progress = e),
      e !== this.lastProgress &&
        ((this.lastProgress = e),
        this.attributes.scrollCssProgress && this._setCssProgress(e),
        this.attributes.scrollEventProgress && this._setCustomEventProgress(e),
        e > 0 && e < 1 && this.setInview(),
        e === 0 && this.setOutOfView(),
        e === 1 && this.setOutOfView());
  }
  _setCssProgress(t = 0) {
    this.$el.style.setProperty(M, t.toString());
  }
  _setCustomEventProgress(t = 0) {
    const e = this.attributes.scrollEventProgress;
    if (!e) return;
    const i = new CustomEvent(e, { detail: { target: this.$el, progress: t } });
    window.dispatchEvent(i);
  }
  _getScrollCallFrom() {
    const t = P(
      [this.intersection.start, this.intersection.end],
      this.currentScroll
    );
    return this.intersection.start === t ? "start" : "end";
  }
  destroy() {
    this.attributes.scrollCssProgress && this.$el.style.removeProperty(M),
      this.attributes.scrollSpeed && this.$el.style.removeProperty("transform"),
      this.isInview &&
        this.attributes.scrollClass &&
        this.$el.classList.remove(this.attributes.scrollClass);
  }
  _dispatchCall(t, e) {
    const i = this.attributes.scrollCall;
    if (!i) return;
    const o = new CustomEvent(i, {
      detail: { target: this.$el, way: t, from: e },
    });
    window.dispatchEvent(o);
  }
}
const q = [
  "scrollOffset",
  "scrollPosition",
  "scrollCssProgress",
  "scrollEventProgress",
  "scrollSpeed",
];
class j {
  constructor({
    $el: t,
    triggerRootMargin: e,
    rafRootMargin: i,
    scrollOrientation: o,
    lenisInstance: n,
  }) {
    (this.$scrollContainer = void 0),
      (this.triggerRootMargin = void 0),
      (this.rafRootMargin = void 0),
      (this.scrollElements = void 0),
      (this.triggeredScrollElements = void 0),
      (this.RAFScrollElements = void 0),
      (this.scrollElementsToUpdate = void 0),
      (this.IOTriggerInstance = void 0),
      (this.IORafInstance = void 0),
      (this.scrollOrientation = void 0),
      (this.lenisInstance = void 0),
      t
        ? ((this.$scrollContainer = t),
          (this.lenisInstance = n),
          (this.scrollOrientation = o),
          (this.triggerRootMargin = e ?? "-1px -1px -1px -1px"),
          (this.rafRootMargin = i ?? "100% 100% 100% 100%"),
          (this.scrollElements = []),
          (this.triggeredScrollElements = []),
          (this.RAFScrollElements = []),
          (this.scrollElementsToUpdate = []),
          this._init())
        : console.error("Please provide a DOM Element as scrollContainer");
  }
  _init() {
    const t = this.$scrollContainer.querySelectorAll("[data-scroll]"),
      e = this.toElementArray(t);
    this._subscribeScrollElements(e);
    const i =
      this.lenisInstance.options.wrapper === window
        ? null
        : this.lenisInstance.options.wrapper;
    (this.IOTriggerInstance = new z({
      scrollElements: [...this.triggeredScrollElements],
      root: i,
      rootMargin: this.triggerRootMargin,
      IORaf: !1,
    })),
      (this.IORafInstance = new z({
        scrollElements: [...this.RAFScrollElements],
        root: i,
        rootMargin: this.rafRootMargin,
        IORaf: !0,
      }));
  }
  destroy() {
    this.IOTriggerInstance.destroy(),
      this.IORafInstance.destroy(),
      this._unsubscribeAllScrollElements();
  }
  onResize({ currentScroll: t }) {
    for (const e of this.RAFScrollElements) e.onResize({ currentScroll: t });
  }
  onRender({ currentScroll: t, smooth: e }) {
    for (const i of this.scrollElementsToUpdate)
      i.onRender({ currentScroll: t, smooth: e });
  }
  removeScrollElements(t) {
    const e = t.querySelectorAll("[data-scroll]");
    if (!e.length) return;
    const i = new Set(Array.from(e));
    for (let o = 0; o < this.triggeredScrollElements.length; o++) {
      const n = this.triggeredScrollElements[o];
      i.has(n.$el) &&
        (this.IOTriggerInstance.unobserve(n.$el),
        this.triggeredScrollElements.splice(o, 1));
    }
    for (let o = 0; o < this.RAFScrollElements.length; o++) {
      const n = this.RAFScrollElements[o];
      i.has(n.$el) &&
        (this.IORafInstance.unobserve(n.$el),
        this.RAFScrollElements.splice(o, 1));
    }
    e.forEach((o) => {
      const n = this.scrollElementsToUpdate.find((l) => l.$el === o),
        r = this.scrollElements.find((l) => l.$el === o);
      n && this._unsubscribeElementUpdate(n),
        r &&
          (this.scrollElements = this.scrollElements.filter(
            (l) => l.id != r.id
          ));
    });
  }
  addScrollElements(t) {
    const e = t.querySelectorAll("[data-scroll]"),
      i = [];
    this.scrollElements.forEach((r) => {
      i.push(r.id);
    });
    const o = Math.max(...i, 0) + 1,
      n = this.toElementArray(e);
    this._subscribeScrollElements(n, o, !0);
  }
  _subscribeScrollElements(t, e = 0, i = !1) {
    for (let o = 0; o < t.length; o++) {
      const n = t[o],
        r = this._checkRafNeeded(n),
        l = new Y({
          $el: n,
          id: e + o,
          scrollOrientation: this.scrollOrientation,
          lenisInstance: this.lenisInstance,
          subscribeElementUpdateFn: this._subscribeElementUpdate.bind(this),
          unsubscribeElementUpdateFn: this._unsubscribeElementUpdate.bind(this),
          needRaf: r,
        });
      this.scrollElements.push(l),
        r
          ? (this.RAFScrollElements.push(l),
            i &&
              (this.IORafInstance.scrollElements.push(l),
              this.IORafInstance.observe(l.$el)))
          : (this.triggeredScrollElements.push(l),
            i &&
              (this.IOTriggerInstance.scrollElements.push(l),
              this.IOTriggerInstance.observe(l.$el)));
    }
  }
  _unsubscribeAllScrollElements() {
    for (const t of this.scrollElements) t.destroy();
    (this.scrollElements = []),
      (this.RAFScrollElements = []),
      (this.triggeredScrollElements = []),
      (this.scrollElementsToUpdate = []);
  }
  _subscribeElementUpdate(t) {
    this.scrollElementsToUpdate.push(t);
  }
  _unsubscribeElementUpdate(t) {
    this.scrollElementsToUpdate = this.scrollElementsToUpdate.filter(
      (e) => e.id != t.id
    );
  }
  toElementArray(t) {
    return Array.from(t);
  }
  _checkRafNeeded(t) {
    let e = [...q];
    const i = (o) => {
      e = e.filter((n) => n !== o);
    };
    if (t.dataset.scrollOffset) {
      if (
        t.dataset.scrollOffset
          .split(",")
          .map((o) => o.replace("%", "").trim())
          .join(",") !== "0,0"
      )
        return !0;
      i("scrollOffset");
    } else i("scrollOffset");
    if (t.dataset.scrollPosition) {
      if (t.dataset.scrollPosition.trim() !== "top,bottom") return !0;
      i("scrollPosition");
    } else i("scrollPosition");
    if (t.dataset.scrollSpeed && !isNaN(parseFloat(t.dataset.scrollSpeed)))
      return !0;
    i("scrollSpeed");
    for (const o of e) if (o in t.dataset) return !0;
    return !1;
  }
}
class G {
  constructor({
    lenisOptions: t = {},
    triggerRootMargin: e,
    rafRootMargin: i,
    autoStart: o = !0,
    scrollCallback: n = () => {},
    initCustomTicker: r,
    destroyCustomTicker: l,
  } = {}) {
    (this.rafPlaying = void 0),
      (this.lenisInstance = null),
      (this.coreInstance = null),
      (this.lenisOptions = void 0),
      (this.triggerRootMargin = void 0),
      (this.rafRootMargin = void 0),
      (this.rafInstance = void 0),
      (this.autoStart = void 0),
      (this.isTouchDevice = void 0),
      (this.initCustomTicker = void 0),
      (this.destroyCustomTicker = void 0),
      (this._onRenderBind = void 0),
      (this._onResizeBind = void 0),
      (this._onScrollToBind = void 0),
      (this._originalOnContentResize = void 0),
      (this._originalOnWrapperResize = void 0),
      (window.locomotiveScrollVersion = "5.0.0"),
      Object.assign(this, {
        lenisOptions: t,
        triggerRootMargin: e,
        rafRootMargin: i,
        autoStart: o,
        scrollCallback: n,
        initCustomTicker: r,
        destroyCustomTicker: l,
      }),
      (this._onRenderBind = this._onRender.bind(this)),
      (this._onScrollToBind = this._onScrollTo.bind(this)),
      (this._onResizeBind = this._onResize.bind(this)),
      (this.rafPlaying = !1),
      (this.isTouchDevice =
        "ontouchstart" in window || navigator.maxTouchPoints > 0),
      this._init();
  }
  _init() {
    (this.lenisInstance = new X(T({}, this.lenisOptions))),
      this.scrollCallback &&
        this.lenisInstance.on("scroll", this.scrollCallback),
      document.documentElement.setAttribute(
        "data-scroll-orientation",
        this.lenisInstance.options.orientation
      ),
      requestAnimationFrame(() => {
        (this.coreInstance = new j({
          $el: this.lenisInstance.rootElement,
          triggerRootMargin: this.triggerRootMargin,
          rafRootMargin: this.rafRootMargin,
          scrollOrientation: this.lenisInstance.options.orientation,
          lenisInstance: this.lenisInstance,
        })),
          this._bindEvents(),
          this.initCustomTicker && !this.destroyCustomTicker
            ? console.warn(
                "initCustomTicker callback is declared, but destroyCustomTicker is not. Please pay attention. It could cause trouble."
              )
            : !this.initCustomTicker &&
              this.destroyCustomTicker &&
              console.warn(
                "destroyCustomTicker callback is declared, but initCustomTicker is not. Please pay attention. It could cause trouble."
              ),
          this.autoStart && this.start();
      });
  }
  destroy() {
    var t;
    this.stop(),
      this._unbindEvents(),
      (t = this.lenisInstance) == null || t.destroy(),
      requestAnimationFrame(() => {
        var e;
        (e = this.coreInstance) == null || e.destroy();
      });
  }
  _bindEvents() {
    this._bindScrollToEvents(),
      this.lenisInstance &&
        ((this._originalOnContentResize =
          this.lenisInstance.dimensions.onContentResize.bind(
            this.lenisInstance.dimensions
          )),
        (this._originalOnWrapperResize =
          this.lenisInstance.dimensions.onWrapperResize.bind(
            this.lenisInstance.dimensions
          )),
        (this.lenisInstance.dimensions.onContentResize = () => {
          var t;
          (t = this._originalOnContentResize) == null || t.call(this),
            this._onResizeBind();
        }),
        (this.lenisInstance.dimensions.onWrapperResize = () => {
          var t;
          (t = this._originalOnWrapperResize) == null || t.call(this),
            this._onResizeBind();
        }));
  }
  _unbindEvents() {
    this._unbindScrollToEvents(),
      this.lenisInstance &&
        (this._originalOnContentResize &&
          (this.lenisInstance.dimensions.onContentResize =
            this._originalOnContentResize),
        this._originalOnWrapperResize &&
          (this.lenisInstance.dimensions.onWrapperResize =
            this._originalOnWrapperResize));
  }
  _bindScrollToEvents(t) {
    var e;
    const i = t || ((e = this.lenisInstance) == null ? void 0 : e.rootElement),
      o = i?.querySelectorAll("[data-scroll-to]");
    o?.length &&
      o.forEach((n) => {
        n.addEventListener("click", this._onScrollToBind, !1);
      });
  }
  _unbindScrollToEvents(t) {
    var e;
    const i = t || ((e = this.lenisInstance) == null ? void 0 : e.rootElement),
      o = i?.querySelectorAll("[data-scroll-to]");
    o?.length &&
      o.forEach((n) => {
        n.removeEventListener("click", this._onScrollToBind, !1);
      });
  }
  _onResize() {
    var t, e, i;
    (t = this.coreInstance) == null ||
      t.onResize({
        currentScroll:
          (e = (i = this.lenisInstance) == null ? void 0 : i.scroll) != null
            ? e
            : 0,
        smooth: !this.isTouchDevice,
      });
  }
  _onRender() {
    var t, e, i, o;
    (t = this.lenisInstance) == null || t.raf(Date.now()),
      (e = this.coreInstance) == null ||
        e.onRender({
          currentScroll:
            (i = (o = this.lenisInstance) == null ? void 0 : o.scroll) != null
              ? i
              : 0,
          smooth: !this.isTouchDevice,
        });
  }
  _onScrollTo(t) {
    var e, i;
    t.preventDefault();
    const o = (e = t.currentTarget) != null ? e : null;
    if (!o) return;
    const n = o.getAttribute("data-scroll-to-href") || o.getAttribute("href"),
      r = o.getAttribute("data-scroll-to-offset") || 0,
      l =
        o.getAttribute("data-scroll-to-duration") ||
        ((i = this.lenisInstance) == null ? void 0 : i.options.duration);
    n &&
      this.scrollTo(n, {
        offset: typeof r == "string" ? parseInt(r) : r,
        duration: typeof l == "string" ? parseInt(l) : l,
      });
  }
  start() {
    var t;
    this.rafPlaying ||
      ((t = this.lenisInstance) == null || t.start(),
      (this.rafPlaying = !0),
      this.initCustomTicker
        ? this.initCustomTicker(this._onRenderBind)
        : this._raf());
  }
  stop() {
    var t;
    this.rafPlaying &&
      ((t = this.lenisInstance) == null || t.stop(),
      (this.rafPlaying = !1),
      this.destroyCustomTicker
        ? this.destroyCustomTicker(this._onRenderBind)
        : this.rafInstance && cancelAnimationFrame(this.rafInstance));
  }
  removeScrollElements(t) {
    var e;
    t
      ? (this._unbindScrollToEvents(t),
        (e = this.coreInstance) == null || e.removeScrollElements(t))
      : console.error("Please provide a DOM Element as $oldContainer");
  }
  addScrollElements(t) {
    var e;
    t
      ? ((e = this.coreInstance) == null || e.addScrollElements(t),
        requestAnimationFrame(() => {
          this._bindScrollToEvents(t);
        }))
      : console.error("Please provide a DOM Element as $newContainer");
  }
  resize() {
    this._onResizeBind();
  }
  scrollTo(t, e) {
    var i;
    (i = this.lenisInstance) == null ||
      i.scrollTo(t, {
        offset: e?.offset,
        lerp: e?.lerp,
        duration: e?.duration,
        immediate: e?.immediate,
        lock: e?.lock,
        force: e?.force,
        easing: e?.easing,
        onComplete: e?.onComplete,
      });
  }
  _raf() {
    this._onRenderBind(),
      (this.rafInstance = requestAnimationFrame(() => this._raf()));
  }
}
class J {
  static locomotiveScroll;
  static init() {
    (this.locomotiveScroll = new G({
      scrollCallback({
        scroll: t,
        limit: e,
        velocity: i,
        direction: o,
        progress: n,
      }) {
        F.set({ scroll: t, limit: e, velocity: i, direction: o, progress: n });
      },
    })),
      this.locomotiveScroll?.lenisInstance?.options?.content?.addEventListener(
        "wheel",
        (t) => {
          t
            .composedPath()
            .some(
              (o) =>
                o?.classList?.contains("js-prevent-lenis") || o.id === "cc-main"
            ) && t.stopPropagation();
        }
      );
  }
  static destroy() {
    this.locomotiveScroll?.destroy();
  }
  static start() {
    this.locomotiveScroll?.start();
  }
  static stop() {
    this.locomotiveScroll?.stop();
  }
  static addScrollElements(t) {
    this.locomotiveScroll?.addScrollElements(t);
  }
  static removeScrollElements(t) {
    this.locomotiveScroll?.removeScrollElements(t);
  }
  static scrollTo(t, e) {
    this.locomotiveScroll?.scrollTo(t, e);
  }
}
export { J as S };
