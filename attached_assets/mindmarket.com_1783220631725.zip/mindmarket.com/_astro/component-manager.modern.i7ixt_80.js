import { a as y } from "./index.BSdFiPHn.js";
const p = () => {
    try {
      return typeof window < "u" && window.COMPONENT_MANAGER_DEBUG === !0;
    } catch {
      return !1;
    }
  },
  d = y(0),
  o = y([]);
let s = new Map(),
  l = [];
const M = (e, t) =>
    class extends e {
      constructor(...n) {
        if (
          (super(...n),
          (this.prototypeType = void 0),
          (this.prototypeType = t),
          !this.id)
        ) {
          const r = d.get() + 1;
          d.set(r), (this.id = `${this.prototypeType.toLowerCase()}-${r}`);
        }
        p() &&
          console.log(
            `🔧 ComponentManager: "${this.id}" (${this.prototypeType}) registered`
          );
      }
      connectedCallback() {
        typeof e.prototype.connectedCallback == "function" &&
          e.prototype.connectedCallback.call(this),
          o.set([...o.get(), this]),
          p() &&
            console.log(`✅ ComponentManager: "${this.id}" connected to DOM`);
      }
      disconnectedCallback() {
        typeof e.prototype.disconnectedCallback == "function" &&
          e.prototype.disconnectedCallback.call(this),
          o.set(o.get().filter((n) => n.id !== this.id)),
          p() &&
            console.log(
              `❌ ComponentManager: "${this.id}" disconnected from DOM`
            );
      }
    },
  f = (e) => o.get().find((t) => t.id === e),
  h = (e, t = []) => {
    const n = o.get();
    n !== l && (s.clear(), (l = n));
    const r = Array.isArray(t) ? t.length > 0 : t !== "";
    if (!r && s.has(e)) return s.get(e);
    let i = [];
    typeof t == "string"
      ? (i = [t])
      : Array.isArray(t)
      ? (i = t)
      : t instanceof HTMLElement && t.id && (i = [`#${t.id}`]);
    const a = n.filter(
      (c) => e === c.prototypeType && !i.some((g) => c.matches && c.matches(g))
    );
    return r || s.set(e, a), a;
  },
  m = (e) => o.get().filter(e),
  u = () => {
    const e = new Set(o.get().map((t) => t.prototypeType));
    return Array.from(e);
  },
  C = () => o.get().length;
(() => {
  if (typeof window < "u") {
    const e = {
      getById: (t) => f(t),
      getByPrototype: (t) => h(t),
      find: (t) => m(t),
      getRegisteredPrototypes: () => u(),
      getComponentCount: () => C(),
    };
    Object.defineProperty(e, "components", {
      get: () => o.get(),
      enumerable: !0,
      configurable: !1,
    }),
      (window.ComponentManager = e);
  }
})();
export { M as i };
