const e = () => navigator.userAgent.includes("Firefox");
export { e as i };
