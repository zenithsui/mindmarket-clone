function x(u, c, t) {
  var l, v, e;
  t === void 0 && (t = {});
  var f = (l = t.isImmediate) != null && l,
    o = (v = t.callback) != null && v,
    i = t.maxWait,
    s = Date.now(),
    n = [];
  function w() {
    if (i !== void 0) {
      var r = Date.now() - s;
      if (r + c >= i) return i - r;
    }
    return c;
  }
  var m = function () {
    var r = [].slice.call(arguments),
      a = this;
    return new Promise(function (d, D) {
      var T = f && e === void 0;
      if (
        (e !== void 0 && clearTimeout(e),
        (e = setTimeout(function () {
          if (((e = void 0), (s = Date.now()), !f)) {
            var h = u.apply(a, r);
            o && o(h),
              n.forEach(function (j) {
                return (0, j.resolve)(h);
              }),
              (n = []);
          }
        }, w())),
        T)
      ) {
        var p = u.apply(a, r);
        return o && o(p), d(p);
      }
      n.push({ resolve: d, reject: D });
    });
  };
  return (
    (m.cancel = function (r) {
      e !== void 0 && clearTimeout(e),
        n.forEach(function (a) {
          return (0, a.reject)(r);
        }),
        (n = []);
    }),
    m
  );
}
export { x as r };
