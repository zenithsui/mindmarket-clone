const p = "modulepreload",
  v = function (l) {
    return "/" + l;
  },
  d = {},
  y = function (f, c, E) {
    let i = Promise.resolve();
    if (c && c.length > 0) {
      let r = function (e) {
        return Promise.all(
          e.map((o) =>
            Promise.resolve(o).then(
              (s) => ({ status: "fulfilled", value: s }),
              (s) => ({ status: "rejected", reason: s })
            )
          )
        );
      };
      document.getElementsByTagName("link");
      const t = document.querySelector("meta[property=csp-nonce]"),
        u = t?.nonce || t?.getAttribute("nonce");
      i = r(
        c.map((e) => {
          if (((e = v(e)), e in d)) return;
          d[e] = !0;
          const o = e.endsWith(".css"),
            s = o ? '[rel="stylesheet"]' : "";
          if (document.querySelector(`link[href="${e}"]${s}`)) return;
          const n = document.createElement("link");
          if (
            ((n.rel = o ? "stylesheet" : p),
            o || (n.as = "script"),
            (n.crossOrigin = ""),
            (n.href = e),
            u && n.setAttribute("nonce", u),
            document.head.appendChild(n),
            o)
          )
            return new Promise((m, h) => {
              n.addEventListener("load", m),
                n.addEventListener("error", () =>
                  h(new Error(`Unable to preload CSS for ${e}`))
                );
            });
        })
      );
    }
    function a(r) {
      const t = new Event("vite:preloadError", { cancelable: !0 });
      if (((t.payload = r), window.dispatchEvent(t), !t.defaultPrevented))
        throw r;
    }
    return i.then((r) => {
      for (const t of r || []) t.status === "rejected" && a(t.reason);
      return f().catch(a);
    });
  };
export { y as _ };
