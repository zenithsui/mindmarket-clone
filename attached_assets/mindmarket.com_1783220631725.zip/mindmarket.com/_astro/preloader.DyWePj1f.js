import { a } from "./index.BSdFiPHn.js";
const r = a(1500);
export { r as $ };
