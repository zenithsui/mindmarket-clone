var kt = { exports: {} },
  Hn = kt.exports,
  wn;
function Gn() {
  return (
    wn ||
      ((wn = 1),
      (function (An, Kn) {
        (function (Dt, Re) {
          An.exports = Re();
        })(Hn, () =>
          (() => {
            var Qt = [
                ,
                (se, B, k) => {
                  k.r(B), k.d(B, { default: () => K });
                  var G = (() => {
                    var Y =
                      typeof document < "u" && document.currentScript
                        ? document.currentScript.src
                        : void 0;
                    return function (T = {}) {
                      var c = T,
                        me,
                        fe;
                      c.ready = new Promise((r, t) => {
                        (me = r), (fe = t);
                      });
                      function Le() {
                        function r(m) {
                          const p = a;
                          (o = t = 0),
                            (a = new Map()),
                            p.forEach((g) => {
                              try {
                                g(m);
                              } catch (v) {
                                console.error(v);
                              }
                            }),
                            this.xa(),
                            u && u.Ta();
                        }
                        let t = 0,
                          o = 0,
                          a = new Map(),
                          u = null,
                          l = null;
                        (this.requestAnimationFrame = function (m) {
                          t || (t = requestAnimationFrame(r.bind(this)));
                          const p = ++o;
                          return a.set(p, m), p;
                        }),
                          (this.cancelAnimationFrame = function (m) {
                            a.delete(m),
                              t &&
                                a.size == 0 &&
                                (cancelAnimationFrame(t), (t = 0));
                          }),
                          (this.Ra = function (m) {
                            l && (document.body.remove(l), (l = null)),
                              m ||
                                ((l = document.createElement("div")),
                                (l.style.backgroundColor = "black"),
                                (l.style.position = "fixed"),
                                (l.style.right = 0),
                                (l.style.top = 0),
                                (l.style.color = "white"),
                                (l.style.padding = "4px"),
                                (l.innerHTML = "RIVE FPS"),
                                (m = function (p) {
                                  l.innerHTML = "RIVE FPS " + p.toFixed(1);
                                }),
                                document.body.appendChild(l)),
                              (u = new (function () {
                                let p = 0,
                                  g = 0;
                                this.Ta = function () {
                                  var v = performance.now();
                                  g
                                    ? (++p,
                                      (v -= g),
                                      1e3 < v &&
                                        (m((1e3 * p) / v), (p = g = 0)))
                                    : ((g = v), (p = 0));
                                };
                              })());
                          }),
                          (this.Oa = function () {
                            l && (document.body.remove(l), (l = null)),
                              (u = null);
                          }),
                          (this.xa = function () {});
                      }
                      function ee(r) {
                        console.assert(!0);
                        const t = new Map();
                        let o = -1 / 0;
                        this.push = function (a) {
                          return (
                            (a = (a + ((1 << r) - 1)) >> r),
                            t.has(a) && clearTimeout(t.get(a)),
                            t.set(
                              a,
                              setTimeout(function () {
                                t.delete(a),
                                  t.length == 0
                                    ? (o = -1 / 0)
                                    : a == o &&
                                      ((o = Math.max(...t.keys())),
                                      console.assert(o < a));
                              }, 1e3)
                            ),
                            (o = Math.max(a, o)),
                            o << r
                          );
                        };
                      }
                      const te = c.onRuntimeInitialized;
                      c.onRuntimeInitialized = function () {
                        te && te();
                        let r = c.decodeAudio;
                        c.decodeAudio = function (u, l) {
                          (u = r(u)), l(u);
                        };
                        let t = c.decodeFont;
                        c.decodeFont = function (u, l) {
                          (u = t(u)), l(u);
                        };
                        const o = c.FileAssetLoader;
                        (c.ptrToAsset = (u) => {
                          let l = c.ptrToFileAsset(u);
                          return l.isImage
                            ? c.ptrToImageAsset(u)
                            : l.isFont
                            ? c.ptrToFontAsset(u)
                            : l.isAudio
                            ? c.ptrToAudioAsset(u)
                            : l;
                        }),
                          (c.CustomFileAssetLoader = o.extend(
                            "CustomFileAssetLoader",
                            {
                              __construct: function ({ loadContents: u }) {
                                this.__parent.__construct.call(this),
                                  (this.Ha = u);
                              },
                              loadContents: function (u, l) {
                                return (u = c.ptrToAsset(u)), this.Ha(u, l);
                              },
                            }
                          )),
                          (c.CDNFileAssetLoader = o.extend(
                            "CDNFileAssetLoader",
                            {
                              __construct: function () {
                                this.__parent.__construct.call(this);
                              },
                              loadContents: function (u) {
                                let l = c.ptrToAsset(u);
                                return (
                                  (u = l.cdnUuid),
                                  u === ""
                                    ? !1
                                    : ((function (m, p) {
                                        var g = new XMLHttpRequest();
                                        (g.responseType = "arraybuffer"),
                                          (g.onreadystatechange = function () {
                                            g.readyState == 4 &&
                                              g.status == 200 &&
                                              p(g);
                                          }),
                                          g.open("GET", m, !0),
                                          g.send(null);
                                      })(l.cdnBaseUrl + "/" + u, (m) => {
                                        l.decode(new Uint8Array(m.response));
                                      }),
                                      !0)
                                );
                              },
                            }
                          )),
                          (c.FallbackFileAssetLoader = o.extend(
                            "FallbackFileAssetLoader",
                            {
                              __construct: function () {
                                this.__parent.__construct.call(this),
                                  (this.wa = []);
                              },
                              addLoader: function (u) {
                                this.wa.push(u);
                              },
                              loadContents: function (u, l) {
                                for (let m of this.wa)
                                  if (m.loadContents(u, l)) return !0;
                                return !1;
                              },
                            }
                          ));
                        let a = c.computeAlignment;
                        c.computeAlignment = function (u, l, m, p, g = 1) {
                          return a.call(this, u, l, m, p, g);
                        };
                      };
                      const Ce =
                          "createConicGradient createImageData createLinearGradient createPattern createRadialGradient getContextAttributes getImageData getLineDash getTransform isContextLost isPointInPath isPointInStroke measureText".split(
                            " "
                          ),
                        ne = new (function () {
                          function r() {
                            if (!t) {
                              let H = function (X, E, oe) {
                                if (
                                  ((E = _.createShader(E)),
                                  _.shaderSource(E, oe),
                                  _.compileShader(E),
                                  (oe = _.getShaderInfoLog(E)),
                                  0 < (oe || "").length)
                                )
                                  throw oe;
                                _.attachShader(X, E);
                              };
                              var f = document.createElement("canvas"),
                                w = {
                                  alpha: 1,
                                  depth: 0,
                                  stencil: 0,
                                  antialias: 0,
                                  premultipliedAlpha: 1,
                                  preserveDrawingBuffer: 0,
                                  powerPreference: "high-performance",
                                  failIfMajorPerformanceCaveat: 0,
                                  enableExtensionsByDefault: 1,
                                  explicitSwapControl: 1,
                                  renderViaOffscreenBackBuffer: 1,
                                };
                              let _;
                              if (
                                /iPhone|iPad|iPod/i.test(navigator.userAgent)
                              ) {
                                if (
                                  ((_ = f.getContext("webgl", w)), (o = 1), !_)
                                )
                                  return (
                                    console.log(
                                      "No WebGL support. Image mesh will not be drawn."
                                    ),
                                    !1
                                  );
                              } else if ((_ = f.getContext("webgl2", w))) o = 2;
                              else if ((_ = f.getContext("webgl", w))) o = 1;
                              else
                                return (
                                  console.log(
                                    "No WebGL support. Image mesh will not be drawn."
                                  ),
                                  !1
                                );
                              if (
                                ((_ = new Proxy(_, {
                                  get(X, E) {
                                    if (X.isContextLost()) {
                                      if (
                                        (g ||
                                          (console.error(
                                            "Cannot render the mesh because the GL Context was lost. Tried to invoke ",
                                            E
                                          ),
                                          (g = !0)),
                                        typeof X[E] == "function")
                                      )
                                        return function () {};
                                    } else
                                      return typeof X[E] == "function"
                                        ? function (...oe) {
                                            return X[E].apply(X, oe);
                                          }
                                        : X[E];
                                  },
                                  set(X, E, oe) {
                                    if (X.isContextLost())
                                      g ||
                                        (console.error(
                                          "Cannot render the mesh because the GL Context was lost. Tried to set property " +
                                            E
                                        ),
                                        (g = !0));
                                    else return (X[E] = oe), !0;
                                  },
                                })),
                                (a = Math.min(
                                  _.getParameter(_.MAX_RENDERBUFFER_SIZE),
                                  _.getParameter(_.MAX_TEXTURE_SIZE)
                                )),
                                (f = _.createProgram()),
                                H(
                                  f,
                                  _.VERTEX_SHADER,
                                  `attribute vec2 vertex;
                attribute vec2 uv;
                uniform vec4 mat;
                uniform vec2 translate;
                varying vec2 st;
                void main() {
                    st = uv;
                    gl_Position = vec4(mat2(mat) * vertex + translate, 0, 1);
                }`
                                ),
                                H(
                                  f,
                                  _.FRAGMENT_SHADER,
                                  `precision highp float;
                uniform sampler2D image;
                varying vec2 st;
                void main() {
                    gl_FragColor = texture2D(image, st);
                }`
                                ),
                                _.bindAttribLocation(f, 0, "vertex"),
                                _.bindAttribLocation(f, 1, "uv"),
                                _.linkProgram(f),
                                (w = _.getProgramInfoLog(f)),
                                0 < (w || "").trim().length)
                              )
                                throw w;
                              (u = _.getUniformLocation(f, "mat")),
                                (l = _.getUniformLocation(f, "translate")),
                                _.useProgram(f),
                                _.bindBuffer(_.ARRAY_BUFFER, _.createBuffer()),
                                _.enableVertexAttribArray(0),
                                _.enableVertexAttribArray(1),
                                _.bindBuffer(
                                  _.ELEMENT_ARRAY_BUFFER,
                                  _.createBuffer()
                                ),
                                _.uniform1i(
                                  _.getUniformLocation(f, "image"),
                                  0
                                ),
                                _.pixelStorei(
                                  _.UNPACK_PREMULTIPLY_ALPHA_WEBGL,
                                  !0
                                ),
                                (t = _);
                            }
                            return !0;
                          }
                          let t = null,
                            o = 0,
                            a = 0,
                            u = null,
                            l = null,
                            m = 0,
                            p = 0,
                            g = !1;
                          r(),
                            (this.eb = function () {
                              return r(), a;
                            }),
                            (this.Ma = function (f) {
                              t.deleteTexture && t.deleteTexture(f);
                            }),
                            (this.La = function (f) {
                              if (!r()) return null;
                              const w = t.createTexture();
                              return w
                                ? (t.bindTexture(t.TEXTURE_2D, w),
                                  t.texImage2D(
                                    t.TEXTURE_2D,
                                    0,
                                    t.RGBA,
                                    t.RGBA,
                                    t.UNSIGNED_BYTE,
                                    f
                                  ),
                                  t.texParameteri(
                                    t.TEXTURE_2D,
                                    t.TEXTURE_WRAP_S,
                                    t.CLAMP_TO_EDGE
                                  ),
                                  t.texParameteri(
                                    t.TEXTURE_2D,
                                    t.TEXTURE_WRAP_T,
                                    t.CLAMP_TO_EDGE
                                  ),
                                  t.texParameteri(
                                    t.TEXTURE_2D,
                                    t.TEXTURE_MAG_FILTER,
                                    t.LINEAR
                                  ),
                                  o == 2
                                    ? (t.texParameteri(
                                        t.TEXTURE_2D,
                                        t.TEXTURE_MIN_FILTER,
                                        t.LINEAR_MIPMAP_LINEAR
                                      ),
                                      t.generateMipmap(t.TEXTURE_2D))
                                    : t.texParameteri(
                                        t.TEXTURE_2D,
                                        t.TEXTURE_MIN_FILTER,
                                        t.LINEAR
                                      ),
                                  w)
                                : null;
                            });
                          const v = new ee(8),
                            A = new ee(8),
                            P = new ee(10),
                            S = new ee(10);
                          (this.Qa = function (f, w, _, H, X) {
                            if (r()) {
                              var E = v.push(f),
                                oe = A.push(w);
                              if (t.canvas) {
                                (t.canvas.width != E ||
                                  t.canvas.height != oe) &&
                                  ((t.canvas.width = E),
                                  (t.canvas.height = oe)),
                                  t.viewport(0, oe - w, f, w),
                                  t.disable(t.SCISSOR_TEST),
                                  t.clearColor(0, 0, 0, 0),
                                  t.clear(t.COLOR_BUFFER_BIT),
                                  t.enable(t.SCISSOR_TEST),
                                  _.sort((z, Ge) => Ge.Ba - z.Ba),
                                  (E = P.push(H)),
                                  m != E &&
                                    (t.bufferData(
                                      t.ARRAY_BUFFER,
                                      8 * E,
                                      t.DYNAMIC_DRAW
                                    ),
                                    (m = E)),
                                  (E = 0);
                                for (var Ae of _)
                                  t.bufferSubData(t.ARRAY_BUFFER, E, Ae.ia),
                                    (E += 4 * Ae.ia.length);
                                console.assert(E == 4 * H);
                                for (var He of _)
                                  t.bufferSubData(t.ARRAY_BUFFER, E, He.Ea),
                                    (E += 4 * He.Ea.length);
                                console.assert(E == 8 * H),
                                  (E = S.push(X)),
                                  p != E &&
                                    (t.bufferData(
                                      t.ELEMENT_ARRAY_BUFFER,
                                      2 * E,
                                      t.DYNAMIC_DRAW
                                    ),
                                    (p = E)),
                                  (Ae = 0);
                                for (var st of _)
                                  t.bufferSubData(
                                    t.ELEMENT_ARRAY_BUFFER,
                                    Ae,
                                    st.indices
                                  ),
                                    (Ae += 2 * st.indices.length);
                                console.assert(Ae == 2 * X),
                                  (st = 0),
                                  (He = !0),
                                  (E = Ae = 0);
                                for (const z of _) {
                                  z.image.da != st &&
                                    (t.bindTexture(
                                      t.TEXTURE_2D,
                                      z.image.ca || null
                                    ),
                                    (st = z.image.da)),
                                    z.hb
                                      ? (t.scissor(
                                          z.na,
                                          oe - z.oa - z.va,
                                          z.sb,
                                          z.va
                                        ),
                                        (He = !0))
                                      : He &&
                                        (t.scissor(0, oe - w, f, w), (He = !1)),
                                    (_ = 2 / f);
                                  const Ge = -2 / w;
                                  t.uniform4f(
                                    u,
                                    z.N[0] * _ * z.X,
                                    z.N[1] * Ge * z.Y,
                                    z.N[2] * _ * z.X,
                                    z.N[3] * Ge * z.Y
                                  ),
                                    t.uniform2f(
                                      l,
                                      z.N[4] * _ * z.X +
                                        _ * (z.na - z.fb * z.X) -
                                        1,
                                      z.N[5] * Ge * z.Y +
                                        Ge * (z.oa - z.gb * z.Y) +
                                        1
                                    ),
                                    t.vertexAttribPointer(
                                      0,
                                      2,
                                      t.FLOAT,
                                      !1,
                                      0,
                                      E
                                    ),
                                    t.vertexAttribPointer(
                                      1,
                                      2,
                                      t.FLOAT,
                                      !1,
                                      0,
                                      E + 4 * H
                                    ),
                                    t.drawElements(
                                      t.TRIANGLES,
                                      z.indices.length,
                                      t.UNSIGNED_SHORT,
                                      Ae
                                    ),
                                    (E += 4 * z.ia.length),
                                    (Ae += 2 * z.indices.length);
                                }
                                console.assert(E == 4 * H),
                                  console.assert(Ae == 2 * X);
                              }
                            }
                          }),
                            (this.canvas = function () {
                              return r() && t.canvas;
                            });
                        })(),
                        ue = c.onRuntimeInitialized;
                      c.onRuntimeInitialized = function () {
                        function r(b) {
                          switch (b) {
                            case v.srcOver:
                              return "source-over";
                            case v.screen:
                              return "screen";
                            case v.overlay:
                              return "overlay";
                            case v.darken:
                              return "darken";
                            case v.lighten:
                              return "lighten";
                            case v.colorDodge:
                              return "color-dodge";
                            case v.colorBurn:
                              return "color-burn";
                            case v.hardLight:
                              return "hard-light";
                            case v.softLight:
                              return "soft-light";
                            case v.difference:
                              return "difference";
                            case v.exclusion:
                              return "exclusion";
                            case v.multiply:
                              return "multiply";
                            case v.hue:
                              return "hue";
                            case v.saturation:
                              return "saturation";
                            case v.color:
                              return "color";
                            case v.luminosity:
                              return "luminosity";
                          }
                        }
                        function t(b) {
                          return (
                            "rgba(" +
                            ((16711680 & b) >>> 16) +
                            "," +
                            ((65280 & b) >>> 8) +
                            "," +
                            ((255 & b) >>> 0) +
                            "," +
                            ((4278190080 & b) >>> 24) / 255 +
                            ")"
                          );
                        }
                        function o() {
                          0 < oe.length &&
                            (ne.Qa(E.drawWidth(), E.drawHeight(), oe, Ae, He),
                            (oe = []),
                            (He = Ae = 0),
                            E.reset(512, 512));
                          for (const b of X) {
                            for (const C of b.u) C();
                            b.u = [];
                          }
                          X.clear();
                        }
                        ue && ue();
                        var a = c.RenderPaintStyle;
                        const u = c.RenderPath,
                          l = c.RenderPaint,
                          m = c.Renderer,
                          p = c.StrokeCap,
                          g = c.StrokeJoin,
                          v = c.BlendMode,
                          A = a.fill,
                          P = a.stroke,
                          S = c.FillRule.evenOdd;
                        let f = 1;
                        var w = c.RenderImage.extend("CanvasRenderImage", {
                            __construct: function ({ R: b, W: C } = {}) {
                              this.__parent.__construct.call(this),
                                (this.da = f),
                                (f = (f + 1) & 2147483647 || 1),
                                (this.R = b),
                                (this.W = C);
                            },
                            __destruct: function () {
                              this.ca &&
                                (ne.Ma(this.ca), URL.revokeObjectURL(this.la)),
                                this.__parent.__destruct.call(this);
                            },
                            decode: function (b) {
                              var C = this;
                              C.W && C.W(C);
                              var D = new Image();
                              (C.la = URL.createObjectURL(
                                new Blob([b], { type: "image/png" })
                              )),
                                (D.onload = function () {
                                  (C.Ga = D),
                                    (C.ca = ne.La(D)),
                                    C.size(D.width, D.height),
                                    C.R && C.R(C);
                                }),
                                (D.src = C.la);
                            },
                          }),
                          _ = u.extend("CanvasRenderPath", {
                            __construct: function () {
                              this.__parent.__construct.call(this),
                                (this.F = new Path2D());
                            },
                            rewind: function () {
                              this.F = new Path2D();
                            },
                            addPath: function (b, C, D, $, x, U, J) {
                              var Q = this.F,
                                $e = Q.addPath;
                              b = b.F;
                              const be = new DOMMatrix();
                              (be.a = C),
                                (be.b = D),
                                (be.c = $),
                                (be.d = x),
                                (be.e = U),
                                (be.f = J),
                                $e.call(Q, b, be);
                            },
                            fillRule: function (b) {
                              this.ka = b;
                            },
                            moveTo: function (b, C) {
                              this.F.moveTo(b, C);
                            },
                            lineTo: function (b, C) {
                              this.F.lineTo(b, C);
                            },
                            cubicTo: function (b, C, D, $, x, U) {
                              this.F.bezierCurveTo(b, C, D, $, x, U);
                            },
                            close: function () {
                              this.F.closePath();
                            },
                          }),
                          H = l.extend("CanvasRenderPaint", {
                            color: function (b) {
                              this.ma = t(b);
                            },
                            thickness: function (b) {
                              this.Ja = b;
                            },
                            join: function (b) {
                              switch (b) {
                                case g.miter:
                                  this.ba = "miter";
                                  break;
                                case g.round:
                                  this.ba = "round";
                                  break;
                                case g.bevel:
                                  this.ba = "bevel";
                              }
                            },
                            cap: function (b) {
                              switch (b) {
                                case p.butt:
                                  this.aa = "butt";
                                  break;
                                case p.round:
                                  this.aa = "round";
                                  break;
                                case p.square:
                                  this.aa = "square";
                              }
                            },
                            style: function (b) {
                              this.Ia = b;
                            },
                            blendMode: function (b) {
                              this.Fa = r(b);
                            },
                            clearGradient: function () {
                              this.P = null;
                            },
                            linearGradient: function (b, C, D, $) {
                              this.P = { Ca: b, Da: C, qa: D, ra: $, ga: [] };
                            },
                            radialGradient: function (b, C, D, $) {
                              this.P = {
                                Ca: b,
                                Da: C,
                                qa: D,
                                ra: $,
                                ga: [],
                                bb: !0,
                              };
                            },
                            addStop: function (b, C) {
                              this.P.ga.push({ color: b, stop: C });
                            },
                            completeGradient: function () {},
                            draw: function (b, C, D) {
                              let $ = this.Ia;
                              var x = this.ma,
                                U = this.P;
                              if (
                                ((b.globalCompositeOperation = this.Fa),
                                U != null)
                              ) {
                                x = U.Ca;
                                var J = U.Da;
                                const $e = U.qa;
                                var Q = U.ra;
                                const be = U.ga;
                                U.bb
                                  ? ((U = $e - x),
                                    (Q -= J),
                                    (x = b.createRadialGradient(
                                      x,
                                      J,
                                      0,
                                      x,
                                      J,
                                      Math.sqrt(U * U + Q * Q)
                                    )))
                                  : (x = b.createLinearGradient(x, J, $e, Q));
                                for (let Ve = 0, _e = be.length; Ve < _e; Ve++)
                                  (J = be[Ve]),
                                    x.addColorStop(J.stop, t(J.color));
                                (this.ma = x), (this.P = null);
                              }
                              switch ($) {
                                case P:
                                  (b.strokeStyle = x),
                                    (b.lineWidth = this.Ja),
                                    (b.lineCap = this.aa),
                                    (b.lineJoin = this.ba),
                                    b.stroke(C);
                                  break;
                                case A:
                                  (b.fillStyle = x), b.fill(C, D);
                              }
                            },
                          });
                        const X = new Set();
                        let E = null,
                          oe = [],
                          Ae = 0,
                          He = 0;
                        var st = (c.CanvasRenderer = m.extend("Renderer", {
                          __construct: function (b) {
                            this.__parent.__construct.call(this),
                              (this.D = [1, 0, 0, 1, 0, 0]),
                              (this.o = b.getContext("2d")),
                              (this.ja = b),
                              (this.u = []);
                          },
                          save: function () {
                            this.D.push(...this.D.slice(this.D.length - 6)),
                              this.u.push(this.o.save.bind(this.o));
                          },
                          restore: function () {
                            const b = this.D.length - 6;
                            if (6 > b)
                              throw "restore() called without matching save().";
                            this.D.splice(b),
                              this.u.push(this.o.restore.bind(this.o));
                          },
                          transform: function (b, C, D, $, x, U) {
                            const J = this.D,
                              Q = J.length - 6;
                            J.splice(
                              Q,
                              6,
                              J[Q] * b + J[Q + 2] * C,
                              J[Q + 1] * b + J[Q + 3] * C,
                              J[Q] * D + J[Q + 2] * $,
                              J[Q + 1] * D + J[Q + 3] * $,
                              J[Q] * x + J[Q + 2] * U + J[Q + 4],
                              J[Q + 1] * x + J[Q + 3] * U + J[Q + 5]
                            ),
                              this.u.push(
                                this.o.transform.bind(this.o, b, C, D, $, x, U)
                              );
                          },
                          rotate: function (b) {
                            const C = Math.sin(b);
                            (b = Math.cos(b)),
                              this.transform(b, C, -C, b, 0, 0);
                          },
                          _drawPath: function (b, C) {
                            this.u.push(
                              C.draw.bind(
                                C,
                                this.o,
                                b.F,
                                b.ka === S ? "evenodd" : "nonzero"
                              )
                            );
                          },
                          _drawRiveImage: function (b, C, D, $) {
                            var x = b.Ga;
                            if (x) {
                              var U = this.o,
                                J = r(D);
                              this.u.push(function () {
                                (U.globalCompositeOperation = J),
                                  (U.globalAlpha = $),
                                  U.drawImage(x, 0, 0),
                                  (U.globalAlpha = 1);
                              });
                            }
                          },
                          _getMatrix: function (b) {
                            const C = this.D,
                              D = C.length - 6;
                            for (let $ = 0; 6 > $; ++$) b[$] = C[D + $];
                          },
                          _drawImageMesh: function (
                            b,
                            C,
                            D,
                            $,
                            x,
                            U,
                            J,
                            Q,
                            $e,
                            be,
                            Ve
                          ) {
                            C = this.o.canvas.width;
                            var _e = this.o.canvas.height;
                            const mn = be - Q,
                              gn = Ve - $e;
                            (Q = Math.max(Q, 0)),
                              ($e = Math.max($e, 0)),
                              (be = Math.min(be, C)),
                              (Ve = Math.min(Ve, _e));
                            const bt = be - Q,
                              _t = Ve - $e;
                            if (
                              (console.assert(bt <= Math.min(mn, C)),
                              console.assert(_t <= Math.min(gn, _e)),
                              !(0 >= bt || 0 >= _t))
                            ) {
                              (be = bt < mn || _t < gn), (C = Ve = 1);
                              var ut = Math.ceil(bt * Ve),
                                lt = Math.ceil(_t * C);
                              (_e = ne.eb()),
                                ut > _e && ((Ve *= _e / ut), (ut = _e)),
                                lt > _e && ((C *= _e / lt), (lt = _e)),
                                E ||
                                  ((E = new c.DynamicRectanizer(_e)),
                                  E.reset(512, 512)),
                                (_e = E.addRect(ut, lt)),
                                0 > _e &&
                                  (o(),
                                  X.add(this),
                                  (_e = E.addRect(ut, lt)),
                                  console.assert(0 <= _e));
                              var yn = _e & 65535,
                                bn = _e >> 16;
                              oe.push({
                                N: this.D.slice(this.D.length - 6),
                                image: b,
                                na: yn,
                                oa: bn,
                                fb: Q,
                                gb: $e,
                                sb: ut,
                                va: lt,
                                X: Ve,
                                Y: C,
                                ia: new Float32Array(x),
                                Ea: new Float32Array(U),
                                indices: new Uint16Array(J),
                                hb: be,
                                Ba: (b.da << 1) | (be ? 1 : 0),
                              }),
                                (Ae += x.length),
                                (He += J.length);
                              var pt = this.o,
                                Xn = r(D);
                              this.u.push(function () {
                                pt.save(),
                                  pt.resetTransform(),
                                  (pt.globalCompositeOperation = Xn),
                                  (pt.globalAlpha = $);
                                const _n = ne.canvas();
                                _n &&
                                  pt.drawImage(
                                    _n,
                                    yn,
                                    bn,
                                    ut,
                                    lt,
                                    Q,
                                    $e,
                                    bt,
                                    _t
                                  ),
                                  pt.restore();
                              });
                            }
                          },
                          _clipPath: function (b) {
                            this.u.push(
                              this.o.clip.bind(
                                this.o,
                                b.F,
                                b.ka === S ? "evenodd" : "nonzero"
                              )
                            );
                          },
                          clear: function () {
                            X.add(this),
                              this.u.push(
                                this.o.clearRect.bind(
                                  this.o,
                                  0,
                                  0,
                                  this.ja.width,
                                  this.ja.height
                                )
                              );
                          },
                          flush: function () {},
                          translate: function (b, C) {
                            this.transform(1, 0, 0, 1, b, C);
                          },
                        }));
                        (c.makeRenderer = function (b) {
                          const C = new st(b),
                            D = C.o;
                          return new Proxy(C, {
                            get($, x) {
                              if (typeof $[x] == "function")
                                return function (...U) {
                                  return $[x].apply($, U);
                                };
                              if (typeof D[x] == "function") {
                                if (-1 < Ce.indexOf(x))
                                  throw Error(
                                    "RiveException: Method call to '" +
                                      x +
                                      "()' is not allowed, as the renderer cannot immediately pass through the return                 values of any canvas 2d context methods."
                                  );
                                return function (...U) {
                                  C.u.push(D[x].bind(D, ...U));
                                };
                              }
                              return $[x];
                            },
                            set($, x, U) {
                              if (x in D)
                                return (
                                  C.u.push(() => {
                                    D[x] = U;
                                  }),
                                  !0
                                );
                            },
                          });
                        }),
                          (c.decodeImage = function (b, C) {
                            new w({ R: C }).decode(b);
                          }),
                          (c.renderFactory = {
                            makeRenderPaint: function () {
                              return new H();
                            },
                            makeRenderPath: function () {
                              return new _();
                            },
                            makeRenderImage: function () {
                              let b = Ge;
                              return new w({
                                W: () => {
                                  b.total++;
                                },
                                R: () => {
                                  if ((b.loaded++, b.loaded === b.total)) {
                                    const C = b.ready;
                                    C && (C(), (b.ready = null));
                                  }
                                },
                              });
                            },
                          });
                        let z = c.load,
                          Ge = null;
                        c.load = function (b, C, D = !0) {
                          const $ = new c.FallbackFileAssetLoader();
                          return (
                            C !== void 0 && $.addLoader(C),
                            D &&
                              ((C = new c.CDNFileAssetLoader()),
                              $.addLoader(C)),
                            new Promise(function (x) {
                              let U = null;
                              (Ge = {
                                total: 0,
                                loaded: 0,
                                ready: function () {
                                  x(U);
                                },
                              }),
                                (U = z(b, $)),
                                Ge.total == 0 && x(U);
                            })
                          );
                        };
                        let Yn = c.RendererWrapper.prototype.align;
                        (c.RendererWrapper.prototype.align = function (
                          b,
                          C,
                          D,
                          $,
                          x = 1
                        ) {
                          Yn.call(this, b, C, D, $, x);
                        }),
                          (a = new Le()),
                          (c.requestAnimationFrame =
                            a.requestAnimationFrame.bind(a)),
                          (c.cancelAnimationFrame =
                            a.cancelAnimationFrame.bind(a)),
                          (c.enableFPSCounter = a.Ra.bind(a)),
                          (c.disableFPSCounter = a.Oa),
                          (a.xa = o),
                          (c.resolveAnimationFrame = o),
                          (c.cleanup = function () {
                            E && E.delete();
                          });
                      };
                      var ge = Object.assign({}, c),
                        Te = "./this.program",
                        rt = typeof window == "object",
                        R = typeof importScripts == "function",
                        M = "",
                        I,
                        O;
                      (rt || R) &&
                        (R
                          ? (M = self.location.href)
                          : typeof document < "u" &&
                            document.currentScript &&
                            (M = document.currentScript.src),
                        Y && (M = Y),
                        M.indexOf("blob:") !== 0
                          ? (M = M.substr(
                              0,
                              M.replace(/[?#].*/, "").lastIndexOf("/") + 1
                            ))
                          : (M = ""),
                        R &&
                          (O = (r) => {
                            var t = new XMLHttpRequest();
                            return (
                              t.open("GET", r, !1),
                              (t.responseType = "arraybuffer"),
                              t.send(null),
                              new Uint8Array(t.response)
                            );
                          }),
                        (I = (r, t, o) => {
                          var a = new XMLHttpRequest();
                          a.open("GET", r, !0),
                            (a.responseType = "arraybuffer"),
                            (a.onload = () => {
                              a.status == 200 || (a.status == 0 && a.response)
                                ? t(a.response)
                                : o();
                            }),
                            (a.onerror = o),
                            a.send(null);
                        }));
                      var he = c.print || console.log.bind(console),
                        ye = c.printErr || console.error.bind(console);
                      Object.assign(c, ge),
                        (ge = null),
                        c.thisProgram && (Te = c.thisProgram);
                      var we;
                      c.wasmBinary && (we = c.wasmBinary),
                        c.noExitRuntime,
                        typeof WebAssembly != "object" &&
                          ft("no native wasm support detected");
                      var Ke,
                        ae,
                        ct = !1,
                        ke,
                        le,
                        Pe,
                        De,
                        re,
                        q,
                        Ye,
                        Z;
                      function Oe() {
                        var r = Ke.buffer;
                        (c.HEAP8 = ke = new Int8Array(r)),
                          (c.HEAP16 = Pe = new Int16Array(r)),
                          (c.HEAP32 = re = new Int32Array(r)),
                          (c.HEAPU8 = le = new Uint8Array(r)),
                          (c.HEAPU16 = De = new Uint16Array(r)),
                          (c.HEAPU32 = q = new Uint32Array(r)),
                          (c.HEAPF32 = Ye = new Float32Array(r)),
                          (c.HEAPF64 = Z = new Float64Array(r));
                      }
                      var ce,
                        Je = [],
                        it = [],
                        Qe = [];
                      function at() {
                        var r = c.preRun.shift();
                        Je.unshift(r);
                      }
                      var Ee = 0,
                        Ue = null;
                      function ft(r) {
                        throw (
                          (c.onAbort && c.onAbort(r),
                          (r = "Aborted(" + r + ")"),
                          ye(r),
                          (ct = !0),
                          (r = new WebAssembly.RuntimeError(
                            r + ". Build with -sASSERTIONS for more info."
                          )),
                          fe(r),
                          r)
                        );
                      }
                      function vt(r) {
                        return r.startsWith(
                          "data:application/octet-stream;base64,"
                        );
                      }
                      var qe;
                      if (((qe = "canvas_advanced.wasm"), !vt(qe))) {
                        var wt = qe;
                        qe = c.locateFile ? c.locateFile(wt, M) : M + wt;
                      }
                      function Se(r) {
                        if (r == qe && we) return new Uint8Array(we);
                        if (O) return O(r);
                        throw "both async and sync fetching of the wasm failed";
                      }
                      function Bt(r) {
                        if (!we && (rt || R)) {
                          if (
                            typeof fetch == "function" &&
                            !r.startsWith("file://")
                          )
                            return fetch(r, { credentials: "same-origin" })
                              .then((t) => {
                                if (!t.ok)
                                  throw (
                                    "failed to load wasm binary file at '" +
                                    r +
                                    "'"
                                  );
                                return t.arrayBuffer();
                              })
                              .catch(() => Se(r));
                          if (I)
                            return new Promise((t, o) => {
                              I(r, (a) => t(new Uint8Array(a)), o);
                            });
                        }
                        return Promise.resolve().then(() => Se(r));
                      }
                      function At(r, t, o) {
                        return Bt(r)
                          .then((a) => WebAssembly.instantiate(a, t))
                          .then((a) => a)
                          .then(o, (a) => {
                            ye("failed to asynchronously prepare wasm: " + a),
                              ft(a);
                          });
                      }
                      function Nt(r, t) {
                        var o = qe;
                        return we ||
                          typeof WebAssembly.instantiateStreaming !=
                            "function" ||
                          vt(o) ||
                          o.startsWith("file://") ||
                          typeof fetch != "function"
                          ? At(o, r, t)
                          : fetch(o, { credentials: "same-origin" }).then((a) =>
                              WebAssembly.instantiateStreaming(a, r).then(
                                t,
                                function (u) {
                                  return (
                                    ye("wasm streaming compile failed: " + u),
                                    ye(
                                      "falling back to ArrayBuffer instantiation"
                                    ),
                                    At(o, r, t)
                                  );
                                }
                              )
                            );
                      }
                      var mt = (r) => {
                        for (; 0 < r.length; ) r.shift()(c);
                      };
                      function i(r) {
                        if (r === void 0) return "_unknown";
                        r = r.replace(/[^a-zA-Z0-9_]/g, "$");
                        var t = r.charCodeAt(0);
                        return 48 <= t && 57 >= t ? `_${r}` : r;
                      }
                      function e(r, t) {
                        return (
                          (r = i(r)),
                          {
                            [r]: function () {
                              return t.apply(this, arguments);
                            },
                          }[r]
                        );
                      }
                      function n() {
                        (this.G = [void 0]), (this.ta = []);
                      }
                      var s = new n(),
                        h = void 0;
                      function d(r) {
                        throw new h(r);
                      }
                      var y = (r) => (
                          r || d("Cannot use deleted val. handle = " + r),
                          s.get(r).value
                        ),
                        L = (r) => {
                          switch (r) {
                            case void 0:
                              return 1;
                            case null:
                              return 2;
                            case !0:
                              return 3;
                            case !1:
                              return 4;
                            default:
                              return s.Za({ Aa: 1, value: r });
                          }
                        };
                      function W(r) {
                        var t = Error,
                          o = e(r, function (a) {
                            (this.name = r),
                              (this.message = a),
                              (a = Error(a).stack),
                              a !== void 0 &&
                                (this.stack =
                                  this.toString() +
                                  `
` +
                                  a.replace(/^Error(:[^\n]*)?\n/, ""));
                          });
                        return (
                          (o.prototype = Object.create(t.prototype)),
                          (o.prototype.constructor = o),
                          (o.prototype.toString = function () {
                            return this.message === void 0
                              ? this.name
                              : `${this.name}: ${this.message}`;
                          }),
                          o
                        );
                      }
                      var F = void 0,
                        V = void 0;
                      function j(r) {
                        for (var t = ""; le[r]; ) t += V[le[r++]];
                        return t;
                      }
                      var de = [];
                      function ie() {
                        for (; de.length; ) {
                          var r = de.pop();
                          (r.g.M = !1), r.delete();
                        }
                      }
                      var Fe = void 0,
                        pe = {};
                      function Ie(r, t) {
                        for (
                          t === void 0 && d("ptr should not be undefined");
                          r.l;

                        )
                          (t = r.S(t)), (r = r.l);
                        return t;
                      }
                      var ve = {};
                      function je(r) {
                        r = pn(r);
                        var t = j(r);
                        return nt(r), t;
                      }
                      function xe(r, t) {
                        var o = ve[r];
                        return (
                          o === void 0 && d(t + " has unknown type " + je(r)), o
                        );
                      }
                      function Be() {}
                      var Ne = !1;
                      function ze(r) {
                        --r.count.value,
                          r.count.value === 0 &&
                            (r.s ? r.A.H(r.s) : r.j.h.H(r.i));
                      }
                      function N(r, t, o) {
                        return t === o
                          ? r
                          : o.l === void 0
                          ? null
                          : ((r = N(r, t, o.l)), r === null ? null : o.Pa(r));
                      }
                      var Ze = {};
                      function Cn(r, t) {
                        return (t = Ie(r, t)), pe[t];
                      }
                      var qt = void 0;
                      function Ct(r) {
                        throw new qt(r);
                      }
                      function Mt(r, t) {
                        return (
                          (t.j && t.i) ||
                            Ct("makeClassHandle requires ptr and ptrType"),
                          !!t.A != !!t.s &&
                            Ct(
                              "Both smartPtrType and smartPtr must be specified"
                            ),
                          (t.count = { value: 1 }),
                          ht(Object.create(r, { g: { value: t } }))
                        );
                      }
                      function ht(r) {
                        return typeof FinalizationRegistry > "u"
                          ? ((ht = (t) => t), r)
                          : ((Ne = new FinalizationRegistry((t) => {
                              ze(t.g);
                            })),
                            (ht = (t) => {
                              var o = t.g;
                              return o.s && Ne.register(t, { g: o }, t), t;
                            }),
                            (Be = (t) => {
                              Ne.unregister(t);
                            }),
                            ht(r));
                      }
                      var It = {};
                      function gt(r) {
                        for (; r.length; ) {
                          var t = r.pop();
                          r.pop()(t);
                        }
                      }
                      function yt(r) {
                        return this.fromWireType(re[r >> 2]);
                      }
                      var dt = {},
                        Rt = {};
                      function We(r, t, o) {
                        function a(p) {
                          (p = o(p)),
                            p.length !== r.length &&
                              Ct("Mismatched type converter count");
                          for (var g = 0; g < r.length; ++g) Xe(r[g], p[g]);
                        }
                        r.forEach(function (p) {
                          Rt[p] = t;
                        });
                        var u = Array(t.length),
                          l = [],
                          m = 0;
                        t.forEach((p, g) => {
                          ve.hasOwnProperty(p)
                            ? (u[g] = ve[p])
                            : (l.push(p),
                              dt.hasOwnProperty(p) || (dt[p] = []),
                              dt[p].push(() => {
                                (u[g] = ve[p]), ++m, m === l.length && a(u);
                              }));
                        }),
                          l.length === 0 && a(u);
                      }
                      function Pt(r) {
                        switch (r) {
                          case 1:
                            return 0;
                          case 2:
                            return 1;
                          case 4:
                            return 2;
                          case 8:
                            return 3;
                          default:
                            throw new TypeError(`Unknown type size: ${r}`);
                        }
                      }
                      function Mn(r, t, o = {}) {
                        var a = t.name;
                        if (
                          (r ||
                            d(
                              `type "${a}" must have a positive integer typeid pointer`
                            ),
                          ve.hasOwnProperty(r))
                        ) {
                          if (o.ab) return;
                          d(`Cannot register type '${a}' twice`);
                        }
                        (ve[r] = t),
                          delete Rt[r],
                          dt.hasOwnProperty(r) &&
                            ((t = dt[r]), delete dt[r], t.forEach((u) => u()));
                      }
                      function Xe(r, t, o = {}) {
                        if (!("argPackAdvance" in t))
                          throw new TypeError(
                            "registerType registeredInstance requires argPackAdvance"
                          );
                        Mn(r, t, o);
                      }
                      function zt(r) {
                        d(r.g.j.h.name + " instance already deleted");
                      }
                      function ot() {}
                      function $t(r, t, o) {
                        if (r[t].m === void 0) {
                          var a = r[t];
                          (r[t] = function () {
                            return (
                              r[t].m.hasOwnProperty(arguments.length) ||
                                d(
                                  `Function '${o}' called with an invalid number of arguments (${arguments.length}) - expects one of (${r[t].m})!`
                                ),
                              r[t].m[arguments.length].apply(this, arguments)
                            );
                          }),
                            (r[t].m = []),
                            (r[t].m[a.L] = a);
                        }
                      }
                      function Yt(r, t, o) {
                        c.hasOwnProperty(r)
                          ? ((o === void 0 ||
                              (c[r].m !== void 0 && c[r].m[o] !== void 0)) &&
                              d(`Cannot register public name '${r}' twice`),
                            $t(c, r, r),
                            c.hasOwnProperty(o) &&
                              d(
                                `Cannot register multiple overloads of a function with the same number of arguments (${o})!`
                              ),
                            (c[r].m[o] = t))
                          : ((c[r] = t), o !== void 0 && (c[r].tb = o));
                      }
                      function In(r, t, o, a, u, l, m, p) {
                        (this.name = r),
                          (this.constructor = t),
                          (this.B = o),
                          (this.H = a),
                          (this.l = u),
                          (this.Ua = l),
                          (this.S = m),
                          (this.Pa = p),
                          (this.ya = []);
                      }
                      function Et(r, t, o) {
                        for (; t !== o; )
                          t.S ||
                            d(
                              `Expected null or instance of ${o.name}, got an instance of ${t.name}`
                            ),
                            (r = t.S(r)),
                            (t = t.l);
                        return r;
                      }
                      function Rn(r, t) {
                        return t === null
                          ? (this.ea && d(`null is not a valid ${this.name}`),
                            0)
                          : (t.g ||
                              d(`Cannot pass "${Ht(t)}" as a ${this.name}`),
                            t.g.i ||
                              d(
                                `Cannot pass deleted object as a pointer of type ${this.name}`
                              ),
                            Et(t.g.i, t.g.j.h, this.h));
                      }
                      function Pn(r, t) {
                        if (t === null) {
                          if (
                            (this.ea && d(`null is not a valid ${this.name}`),
                            this.V)
                          ) {
                            var o = this.fa();
                            return r !== null && r.push(this.H, o), o;
                          }
                          return 0;
                        }
                        if (
                          (t.g || d(`Cannot pass "${Ht(t)}" as a ${this.name}`),
                          t.g.i ||
                            d(
                              `Cannot pass deleted object as a pointer of type ${this.name}`
                            ),
                          !this.U &&
                            t.g.j.U &&
                            d(
                              `Cannot convert argument of type ${
                                t.g.A ? t.g.A.name : t.g.j.name
                              } to parameter type ${this.name}`
                            ),
                          (o = Et(t.g.i, t.g.j.h, this.h)),
                          this.V)
                        )
                          switch (
                            (t.g.s === void 0 &&
                              d(
                                "Passing raw pointer to smart pointer is illegal"
                              ),
                            this.nb)
                          ) {
                            case 0:
                              t.g.A === this
                                ? (o = t.g.s)
                                : d(
                                    `Cannot convert argument of type ${
                                      t.g.A ? t.g.A.name : t.g.j.name
                                    } to parameter type ${this.name}`
                                  );
                              break;
                            case 1:
                              o = t.g.s;
                              break;
                            case 2:
                              if (t.g.A === this) o = t.g.s;
                              else {
                                var a = t.clone();
                                (o = this.jb(
                                  o,
                                  L(function () {
                                    a.delete();
                                  })
                                )),
                                  r !== null && r.push(this.H, o);
                              }
                              break;
                            default:
                              d("Unsupporting sharing policy");
                          }
                        return o;
                      }
                      function En(r, t) {
                        return t === null
                          ? (this.ea && d(`null is not a valid ${this.name}`),
                            0)
                          : (t.g ||
                              d(`Cannot pass "${Ht(t)}" as a ${this.name}`),
                            t.g.i ||
                              d(
                                `Cannot pass deleted object as a pointer of type ${this.name}`
                              ),
                            t.g.j.U &&
                              d(
                                `Cannot convert argument of type ${t.g.j.name} to parameter type ${this.name}`
                              ),
                            Et(t.g.i, t.g.j.h, this.h));
                      }
                      function et(r, t, o, a) {
                        (this.name = r),
                          (this.h = t),
                          (this.ea = o),
                          (this.U = a),
                          (this.V = !1),
                          (this.H =
                            this.jb =
                            this.fa =
                            this.za =
                            this.nb =
                            this.ib =
                              void 0),
                          t.l !== void 0
                            ? (this.toWireType = Pn)
                            : ((this.toWireType = a ? Rn : En),
                              (this.v = null));
                      }
                      function Zt(r, t, o) {
                        c.hasOwnProperty(r) ||
                          Ct("Replacing nonexistant public symbol"),
                          c[r].m !== void 0 && o !== void 0
                            ? (c[r].m[o] = t)
                            : ((c[r] = t), (c[r].L = o));
                      }
                      var Ft = [],
                        en = (r) => {
                          var t = Ft[r];
                          return (
                            t ||
                              (r >= Ft.length && (Ft.length = r + 1),
                              (Ft[r] = t = ce.get(r))),
                            t
                          );
                        },
                        Fn = (r, t) => {
                          var o = [];
                          return function () {
                            if (
                              ((o.length = 0),
                              Object.assign(o, arguments),
                              r.includes("j"))
                            ) {
                              var a = c["dynCall_" + r];
                              a =
                                o && o.length
                                  ? a.apply(null, [t].concat(o))
                                  : a.call(null, t);
                            } else a = en(t).apply(null, o);
                            return a;
                          };
                        };
                      function Me(r, t) {
                        r = j(r);
                        var o = r.includes("j") ? Fn(r, t) : en(t);
                        return (
                          typeof o != "function" &&
                            d(
                              `unknown function pointer with signature ${r}: ${t}`
                            ),
                          o
                        );
                      }
                      var tn = void 0;
                      function tt(r, t) {
                        function o(l) {
                          u[l] ||
                            ve[l] ||
                            (Rt[l]
                              ? Rt[l].forEach(o)
                              : (a.push(l), (u[l] = !0)));
                        }
                        var a = [],
                          u = {};
                        throw (
                          (t.forEach(o),
                          new tn(`${r}: ` + a.map(je).join([", "])))
                        );
                      }
                      function Lt(r, t, o, a, u) {
                        var l = t.length;
                        2 > l &&
                          d(
                            "argTypes array size mismatch! Must at least get return value and 'this' types!"
                          );
                        var m = t[1] !== null && o !== null,
                          p = !1;
                        for (o = 1; o < t.length; ++o)
                          if (t[o] !== null && t[o].v === void 0) {
                            p = !0;
                            break;
                          }
                        var g = t[0].name !== "void",
                          v = l - 2,
                          A = Array(v),
                          P = [],
                          S = [];
                        return function () {
                          if (
                            (arguments.length !== v &&
                              d(
                                `function ${r} called with ${arguments.length} arguments, expected ${v} args!`
                              ),
                            (S.length = 0),
                            (P.length = m ? 2 : 1),
                            (P[0] = u),
                            m)
                          ) {
                            var f = t[1].toWireType(S, this);
                            P[1] = f;
                          }
                          for (var w = 0; w < v; ++w)
                            (A[w] = t[w + 2].toWireType(S, arguments[w])),
                              P.push(A[w]);
                          if (((w = a.apply(null, P)), p)) gt(S);
                          else
                            for (var _ = m ? 1 : 2; _ < t.length; _++) {
                              var H = _ === 1 ? f : A[_ - 2];
                              t[_].v !== null && t[_].v(H);
                            }
                          return (f = g ? t[0].fromWireType(w) : void 0), f;
                        };
                      }
                      function Tt(r, t) {
                        for (var o = [], a = 0; a < r; a++)
                          o.push(q[(t + 4 * a) >> 2]);
                        return o;
                      }
                      function nn(r, t, o) {
                        return (
                          r instanceof Object ||
                            d(`${o} with invalid "this": ${r}`),
                          r instanceof t.h.constructor ||
                            d(
                              `${o} incompatible with "this" of type ${r.constructor.name}`
                            ),
                          r.g.i ||
                            d(
                              `cannot call emscripten binding method ${o} on deleted object`
                            ),
                          Et(r.g.i, r.g.j.h, t.h)
                        );
                      }
                      function Xt(r) {
                        r >= s.ua && --s.get(r).Aa === 0 && s.$a(r);
                      }
                      function Ln(r, t, o) {
                        switch (t) {
                          case 0:
                            return function (a) {
                              return this.fromWireType((o ? ke : le)[a]);
                            };
                          case 1:
                            return function (a) {
                              return this.fromWireType((o ? Pe : De)[a >> 1]);
                            };
                          case 2:
                            return function (a) {
                              return this.fromWireType((o ? re : q)[a >> 2]);
                            };
                          default:
                            throw new TypeError("Unknown integer type: " + r);
                        }
                      }
                      function Ht(r) {
                        if (r === null) return "null";
                        var t = typeof r;
                        return t === "object" ||
                          t === "array" ||
                          t === "function"
                          ? r.toString()
                          : "" + r;
                      }
                      function Tn(r, t) {
                        switch (t) {
                          case 2:
                            return function (o) {
                              return this.fromWireType(Ye[o >> 2]);
                            };
                          case 3:
                            return function (o) {
                              return this.fromWireType(Z[o >> 3]);
                            };
                          default:
                            throw new TypeError("Unknown float type: " + r);
                        }
                      }
                      function On(r, t, o) {
                        switch (t) {
                          case 0:
                            return o
                              ? function (a) {
                                  return ke[a];
                                }
                              : function (a) {
                                  return le[a];
                                };
                          case 1:
                            return o
                              ? function (a) {
                                  return Pe[a >> 1];
                                }
                              : function (a) {
                                  return De[a >> 1];
                                };
                          case 2:
                            return o
                              ? function (a) {
                                  return re[a >> 2];
                                }
                              : function (a) {
                                  return q[a >> 2];
                                };
                          default:
                            throw new TypeError("Unknown integer type: " + r);
                        }
                      }
                      var rn = (r, t, o, a) => {
                          if (0 < a) {
                            a = o + a - 1;
                            for (var u = 0; u < r.length; ++u) {
                              var l = r.charCodeAt(u);
                              if (55296 <= l && 57343 >= l) {
                                var m = r.charCodeAt(++u);
                                l = (65536 + ((l & 1023) << 10)) | (m & 1023);
                              }
                              if (127 >= l) {
                                if (o >= a) break;
                                t[o++] = l;
                              } else {
                                if (2047 >= l) {
                                  if (o + 1 >= a) break;
                                  t[o++] = 192 | (l >> 6);
                                } else {
                                  if (65535 >= l) {
                                    if (o + 2 >= a) break;
                                    t[o++] = 224 | (l >> 12);
                                  } else {
                                    if (o + 3 >= a) break;
                                    (t[o++] = 240 | (l >> 18)),
                                      (t[o++] = 128 | ((l >> 12) & 63));
                                  }
                                  t[o++] = 128 | ((l >> 6) & 63);
                                }
                                t[o++] = 128 | (l & 63);
                              }
                            }
                            t[o] = 0;
                          }
                        },
                        on = (r) => {
                          for (var t = 0, o = 0; o < r.length; ++o) {
                            var a = r.charCodeAt(o);
                            127 >= a
                              ? t++
                              : 2047 >= a
                              ? (t += 2)
                              : 55296 <= a && 57343 >= a
                              ? ((t += 4), ++o)
                              : (t += 3);
                          }
                          return t;
                        },
                        an =
                          typeof TextDecoder < "u"
                            ? new TextDecoder("utf8")
                            : void 0,
                        Ot = (r, t, o) => {
                          var a = t + o;
                          for (o = t; r[o] && !(o >= a); ) ++o;
                          if (16 < o - t && r.buffer && an)
                            return an.decode(r.subarray(t, o));
                          for (a = ""; t < o; ) {
                            var u = r[t++];
                            if (u & 128) {
                              var l = r[t++] & 63;
                              if ((u & 224) == 192)
                                a += String.fromCharCode(((u & 31) << 6) | l);
                              else {
                                var m = r[t++] & 63;
                                (u =
                                  (u & 240) == 224
                                    ? ((u & 15) << 12) | (l << 6) | m
                                    : ((u & 7) << 18) |
                                      (l << 12) |
                                      (m << 6) |
                                      (r[t++] & 63)),
                                  65536 > u
                                    ? (a += String.fromCharCode(u))
                                    : ((u -= 65536),
                                      (a += String.fromCharCode(
                                        55296 | (u >> 10),
                                        56320 | (u & 1023)
                                      )));
                              }
                            } else a += String.fromCharCode(u);
                          }
                          return a;
                        },
                        sn =
                          typeof TextDecoder < "u"
                            ? new TextDecoder("utf-16le")
                            : void 0,
                        Sn = (r, t) => {
                          for (
                            var o = r >> 1, a = o + t / 2;
                            !(o >= a) && De[o];

                          )
                            ++o;
                          if (((o <<= 1), 32 < o - r && sn))
                            return sn.decode(le.subarray(r, o));
                          for (o = "", a = 0; !(a >= t / 2); ++a) {
                            var u = Pe[(r + 2 * a) >> 1];
                            if (u == 0) break;
                            o += String.fromCharCode(u);
                          }
                          return o;
                        },
                        jn = (r, t, o) => {
                          if ((o === void 0 && (o = 2147483647), 2 > o))
                            return 0;
                          o -= 2;
                          var a = t;
                          o = o < 2 * r.length ? o / 2 : r.length;
                          for (var u = 0; u < o; ++u)
                            (Pe[t >> 1] = r.charCodeAt(u)), (t += 2);
                          return (Pe[t >> 1] = 0), t - a;
                        },
                        Wn = (r) => 2 * r.length,
                        xn = (r, t) => {
                          for (var o = 0, a = ""; !(o >= t / 4); ) {
                            var u = re[(r + 4 * o) >> 2];
                            if (u == 0) break;
                            ++o,
                              65536 <= u
                                ? ((u -= 65536),
                                  (a += String.fromCharCode(
                                    55296 | (u >> 10),
                                    56320 | (u & 1023)
                                  )))
                                : (a += String.fromCharCode(u));
                          }
                          return a;
                        },
                        Vn = (r, t, o) => {
                          if ((o === void 0 && (o = 2147483647), 4 > o))
                            return 0;
                          var a = t;
                          o = a + o - 4;
                          for (var u = 0; u < r.length; ++u) {
                            var l = r.charCodeAt(u);
                            if (55296 <= l && 57343 >= l) {
                              var m = r.charCodeAt(++u);
                              l = (65536 + ((l & 1023) << 10)) | (m & 1023);
                            }
                            if (((re[t >> 2] = l), (t += 4), t + 4 > o)) break;
                          }
                          return (re[t >> 2] = 0), t - a;
                        },
                        kn = (r) => {
                          for (var t = 0, o = 0; o < r.length; ++o) {
                            var a = r.charCodeAt(o);
                            55296 <= a && 57343 >= a && ++o, (t += 4);
                          }
                          return t;
                        },
                        Dn = {};
                      function St(r) {
                        var t = Dn[r];
                        return t === void 0 ? j(r) : t;
                      }
                      var jt = [];
                      function Un(r) {
                        var t = jt.length;
                        return jt.push(r), t;
                      }
                      function Bn(r, t) {
                        for (var o = Array(r), a = 0; a < r; ++a)
                          o[a] = xe(q[(t + 4 * a) >> 2], "parameter " + a);
                        return o;
                      }
                      var un = [],
                        Gt = {},
                        ln = () => {
                          if (!Kt) {
                            var r = {
                                USER: "web_user",
                                LOGNAME: "web_user",
                                PATH: "/",
                                PWD: "/",
                                HOME: "/home/web_user",
                                LANG:
                                  (
                                    (typeof navigator == "object" &&
                                      navigator.languages &&
                                      navigator.languages[0]) ||
                                    "C"
                                  ).replace("-", "_") + ".UTF-8",
                                _: Te || "./this.program",
                              },
                              t;
                            for (t in Gt)
                              Gt[t] === void 0 ? delete r[t] : (r[t] = Gt[t]);
                            var o = [];
                            for (t in r) o.push(`${t}=${r[t]}`);
                            Kt = o;
                          }
                          return Kt;
                        },
                        Kt,
                        Nn = [null, [], []],
                        Wt = (r) =>
                          r % 4 === 0 && (r % 100 !== 0 || r % 400 === 0),
                        cn = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31],
                        fn = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
                      function zn(r) {
                        var t = Array(on(r) + 1);
                        return rn(r, t, 0, t.length), t;
                      }
                      var $n = (r, t, o, a) => {
                        function u(f, w, _) {
                          for (
                            f = typeof f == "number" ? f.toString() : f || "";
                            f.length < w;

                          )
                            f = _[0] + f;
                          return f;
                        }
                        function l(f, w) {
                          return u(f, w, "0");
                        }
                        function m(f, w) {
                          function _(X) {
                            return 0 > X ? -1 : 0 < X ? 1 : 0;
                          }
                          var H;
                          return (
                            (H = _(f.getFullYear() - w.getFullYear())) === 0 &&
                              (H = _(f.getMonth() - w.getMonth())) === 0 &&
                              (H = _(f.getDate() - w.getDate())),
                            H
                          );
                        }
                        function p(f) {
                          switch (f.getDay()) {
                            case 0:
                              return new Date(f.getFullYear() - 1, 11, 29);
                            case 1:
                              return f;
                            case 2:
                              return new Date(f.getFullYear(), 0, 3);
                            case 3:
                              return new Date(f.getFullYear(), 0, 2);
                            case 4:
                              return new Date(f.getFullYear(), 0, 1);
                            case 5:
                              return new Date(f.getFullYear() - 1, 11, 31);
                            case 6:
                              return new Date(f.getFullYear() - 1, 11, 30);
                          }
                        }
                        function g(f) {
                          var w = f.J;
                          for (
                            f = new Date(new Date(f.K + 1900, 0, 1).getTime());
                            0 < w;

                          ) {
                            var _ = f.getMonth(),
                              H = (Wt(f.getFullYear()) ? cn : fn)[_];
                            if (w > H - f.getDate())
                              (w -= H - f.getDate() + 1),
                                f.setDate(1),
                                11 > _
                                  ? f.setMonth(_ + 1)
                                  : (f.setMonth(0),
                                    f.setFullYear(f.getFullYear() + 1));
                            else {
                              f.setDate(f.getDate() + w);
                              break;
                            }
                          }
                          return (
                            (_ = new Date(f.getFullYear() + 1, 0, 4)),
                            (w = p(new Date(f.getFullYear(), 0, 4))),
                            (_ = p(_)),
                            0 >= m(w, f)
                              ? 0 >= m(_, f)
                                ? f.getFullYear() + 1
                                : f.getFullYear()
                              : f.getFullYear() - 1
                          );
                        }
                        var v = re[(a + 40) >> 2];
                        (a = {
                          qb: re[a >> 2],
                          pb: re[(a + 4) >> 2],
                          Z: re[(a + 8) >> 2],
                          ha: re[(a + 12) >> 2],
                          $: re[(a + 16) >> 2],
                          K: re[(a + 20) >> 2],
                          C: re[(a + 24) >> 2],
                          J: re[(a + 28) >> 2],
                          ub: re[(a + 32) >> 2],
                          ob: re[(a + 36) >> 2],
                          rb: v && v ? Ot(le, v) : "",
                        }),
                          (o = o ? Ot(le, o) : ""),
                          (v = {
                            "%c": "%a %b %d %H:%M:%S %Y",
                            "%D": "%m/%d/%y",
                            "%F": "%Y-%m-%d",
                            "%h": "%b",
                            "%r": "%I:%M:%S %p",
                            "%R": "%H:%M",
                            "%T": "%H:%M:%S",
                            "%x": "%m/%d/%y",
                            "%X": "%H:%M:%S",
                            "%Ec": "%c",
                            "%EC": "%C",
                            "%Ex": "%m/%d/%y",
                            "%EX": "%H:%M:%S",
                            "%Ey": "%y",
                            "%EY": "%Y",
                            "%Od": "%d",
                            "%Oe": "%e",
                            "%OH": "%H",
                            "%OI": "%I",
                            "%Om": "%m",
                            "%OM": "%M",
                            "%OS": "%S",
                            "%Ou": "%u",
                            "%OU": "%U",
                            "%OV": "%V",
                            "%Ow": "%w",
                            "%OW": "%W",
                            "%Oy": "%y",
                          });
                        for (var A in v)
                          o = o.replace(new RegExp(A, "g"), v[A]);
                        var P =
                            "Sunday Monday Tuesday Wednesday Thursday Friday Saturday".split(
                              " "
                            ),
                          S =
                            "January February March April May June July August September October November December".split(
                              " "
                            );
                        (v = {
                          "%a": (f) => P[f.C].substring(0, 3),
                          "%A": (f) => P[f.C],
                          "%b": (f) => S[f.$].substring(0, 3),
                          "%B": (f) => S[f.$],
                          "%C": (f) => l(((f.K + 1900) / 100) | 0, 2),
                          "%d": (f) => l(f.ha, 2),
                          "%e": (f) => u(f.ha, 2, " "),
                          "%g": (f) => g(f).toString().substring(2),
                          "%G": (f) => g(f),
                          "%H": (f) => l(f.Z, 2),
                          "%I": (f) => (
                            (f = f.Z),
                            f == 0 ? (f = 12) : 12 < f && (f -= 12),
                            l(f, 2)
                          ),
                          "%j": (f) => {
                            for (
                              var w = 0, _ = 0;
                              _ <= f.$ - 1;
                              w += (Wt(f.K + 1900) ? cn : fn)[_++]
                            );
                            return l(f.ha + w, 3);
                          },
                          "%m": (f) => l(f.$ + 1, 2),
                          "%M": (f) => l(f.pb, 2),
                          "%n": () => `
`,
                          "%p": (f) => (0 <= f.Z && 12 > f.Z ? "AM" : "PM"),
                          "%S": (f) => l(f.qb, 2),
                          "%t": () => "	",
                          "%u": (f) => f.C || 7,
                          "%U": (f) => l(Math.floor((f.J + 7 - f.C) / 7), 2),
                          "%V": (f) => {
                            var w = Math.floor((f.J + 7 - ((f.C + 6) % 7)) / 7);
                            if ((2 >= (f.C + 371 - f.J - 2) % 7 && w++, w))
                              w == 53 &&
                                ((_ = (f.C + 371 - f.J) % 7),
                                _ == 4 || (_ == 3 && Wt(f.K)) || (w = 1));
                            else {
                              w = 52;
                              var _ = (f.C + 7 - f.J - 1) % 7;
                              (_ == 4 || (_ == 5 && Wt((f.K % 400) - 1))) &&
                                w++;
                            }
                            return l(w, 2);
                          },
                          "%w": (f) => f.C,
                          "%W": (f) =>
                            l(Math.floor((f.J + 7 - ((f.C + 6) % 7)) / 7), 2),
                          "%y": (f) => (f.K + 1900).toString().substring(2),
                          "%Y": (f) => f.K + 1900,
                          "%z": (f) => {
                            f = f.ob;
                            var w = 0 <= f;
                            return (
                              (f = Math.abs(f) / 60),
                              (w ? "+" : "-") +
                                ("0000" + ((f / 60) * 100 + (f % 60))).slice(-4)
                            );
                          },
                          "%Z": (f) => f.rb,
                          "%%": () => "%",
                        }),
                          (o = o.replace(/%%/g, "\0\0"));
                        for (A in v)
                          o.includes(A) &&
                            (o = o.replace(new RegExp(A, "g"), v[A](a)));
                        return (
                          (o = o.replace(/\0\0/g, "%")),
                          (A = zn(o)),
                          A.length > t ? 0 : (ke.set(A, r), A.length - 1)
                        );
                      };
                      Object.assign(n.prototype, {
                        get(r) {
                          return this.G[r];
                        },
                        has(r) {
                          return this.G[r] !== void 0;
                        },
                        Za(r) {
                          var t = this.ta.pop() || this.G.length;
                          return (this.G[t] = r), t;
                        },
                        $a(r) {
                          (this.G[r] = void 0), this.ta.push(r);
                        },
                      }),
                        (h = c.BindingError =
                          class extends Error {
                            constructor(r) {
                              super(r), (this.name = "BindingError");
                            }
                          }),
                        s.G.push(
                          { value: void 0 },
                          { value: null },
                          { value: !0 },
                          { value: !1 }
                        ),
                        (s.ua = s.G.length),
                        (c.count_emval_handles = function () {
                          for (var r = 0, t = s.ua; t < s.G.length; ++t)
                            s.G[t] !== void 0 && ++r;
                          return r;
                        }),
                        (F = c.PureVirtualError = W("PureVirtualError"));
                      for (var hn = Array(256), xt = 0; 256 > xt; ++xt)
                        hn[xt] = String.fromCharCode(xt);
                      (V = hn),
                        (c.getInheritedInstanceCount = function () {
                          return Object.keys(pe).length;
                        }),
                        (c.getLiveInheritedInstances = function () {
                          var r = [],
                            t;
                          for (t in pe) pe.hasOwnProperty(t) && r.push(pe[t]);
                          return r;
                        }),
                        (c.flushPendingDeletes = ie),
                        (c.setDelayFunction = function (r) {
                          (Fe = r), de.length && Fe && Fe(ie);
                        }),
                        (qt = c.InternalError =
                          class extends Error {
                            constructor(r) {
                              super(r), (this.name = "InternalError");
                            }
                          }),
                        (ot.prototype.isAliasOf = function (r) {
                          if (!(this instanceof ot && r instanceof ot))
                            return !1;
                          var t = this.g.j.h,
                            o = this.g.i,
                            a = r.g.j.h;
                          for (r = r.g.i; t.l; ) (o = t.S(o)), (t = t.l);
                          for (; a.l; ) (r = a.S(r)), (a = a.l);
                          return t === a && o === r;
                        }),
                        (ot.prototype.clone = function () {
                          if ((this.g.i || zt(this), this.g.O))
                            return (this.g.count.value += 1), this;
                          var r = ht,
                            t = Object,
                            o = t.create,
                            a = Object.getPrototypeOf(this),
                            u = this.g;
                          return (
                            (r = r(
                              o.call(t, a, {
                                g: {
                                  value: {
                                    count: u.count,
                                    M: u.M,
                                    O: u.O,
                                    i: u.i,
                                    j: u.j,
                                    s: u.s,
                                    A: u.A,
                                  },
                                },
                              })
                            )),
                            (r.g.count.value += 1),
                            (r.g.M = !1),
                            r
                          );
                        }),
                        (ot.prototype.delete = function () {
                          this.g.i || zt(this),
                            this.g.M &&
                              !this.g.O &&
                              d("Object already scheduled for deletion"),
                            Be(this),
                            ze(this.g),
                            this.g.O ||
                              ((this.g.s = void 0), (this.g.i = void 0));
                        }),
                        (ot.prototype.isDeleted = function () {
                          return !this.g.i;
                        }),
                        (ot.prototype.deleteLater = function () {
                          return (
                            this.g.i || zt(this),
                            this.g.M &&
                              !this.g.O &&
                              d("Object already scheduled for deletion"),
                            de.push(this),
                            de.length === 1 && Fe && Fe(ie),
                            (this.g.M = !0),
                            this
                          );
                        }),
                        (et.prototype.Va = function (r) {
                          return this.za && (r = this.za(r)), r;
                        }),
                        (et.prototype.pa = function (r) {
                          this.H && this.H(r);
                        }),
                        (et.prototype.argPackAdvance = 8),
                        (et.prototype.readValueFromPointer = yt),
                        (et.prototype.deleteObject = function (r) {
                          r !== null && r.delete();
                        }),
                        (et.prototype.fromWireType = function (r) {
                          function t() {
                            return this.V
                              ? Mt(this.h.B, {
                                  j: this.ib,
                                  i: o,
                                  A: this,
                                  s: r,
                                })
                              : Mt(this.h.B, { j: this, i: r });
                          }
                          var o = this.Va(r);
                          if (!o) return this.pa(r), null;
                          var a = Cn(this.h, o);
                          if (a !== void 0)
                            return a.g.count.value === 0
                              ? ((a.g.i = o), (a.g.s = r), a.clone())
                              : ((a = a.clone()), this.pa(r), a);
                          if (((a = this.h.Ua(o)), (a = Ze[a]), !a))
                            return t.call(this);
                          a = this.U ? a.Ka : a.pointerType;
                          var u = N(o, this.h, a.h);
                          return u === null
                            ? t.call(this)
                            : this.V
                            ? Mt(a.h.B, { j: a, i: u, A: this, s: r })
                            : Mt(a.h.B, { j: a, i: u });
                        }),
                        (tn = c.UnboundTypeError = W("UnboundTypeError"));
                      var dn = {
                        _embind_create_inheriting_constructor: function (
                          r,
                          t,
                          o
                        ) {
                          (r = j(r)), (t = xe(t, "wrapper")), (o = y(o));
                          var a = [].slice,
                            u = t.h,
                            l = u.B,
                            m = u.l.B,
                            p = u.l.constructor;
                          (r = e(r, function () {
                            u.l.ya.forEach(
                              function (v) {
                                if (this[v] === m[v])
                                  throw new F(
                                    `Pure virtual function ${v} must be implemented in JavaScript`
                                  );
                              }.bind(this)
                            ),
                              Object.defineProperty(this, "__parent", {
                                value: l,
                              }),
                              this.__construct.apply(this, a.call(arguments));
                          })),
                            (l.__construct = function () {
                              this === l &&
                                d("Pass correct 'this' to __construct");
                              var v = p.implement.apply(
                                void 0,
                                [this].concat(a.call(arguments))
                              );
                              Be(v);
                              var A = v.g;
                              v.notifyOnDestruction(),
                                (A.O = !0),
                                Object.defineProperties(this, {
                                  g: { value: A },
                                }),
                                ht(this),
                                (v = A.i),
                                (v = Ie(u, v)),
                                pe.hasOwnProperty(v)
                                  ? d(
                                      `Tried to register registered instance: ${v}`
                                    )
                                  : (pe[v] = this);
                            }),
                            (l.__destruct = function () {
                              this === l &&
                                d("Pass correct 'this' to __destruct"),
                                Be(this);
                              var v = this.g.i;
                              (v = Ie(u, v)),
                                pe.hasOwnProperty(v)
                                  ? delete pe[v]
                                  : d(
                                      `Tried to unregister unregistered instance: ${v}`
                                    );
                            }),
                            (r.prototype = Object.create(l));
                          for (var g in o) r.prototype[g] = o[g];
                          return L(r);
                        },
                        _embind_finalize_value_object: function (r) {
                          var t = It[r];
                          delete It[r];
                          var o = t.fa,
                            a = t.H,
                            u = t.sa,
                            l = u.map((m) => m.Ya).concat(u.map((m) => m.lb));
                          We([r], l, (m) => {
                            var p = {};
                            return (
                              u.forEach((g, v) => {
                                var A = m[v],
                                  P = g.Wa,
                                  S = g.Xa,
                                  f = m[v + u.length],
                                  w = g.kb,
                                  _ = g.mb;
                                p[g.Sa] = {
                                  read: (H) => A.fromWireType(P(S, H)),
                                  write: (H, X) => {
                                    var E = [];
                                    w(_, H, f.toWireType(E, X)), gt(E);
                                  },
                                };
                              }),
                              [
                                {
                                  name: t.name,
                                  fromWireType: function (g) {
                                    var v = {},
                                      A;
                                    for (A in p) v[A] = p[A].read(g);
                                    return a(g), v;
                                  },
                                  toWireType: function (g, v) {
                                    for (var A in p)
                                      if (!(A in v))
                                        throw new TypeError(
                                          `Missing field: "${A}"`
                                        );
                                    var P = o();
                                    for (A in p) p[A].write(P, v[A]);
                                    return g !== null && g.push(a, P), P;
                                  },
                                  argPackAdvance: 8,
                                  readValueFromPointer: yt,
                                  v: a,
                                },
                              ]
                            );
                          });
                        },
                        _embind_register_bigint: function () {},
                        _embind_register_bool: function (r, t, o, a, u) {
                          var l = Pt(o);
                          (t = j(t)),
                            Xe(r, {
                              name: t,
                              fromWireType: function (m) {
                                return !!m;
                              },
                              toWireType: function (m, p) {
                                return p ? a : u;
                              },
                              argPackAdvance: 8,
                              readValueFromPointer: function (m) {
                                if (o === 1) var p = ke;
                                else if (o === 2) p = Pe;
                                else if (o === 4) p = re;
                                else
                                  throw new TypeError(
                                    "Unknown boolean type size: " + t
                                  );
                                return this.fromWireType(p[m >> l]);
                              },
                              v: null,
                            });
                        },
                        _embind_register_class: function (
                          r,
                          t,
                          o,
                          a,
                          u,
                          l,
                          m,
                          p,
                          g,
                          v,
                          A,
                          P,
                          S
                        ) {
                          (A = j(A)),
                            (l = Me(u, l)),
                            p && (p = Me(m, p)),
                            v && (v = Me(g, v)),
                            (S = Me(P, S));
                          var f = i(A);
                          Yt(f, function () {
                            tt(`Cannot construct ${A} due to unbound types`, [
                              a,
                            ]);
                          }),
                            We([r, t, o], a ? [a] : [], function (w) {
                              if (((w = w[0]), a))
                                var _ = w.h,
                                  H = _.B;
                              else H = ot.prototype;
                              w = e(f, function () {
                                if (Object.getPrototypeOf(this) !== X)
                                  throw new h("Use 'new' to construct " + A);
                                if (E.I === void 0)
                                  throw new h(
                                    A + " has no accessible constructor"
                                  );
                                var Ae = E.I[arguments.length];
                                if (Ae === void 0)
                                  throw new h(
                                    `Tried to invoke ctor of ${A} with invalid number of parameters (${
                                      arguments.length
                                    }) - expected (${Object.keys(
                                      E.I
                                    ).toString()}) parameters instead!`
                                  );
                                return Ae.apply(this, arguments);
                              });
                              var X = Object.create(H, {
                                constructor: { value: w },
                              });
                              w.prototype = X;
                              var E = new In(A, w, X, S, _, l, p, v);
                              E.l &&
                                (E.l.T === void 0 && (E.l.T = []),
                                E.l.T.push(E)),
                                (_ = new et(A, E, !0, !1)),
                                (H = new et(A + "*", E, !1, !1));
                              var oe = new et(A + " const*", E, !1, !0);
                              return (
                                (Ze[r] = { pointerType: H, Ka: oe }),
                                Zt(f, w),
                                [_, H, oe]
                              );
                            });
                        },
                        _embind_register_class_class_function: function (
                          r,
                          t,
                          o,
                          a,
                          u,
                          l,
                          m
                        ) {
                          var p = Tt(o, a);
                          (t = j(t)),
                            (l = Me(u, l)),
                            We([], [r], function (g) {
                              function v() {
                                tt(`Cannot call ${A} due to unbound types`, p);
                              }
                              g = g[0];
                              var A = `${g.name}.${t}`;
                              t.startsWith("@@") &&
                                (t = Symbol[t.substring(2)]);
                              var P = g.h.constructor;
                              return (
                                P[t] === void 0
                                  ? ((v.L = o - 1), (P[t] = v))
                                  : ($t(P, t, A), (P[t].m[o - 1] = v)),
                                We([], p, function (S) {
                                  if (
                                    ((S = Lt(
                                      A,
                                      [S[0], null].concat(S.slice(1)),
                                      null,
                                      l,
                                      m
                                    )),
                                    P[t].m === void 0
                                      ? ((S.L = o - 1), (P[t] = S))
                                      : (P[t].m[o - 1] = S),
                                    g.h.T)
                                  )
                                    for (const f of g.h.T)
                                      f.constructor.hasOwnProperty(t) ||
                                        (f.constructor[t] = S);
                                  return [];
                                }),
                                []
                              );
                            });
                        },
                        _embind_register_class_class_property: function (
                          r,
                          t,
                          o,
                          a,
                          u,
                          l,
                          m,
                          p
                        ) {
                          (t = j(t)),
                            (l = Me(u, l)),
                            We([], [r], function (g) {
                              g = g[0];
                              var v = `${g.name}.${t}`,
                                A = {
                                  get() {
                                    tt(
                                      `Cannot access ${v} due to unbound types`,
                                      [o]
                                    );
                                  },
                                  enumerable: !0,
                                  configurable: !0,
                                };
                              return (
                                (A.set = p
                                  ? () => {
                                      tt(
                                        `Cannot access ${v} due to unbound types`,
                                        [o]
                                      );
                                    }
                                  : () => {
                                      d(`${v} is a read-only property`);
                                    }),
                                Object.defineProperty(g.h.constructor, t, A),
                                We([], [o], function (P) {
                                  P = P[0];
                                  var S = {
                                    get() {
                                      return P.fromWireType(l(a));
                                    },
                                    enumerable: !0,
                                  };
                                  return (
                                    p &&
                                      ((p = Me(m, p)),
                                      (S.set = (f) => {
                                        var w = [];
                                        p(a, P.toWireType(w, f)), gt(w);
                                      })),
                                    Object.defineProperty(
                                      g.h.constructor,
                                      t,
                                      S
                                    ),
                                    []
                                  );
                                }),
                                []
                              );
                            });
                        },
                        _embind_register_class_constructor: function (
                          r,
                          t,
                          o,
                          a,
                          u,
                          l
                        ) {
                          var m = Tt(t, o);
                          (u = Me(a, u)),
                            We([], [r], function (p) {
                              p = p[0];
                              var g = `constructor ${p.name}`;
                              if (
                                (p.h.I === void 0 && (p.h.I = []),
                                p.h.I[t - 1] !== void 0)
                              )
                                throw new h(
                                  `Cannot register multiple constructors with identical number of parameters (${
                                    t - 1
                                  }) for class '${
                                    p.name
                                  }'! Overload resolution is currently only performed using the parameter count, not actual type info!`
                                );
                              return (
                                (p.h.I[t - 1] = () => {
                                  tt(
                                    `Cannot construct ${p.name} due to unbound types`,
                                    m
                                  );
                                }),
                                We([], m, function (v) {
                                  return (
                                    v.splice(1, 0, null),
                                    (p.h.I[t - 1] = Lt(g, v, null, u, l)),
                                    []
                                  );
                                }),
                                []
                              );
                            });
                        },
                        _embind_register_class_function: function (
                          r,
                          t,
                          o,
                          a,
                          u,
                          l,
                          m,
                          p
                        ) {
                          var g = Tt(o, a);
                          (t = j(t)),
                            (l = Me(u, l)),
                            We([], [r], function (v) {
                              function A() {
                                tt(`Cannot call ${P} due to unbound types`, g);
                              }
                              v = v[0];
                              var P = `${v.name}.${t}`;
                              t.startsWith("@@") &&
                                (t = Symbol[t.substring(2)]),
                                p && v.h.ya.push(t);
                              var S = v.h.B,
                                f = S[t];
                              return (
                                f === void 0 ||
                                (f.m === void 0 &&
                                  f.className !== v.name &&
                                  f.L === o - 2)
                                  ? ((A.L = o - 2),
                                    (A.className = v.name),
                                    (S[t] = A))
                                  : ($t(S, t, P), (S[t].m[o - 2] = A)),
                                We([], g, function (w) {
                                  return (
                                    (w = Lt(P, w, v, l, m)),
                                    S[t].m === void 0
                                      ? ((w.L = o - 2), (S[t] = w))
                                      : (S[t].m[o - 2] = w),
                                    []
                                  );
                                }),
                                []
                              );
                            });
                        },
                        _embind_register_class_property: function (
                          r,
                          t,
                          o,
                          a,
                          u,
                          l,
                          m,
                          p,
                          g,
                          v
                        ) {
                          (t = j(t)),
                            (u = Me(a, u)),
                            We([], [r], function (A) {
                              A = A[0];
                              var P = `${A.name}.${t}`,
                                S = {
                                  get() {
                                    tt(
                                      `Cannot access ${P} due to unbound types`,
                                      [o, m]
                                    );
                                  },
                                  enumerable: !0,
                                  configurable: !0,
                                };
                              return (
                                (S.set = g
                                  ? () => {
                                      tt(
                                        `Cannot access ${P} due to unbound types`,
                                        [o, m]
                                      );
                                    }
                                  : () => {
                                      d(P + " is a read-only property");
                                    }),
                                Object.defineProperty(A.h.B, t, S),
                                We([], g ? [o, m] : [o], function (f) {
                                  var w = f[0],
                                    _ = {
                                      get() {
                                        var X = nn(this, A, P + " getter");
                                        return w.fromWireType(u(l, X));
                                      },
                                      enumerable: !0,
                                    };
                                  if (g) {
                                    g = Me(p, g);
                                    var H = f[1];
                                    _.set = function (X) {
                                      var E = nn(this, A, P + " setter"),
                                        oe = [];
                                      g(v, E, H.toWireType(oe, X)), gt(oe);
                                    };
                                  }
                                  return Object.defineProperty(A.h.B, t, _), [];
                                }),
                                []
                              );
                            });
                        },
                        _embind_register_emval: function (r, t) {
                          (t = j(t)),
                            Xe(r, {
                              name: t,
                              fromWireType: function (o) {
                                var a = y(o);
                                return Xt(o), a;
                              },
                              toWireType: function (o, a) {
                                return L(a);
                              },
                              argPackAdvance: 8,
                              readValueFromPointer: yt,
                              v: null,
                            });
                        },
                        _embind_register_enum: function (r, t, o, a) {
                          function u() {}
                          (o = Pt(o)),
                            (t = j(t)),
                            (u.values = {}),
                            Xe(r, {
                              name: t,
                              constructor: u,
                              fromWireType: function (l) {
                                return this.constructor.values[l];
                              },
                              toWireType: function (l, m) {
                                return m.value;
                              },
                              argPackAdvance: 8,
                              readValueFromPointer: Ln(t, o, a),
                              v: null,
                            }),
                            Yt(t, u);
                        },
                        _embind_register_enum_value: function (r, t, o) {
                          var a = xe(r, "enum");
                          (t = j(t)),
                            (r = a.constructor),
                            (a = Object.create(a.constructor.prototype, {
                              value: { value: o },
                              constructor: {
                                value: e(`${a.name}_${t}`, function () {}),
                              },
                            })),
                            (r.values[o] = a),
                            (r[t] = a);
                        },
                        _embind_register_float: function (r, t, o) {
                          (o = Pt(o)),
                            (t = j(t)),
                            Xe(r, {
                              name: t,
                              fromWireType: function (a) {
                                return a;
                              },
                              toWireType: function (a, u) {
                                return u;
                              },
                              argPackAdvance: 8,
                              readValueFromPointer: Tn(t, o),
                              v: null,
                            });
                        },
                        _embind_register_function: function (r, t, o, a, u, l) {
                          var m = Tt(t, o);
                          (r = j(r)),
                            (u = Me(a, u)),
                            Yt(
                              r,
                              function () {
                                tt(`Cannot call ${r} due to unbound types`, m);
                              },
                              t - 1
                            ),
                            We([], m, function (p) {
                              return (
                                Zt(
                                  r,
                                  Lt(
                                    r,
                                    [p[0], null].concat(p.slice(1)),
                                    null,
                                    u,
                                    l
                                  ),
                                  t - 1
                                ),
                                []
                              );
                            });
                        },
                        _embind_register_integer: function (r, t, o, a, u) {
                          (t = j(t)), u === -1 && (u = 4294967295), (u = Pt(o));
                          var l = (p) => p;
                          if (a === 0) {
                            var m = 32 - 8 * o;
                            l = (p) => (p << m) >>> m;
                          }
                          (o = t.includes("unsigned")
                            ? function (p, g) {
                                return g >>> 0;
                              }
                            : function (p, g) {
                                return g;
                              }),
                            Xe(r, {
                              name: t,
                              fromWireType: l,
                              toWireType: o,
                              argPackAdvance: 8,
                              readValueFromPointer: On(t, u, a !== 0),
                              v: null,
                            });
                        },
                        _embind_register_memory_view: function (r, t, o) {
                          function a(l) {
                            l >>= 2;
                            var m = q;
                            return new u(m.buffer, m[l + 1], m[l]);
                          }
                          var u = [
                            Int8Array,
                            Uint8Array,
                            Int16Array,
                            Uint16Array,
                            Int32Array,
                            Uint32Array,
                            Float32Array,
                            Float64Array,
                          ][t];
                          (o = j(o)),
                            Xe(
                              r,
                              {
                                name: o,
                                fromWireType: a,
                                argPackAdvance: 8,
                                readValueFromPointer: a,
                              },
                              { ab: !0 }
                            );
                        },
                        _embind_register_std_string: function (r, t) {
                          t = j(t);
                          var o = t === "std::string";
                          Xe(r, {
                            name: t,
                            fromWireType: function (a) {
                              var u = q[a >> 2],
                                l = a + 4;
                              if (o)
                                for (var m = l, p = 0; p <= u; ++p) {
                                  var g = l + p;
                                  if (p == u || le[g] == 0) {
                                    if (
                                      ((m = m ? Ot(le, m, g - m) : ""),
                                      v === void 0)
                                    )
                                      var v = m;
                                    else (v += "\0"), (v += m);
                                    m = g + 1;
                                  }
                                }
                              else {
                                for (v = Array(u), p = 0; p < u; ++p)
                                  v[p] = String.fromCharCode(le[l + p]);
                                v = v.join("");
                              }
                              return nt(a), v;
                            },
                            toWireType: function (a, u) {
                              u instanceof ArrayBuffer &&
                                (u = new Uint8Array(u));
                              var l = typeof u == "string";
                              l ||
                                u instanceof Uint8Array ||
                                u instanceof Uint8ClampedArray ||
                                u instanceof Int8Array ||
                                d("Cannot pass non-string to std::string");
                              var m = o && l ? on(u) : u.length,
                                p = Jt(4 + m + 1),
                                g = p + 4;
                              if (((q[p >> 2] = m), o && l))
                                rn(u, le, g, m + 1);
                              else if (l)
                                for (l = 0; l < m; ++l) {
                                  var v = u.charCodeAt(l);
                                  255 < v &&
                                    (nt(g),
                                    d(
                                      "String has UTF-16 code units that do not fit in 8 bits"
                                    )),
                                    (le[g + l] = v);
                                }
                              else for (l = 0; l < m; ++l) le[g + l] = u[l];
                              return a !== null && a.push(nt, p), p;
                            },
                            argPackAdvance: 8,
                            readValueFromPointer: yt,
                            v: function (a) {
                              nt(a);
                            },
                          });
                        },
                        _embind_register_std_wstring: function (r, t, o) {
                          if (((o = j(o)), t === 2))
                            var a = Sn,
                              u = jn,
                              l = Wn,
                              m = () => De,
                              p = 1;
                          else
                            t === 4 &&
                              ((a = xn),
                              (u = Vn),
                              (l = kn),
                              (m = () => q),
                              (p = 2));
                          Xe(r, {
                            name: o,
                            fromWireType: function (g) {
                              for (
                                var v = q[g >> 2], A = m(), P, S = g + 4, f = 0;
                                f <= v;
                                ++f
                              ) {
                                var w = g + 4 + f * t;
                                (f == v || A[w >> p] == 0) &&
                                  ((S = a(S, w - S)),
                                  P === void 0
                                    ? (P = S)
                                    : ((P += "\0"), (P += S)),
                                  (S = w + t));
                              }
                              return nt(g), P;
                            },
                            toWireType: function (g, v) {
                              typeof v != "string" &&
                                d(
                                  `Cannot pass non-string to C++ string type ${o}`
                                );
                              var A = l(v),
                                P = Jt(4 + A + t);
                              return (
                                (q[P >> 2] = A >> p),
                                u(v, P + 4, A + t),
                                g !== null && g.push(nt, P),
                                P
                              );
                            },
                            argPackAdvance: 8,
                            readValueFromPointer: yt,
                            v: function (g) {
                              nt(g);
                            },
                          });
                        },
                        _embind_register_value_object: function (
                          r,
                          t,
                          o,
                          a,
                          u,
                          l
                        ) {
                          It[r] = {
                            name: j(t),
                            fa: Me(o, a),
                            H: Me(u, l),
                            sa: [],
                          };
                        },
                        _embind_register_value_object_field: function (
                          r,
                          t,
                          o,
                          a,
                          u,
                          l,
                          m,
                          p,
                          g,
                          v
                        ) {
                          It[r].sa.push({
                            Sa: j(t),
                            Ya: o,
                            Wa: Me(a, u),
                            Xa: l,
                            lb: m,
                            kb: Me(p, g),
                            mb: v,
                          });
                        },
                        _embind_register_void: function (r, t) {
                          (t = j(t)),
                            Xe(r, {
                              cb: !0,
                              name: t,
                              argPackAdvance: 0,
                              fromWireType: function () {},
                              toWireType: function () {},
                            });
                        },
                        _emscripten_get_now_is_monotonic: () => !0,
                        _emval_as: function (r, t, o) {
                          (r = y(r)), (t = xe(t, "emval::as"));
                          var a = [],
                            u = L(a);
                          return (q[o >> 2] = u), t.toWireType(a, r);
                        },
                        _emval_call_method: function (r, t, o, a, u) {
                          (r = jt[r]), (t = y(t)), (o = St(o));
                          var l = [];
                          return (q[a >> 2] = L(l)), r(t, o, l, u);
                        },
                        _emval_call_void_method: function (r, t, o, a) {
                          (r = jt[r]),
                            (t = y(t)),
                            (o = St(o)),
                            r(t, o, null, a);
                        },
                        _emval_decref: Xt,
                        _emval_get_method_caller: function (r, t) {
                          var o = Bn(r, t),
                            a = o[0];
                          t =
                            a.name +
                            "_$" +
                            o
                              .slice(1)
                              .map(function (m) {
                                return m.name;
                              })
                              .join("_") +
                            "$";
                          var u = un[t];
                          if (u !== void 0) return u;
                          var l = Array(r - 1);
                          return (
                            (u = Un((m, p, g, v) => {
                              for (var A = 0, P = 0; P < r - 1; ++P)
                                (l[P] = o[P + 1].readValueFromPointer(v + A)),
                                  (A += o[P + 1].argPackAdvance);
                              for (m = m[p].apply(m, l), P = 0; P < r - 1; ++P)
                                o[P + 1].Na && o[P + 1].Na(l[P]);
                              if (!a.cb) return a.toWireType(g, m);
                            })),
                            (un[t] = u)
                          );
                        },
                        _emval_get_module_property: function (r) {
                          return (r = St(r)), L(c[r]);
                        },
                        _emval_get_property: function (r, t) {
                          return (r = y(r)), (t = y(t)), L(r[t]);
                        },
                        _emval_incref: function (r) {
                          4 < r && (s.get(r).Aa += 1);
                        },
                        _emval_new_array: function () {
                          return L([]);
                        },
                        _emval_new_cstring: function (r) {
                          return L(St(r));
                        },
                        _emval_new_object: function () {
                          return L({});
                        },
                        _emval_run_destructors: function (r) {
                          var t = y(r);
                          gt(t), Xt(r);
                        },
                        _emval_set_property: function (r, t, o) {
                          (r = y(r)), (t = y(t)), (o = y(o)), (r[t] = o);
                        },
                        _emval_take_value: function (r, t) {
                          return (
                            (r = xe(r, "_emval_take_value")),
                            (r = r.readValueFromPointer(t)),
                            L(r)
                          );
                        },
                        abort: () => {
                          ft("");
                        },
                        emscripten_date_now: function () {
                          return Date.now();
                        },
                        emscripten_get_now: () => performance.now(),
                        emscripten_memcpy_big: (r, t, o) =>
                          le.copyWithin(r, t, t + o),
                        emscripten_resize_heap: (r) => {
                          var t = le.length;
                          if (((r >>>= 0), 2147483648 < r)) return !1;
                          for (var o = 1; 4 >= o; o *= 2) {
                            var a = t * (1 + 0.2 / o);
                            a = Math.min(a, r + 100663296);
                            var u = Math;
                            a = Math.max(r, a);
                            e: {
                              u =
                                (u.min.call(
                                  u,
                                  2147483648,
                                  a + ((65536 - (a % 65536)) % 65536)
                                ) -
                                  Ke.buffer.byteLength +
                                  65535) >>>
                                16;
                              try {
                                Ke.grow(u), Oe();
                                var l = 1;
                                break e;
                              } catch {}
                              l = void 0;
                            }
                            if (l) return !0;
                          }
                          return !1;
                        },
                        environ_get: (r, t) => {
                          var o = 0;
                          return (
                            ln().forEach(function (a, u) {
                              var l = t + o;
                              for (
                                u = q[(r + 4 * u) >> 2] = l, l = 0;
                                l < a.length;
                                ++l
                              )
                                ke[u++ >> 0] = a.charCodeAt(l);
                              (ke[u >> 0] = 0), (o += a.length + 1);
                            }),
                            0
                          );
                        },
                        environ_sizes_get: (r, t) => {
                          var o = ln();
                          q[r >> 2] = o.length;
                          var a = 0;
                          return (
                            o.forEach(function (u) {
                              a += u.length + 1;
                            }),
                            (q[t >> 2] = a),
                            0
                          );
                        },
                        fd_close: () => 52,
                        fd_seek: function () {
                          return 70;
                        },
                        fd_write: (r, t, o, a) => {
                          for (var u = 0, l = 0; l < o; l++) {
                            var m = q[t >> 2],
                              p = q[(t + 4) >> 2];
                            t += 8;
                            for (var g = 0; g < p; g++) {
                              var v = le[m + g],
                                A = Nn[r];
                              v === 0 || v === 10
                                ? ((r === 1 ? he : ye)(Ot(A, 0)),
                                  (A.length = 0))
                                : A.push(v);
                            }
                            u += p;
                          }
                          return (q[a >> 2] = u), 0;
                        },
                        strftime_l: (r, t, o, a) => $n(r, t, o, a),
                      };
                      (function () {
                        function r(o) {
                          if (
                            ((ae = o = o.exports),
                            (Ke = ae.memory),
                            Oe(),
                            (ce = ae.__indirect_function_table),
                            it.unshift(ae.__wasm_call_ctors),
                            Ee--,
                            c.monitorRunDependencies &&
                              c.monitorRunDependencies(Ee),
                            Ee == 0 && Ue)
                          ) {
                            var a = Ue;
                            (Ue = null), a();
                          }
                          return o;
                        }
                        var t = { env: dn, wasi_snapshot_preview1: dn };
                        if (
                          (Ee++,
                          c.monitorRunDependencies &&
                            c.monitorRunDependencies(Ee),
                          c.instantiateWasm)
                        )
                          try {
                            return c.instantiateWasm(t, r);
                          } catch (o) {
                            ye(
                              "Module.instantiateWasm callback failed with error: " +
                                o
                            ),
                              fe(o);
                          }
                        return (
                          Nt(t, function (o) {
                            r(o.instance);
                          }).catch(fe),
                          {}
                        );
                      })();
                      var nt = (r) => (nt = ae.free)(r),
                        Jt = (r) => (Jt = ae.malloc)(r),
                        pn = (r) => (pn = ae.__getTypeName)(r);
                      (c.__embind_initialize_bindings = () =>
                        (c.__embind_initialize_bindings =
                          ae._embind_initialize_bindings)()),
                        (c.dynCall_jiji = (r, t, o, a, u) =>
                          (c.dynCall_jiji = ae.dynCall_jiji)(r, t, o, a, u)),
                        (c.dynCall_viijii = (r, t, o, a, u, l, m) =>
                          (c.dynCall_viijii = ae.dynCall_viijii)(
                            r,
                            t,
                            o,
                            a,
                            u,
                            l,
                            m
                          )),
                        (c.dynCall_iiiiij = (r, t, o, a, u, l, m) =>
                          (c.dynCall_iiiiij = ae.dynCall_iiiiij)(
                            r,
                            t,
                            o,
                            a,
                            u,
                            l,
                            m
                          )),
                        (c.dynCall_iiiiijj = (r, t, o, a, u, l, m, p, g) =>
                          (c.dynCall_iiiiijj = ae.dynCall_iiiiijj)(
                            r,
                            t,
                            o,
                            a,
                            u,
                            l,
                            m,
                            p,
                            g
                          )),
                        (c.dynCall_iiiiiijj = (r, t, o, a, u, l, m, p, g, v) =>
                          (c.dynCall_iiiiiijj = ae.dynCall_iiiiiijj)(
                            r,
                            t,
                            o,
                            a,
                            u,
                            l,
                            m,
                            p,
                            g,
                            v
                          ));
                      var Vt;
                      Ue = function r() {
                        Vt || vn(), Vt || (Ue = r);
                      };
                      function vn() {
                        function r() {
                          if (!Vt && ((Vt = !0), (c.calledRun = !0), !ct)) {
                            if (
                              (mt(it),
                              me(c),
                              c.onRuntimeInitialized &&
                                c.onRuntimeInitialized(),
                              c.postRun)
                            )
                              for (
                                typeof c.postRun == "function" &&
                                (c.postRun = [c.postRun]);
                                c.postRun.length;

                              ) {
                                var t = c.postRun.shift();
                                Qe.unshift(t);
                              }
                            mt(Qe);
                          }
                        }
                        if (!(0 < Ee)) {
                          if (c.preRun)
                            for (
                              typeof c.preRun == "function" &&
                              (c.preRun = [c.preRun]);
                              c.preRun.length;

                            )
                              at();
                          mt(Je),
                            0 < Ee ||
                              (c.setStatus
                                ? (c.setStatus("Running..."),
                                  setTimeout(function () {
                                    setTimeout(function () {
                                      c.setStatus("");
                                    }, 1),
                                      r();
                                  }, 1))
                                : r());
                        }
                      }
                      if (c.preInit)
                        for (
                          typeof c.preInit == "function" &&
                          (c.preInit = [c.preInit]);
                          0 < c.preInit.length;

                        )
                          c.preInit.pop()();
                      return vn(), T.ready;
                    };
                  })();
                  const K = G;
                },
                (se) => {
                  se.exports = JSON.parse(
                    `{"name":"@rive-app/canvas-lite","version":"2.31.5","description":"A lite version of Rive's canvas based web api.","main":"rive.js","homepage":"https://rive.app","repository":{"type":"git","url":"https://github.com/rive-app/rive-wasm/tree/master/js"},"keywords":["rive","animation"],"author":"Rive","contributors":["Luigi Rosso <luigi@rive.app> (https://rive.app)","Maxwell Talbot <max@rive.app> (https://rive.app)","Arthur Vivian <arthur@rive.app> (https://rive.app)","Umberto Sonnino <umberto@rive.app> (https://rive.app)","Matthew Sullivan <matt.j.sullivan@gmail.com> (mailto:matt.j.sullivan@gmail.com)"],"license":"MIT","files":["rive.js","rive.js.map","rive.wasm","rive_fallback.wasm","rive.d.ts","rive_advanced.mjs.d.ts"],"typings":"rive.d.ts","dependencies":{},"browser":{"fs":false,"path":false}}`
                  );
                },
                (se, B, k) => {
                  k.r(B), k.d(B, { Animation: () => G.Animation });
                  var G = k(4);
                },
                (se, B, k) => {
                  k.r(B), k.d(B, { Animation: () => G });
                  var G = (function () {
                    function K(Y, T, c, me) {
                      (this.animation = Y),
                        (this.artboard = T),
                        (this.playing = me),
                        (this.loopCount = 0),
                        (this.scrubTo = null),
                        (this.instance = new c.LinearAnimationInstance(Y, T));
                    }
                    return (
                      Object.defineProperty(K.prototype, "name", {
                        get: function () {
                          return this.animation.name;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      Object.defineProperty(K.prototype, "time", {
                        get: function () {
                          return this.instance.time;
                        },
                        set: function (Y) {
                          this.instance.time = Y;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      Object.defineProperty(K.prototype, "loopValue", {
                        get: function () {
                          return this.animation.loopValue;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      Object.defineProperty(K.prototype, "needsScrub", {
                        get: function () {
                          return this.scrubTo !== null;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      (K.prototype.advance = function (Y) {
                        this.scrubTo === null
                          ? this.instance.advance(Y)
                          : ((this.instance.time = 0),
                            this.instance.advance(this.scrubTo),
                            (this.scrubTo = null));
                      }),
                      (K.prototype.apply = function (Y) {
                        this.instance.apply(Y);
                      }),
                      (K.prototype.cleanup = function () {
                        this.instance.delete();
                      }),
                      K
                    );
                  })();
                },
                (se, B, k) => {
                  k.r(B),
                    k.d(B, {
                      AudioAssetWrapper: () => Y.AudioAssetWrapper,
                      AudioWrapper: () => Y.AudioWrapper,
                      BLANK_URL: () => K.BLANK_URL,
                      CustomFileAssetLoaderWrapper: () =>
                        Y.CustomFileAssetLoaderWrapper,
                      FileAssetWrapper: () => Y.FileAssetWrapper,
                      FileFinalizer: () => Y.FileFinalizer,
                      FontAssetWrapper: () => Y.FontAssetWrapper,
                      FontWrapper: () => Y.FontWrapper,
                      ImageAssetWrapper: () => Y.ImageAssetWrapper,
                      ImageWrapper: () => Y.ImageWrapper,
                      createFinalization: () => Y.createFinalization,
                      finalizationRegistry: () => Y.finalizationRegistry,
                      registerTouchInteractions: () =>
                        G.registerTouchInteractions,
                      sanitizeUrl: () => K.sanitizeUrl,
                    });
                  var G = k(6),
                    K = k(7),
                    Y = k(8);
                },
                (se, B, k) => {
                  k.r(B), k.d(B, { registerTouchInteractions: () => Y });
                  var G = void 0,
                    K = function (T, c) {
                      var me, fe;
                      return ["touchstart", "touchmove"].indexOf(T.type) > -1 &&
                        !((me = T.touches) === null || me === void 0) &&
                        me.length
                        ? (c || T.preventDefault(),
                          {
                            clientX: T.touches[0].clientX,
                            clientY: T.touches[0].clientY,
                          })
                        : T.type === "touchend" &&
                          !(
                            (fe = T.changedTouches) === null || fe === void 0
                          ) &&
                          fe.length
                        ? {
                            clientX: T.changedTouches[0].clientX,
                            clientY: T.changedTouches[0].clientY,
                          }
                        : { clientX: T.clientX, clientY: T.clientY };
                    },
                    Y = function (T) {
                      var c = T.canvas,
                        me = T.artboard,
                        fe = T.stateMachines,
                        Le = fe === void 0 ? [] : fe,
                        ee = T.renderer,
                        te = T.rive,
                        Ce = T.fit,
                        ne = T.alignment,
                        ue = T.isTouchScrollEnabled,
                        ge = ue === void 0 ? !1 : ue,
                        Te = T.layoutScaleFactor,
                        rt = Te === void 0 ? 1 : Te;
                      if (
                        !c ||
                        !Le.length ||
                        !ee ||
                        !te ||
                        !me ||
                        typeof window > "u"
                      )
                        return null;
                      var R = null,
                        M = !1,
                        I = function (he) {
                          if (M && he instanceof MouseEvent) {
                            he.type == "mouseup" && (M = !1);
                            return;
                          }
                          (M =
                            ge && he.type === "touchend" && R === "touchstart"),
                            (R = he.type);
                          var ye = he.currentTarget.getBoundingClientRect(),
                            we = K(he, ge),
                            Ke = we.clientX,
                            ae = we.clientY;
                          if (!(!Ke && !ae)) {
                            var ct = Ke - ye.left,
                              ke = ae - ye.top,
                              le = te.computeAlignment(
                                Ce,
                                ne,
                                {
                                  minX: 0,
                                  minY: 0,
                                  maxX: ye.width,
                                  maxY: ye.height,
                                },
                                me.bounds,
                                rt
                              ),
                              Pe = new te.Mat2D();
                            le.invert(Pe);
                            var De = new te.Vec2D(ct, ke),
                              re = te.mapXY(Pe, De),
                              q = re.x(),
                              Ye = re.y();
                            switch (
                              (re.delete(),
                              Pe.delete(),
                              De.delete(),
                              le.delete(),
                              he.type)
                            ) {
                              case "mouseout":
                                for (var Z = 0, Oe = Le; Z < Oe.length; Z++) {
                                  var ce = Oe[Z];
                                  ce.pointerMove(q, Ye);
                                }
                                break;
                              case "touchmove":
                              case "mouseover":
                              case "mousemove": {
                                for (
                                  var Je = 0, it = Le;
                                  Je < it.length;
                                  Je++
                                ) {
                                  var ce = it[Je];
                                  ce.pointerMove(q, Ye);
                                }
                                break;
                              }
                              case "touchstart":
                              case "mousedown": {
                                for (
                                  var Qe = 0, at = Le;
                                  Qe < at.length;
                                  Qe++
                                ) {
                                  var ce = at[Qe];
                                  ce.pointerDown(q, Ye);
                                }
                                break;
                              }
                              case "touchend":
                              case "mouseup": {
                                for (
                                  var Ee = 0, Ue = Le;
                                  Ee < Ue.length;
                                  Ee++
                                ) {
                                  var ce = Ue[Ee];
                                  ce.pointerUp(q, Ye);
                                }
                                break;
                              }
                            }
                          }
                        },
                        O = I.bind(G);
                      return (
                        c.addEventListener("mouseover", O),
                        c.addEventListener("mouseout", O),
                        c.addEventListener("mousemove", O),
                        c.addEventListener("mousedown", O),
                        c.addEventListener("mouseup", O),
                        c.addEventListener("touchmove", O, { passive: ge }),
                        c.addEventListener("touchstart", O, { passive: ge }),
                        c.addEventListener("touchend", O),
                        function () {
                          c.removeEventListener("mouseover", O),
                            c.removeEventListener("mouseout", O),
                            c.removeEventListener("mousemove", O),
                            c.removeEventListener("mousedown", O),
                            c.removeEventListener("mouseup", O),
                            c.removeEventListener("touchmove", O),
                            c.removeEventListener("touchstart", O),
                            c.removeEventListener("touchend", O);
                        }
                      );
                    };
                },
                (se, B, k) => {
                  k.r(B),
                    k.d(B, { BLANK_URL: () => fe, sanitizeUrl: () => te });
                  var G = /^([^\w]*)(javascript|data|vbscript)/im,
                    K = /&#(\w+)(^\w|;)?/g,
                    Y = /&(newline|tab);/gi,
                    T = /[\u0000-\u001F\u007F-\u009F\u2000-\u200D\uFEFF]/gim,
                    c = /^.+(:|&colon;)/gim,
                    me = [".", "/"],
                    fe = "about:blank";
                  function Le(Ce) {
                    return me.indexOf(Ce[0]) > -1;
                  }
                  function ee(Ce) {
                    var ne = Ce.replace(T, "");
                    return ne.replace(K, function (ue, ge) {
                      return String.fromCharCode(ge);
                    });
                  }
                  function te(Ce) {
                    if (!Ce) return fe;
                    var ne = ee(Ce).replace(Y, "").replace(T, "").trim();
                    if (!ne) return fe;
                    if (Le(ne)) return ne;
                    var ue = ne.match(c);
                    if (!ue) return ne;
                    var ge = ue[0];
                    return G.test(ge) ? fe : ne;
                  }
                },
                (se, B, k) => {
                  k.r(B),
                    k.d(B, {
                      AudioAssetWrapper: () => Ce,
                      AudioWrapper: () => me,
                      CustomFileAssetLoaderWrapper: () => Le,
                      FileAssetWrapper: () => ee,
                      FileFinalizer: () => K,
                      FontAssetWrapper: () => ne,
                      FontWrapper: () => fe,
                      ImageAssetWrapper: () => te,
                      ImageWrapper: () => c,
                      createFinalization: () => rt,
                      finalizationRegistry: () => Te,
                    });
                  var G = (function () {
                      var R = function (M, I) {
                        return (
                          (R =
                            Object.setPrototypeOf ||
                            ({ __proto__: [] } instanceof Array &&
                              function (O, he) {
                                O.__proto__ = he;
                              }) ||
                            function (O, he) {
                              for (var ye in he)
                                Object.prototype.hasOwnProperty.call(he, ye) &&
                                  (O[ye] = he[ye]);
                            }),
                          R(M, I)
                        );
                      };
                      return function (M, I) {
                        if (typeof I != "function" && I !== null)
                          throw new TypeError(
                            "Class extends value " +
                              String(I) +
                              " is not a constructor or null"
                          );
                        R(M, I);
                        function O() {
                          this.constructor = M;
                        }
                        M.prototype =
                          I === null
                            ? Object.create(I)
                            : ((O.prototype = I.prototype), new O());
                      };
                    })(),
                    K = (function () {
                      function R(M) {
                        (this.selfUnref = !1), (this._file = M);
                      }
                      return (
                        (R.prototype.unref = function () {
                          this._file && this._file.unref();
                        }),
                        R
                      );
                    })(),
                    Y = (function () {
                      function R(M) {
                        this._finalizableObject = M;
                      }
                      return (
                        (R.prototype.unref = function () {
                          this._finalizableObject.unref();
                        }),
                        R
                      );
                    })(),
                    T = (function () {
                      function R() {
                        this.selfUnref = !1;
                      }
                      return (R.prototype.unref = function () {}), R;
                    })(),
                    c = (function (R) {
                      G(M, R);
                      function M(I) {
                        var O = R.call(this) || this;
                        return (O._nativeImage = I), O;
                      }
                      return (
                        Object.defineProperty(M.prototype, "nativeImage", {
                          get: function () {
                            return this._nativeImage;
                          },
                          enumerable: !1,
                          configurable: !0,
                        }),
                        (M.prototype.unref = function () {
                          this.selfUnref && this._nativeImage.unref();
                        }),
                        M
                      );
                    })(T),
                    me = (function (R) {
                      G(M, R);
                      function M(I) {
                        var O = R.call(this) || this;
                        return (O._nativeAudio = I), O;
                      }
                      return (
                        Object.defineProperty(M.prototype, "nativeAudio", {
                          get: function () {
                            return this._nativeAudio;
                          },
                          enumerable: !1,
                          configurable: !0,
                        }),
                        (M.prototype.unref = function () {
                          this.selfUnref && this._nativeAudio.unref();
                        }),
                        M
                      );
                    })(T),
                    fe = (function (R) {
                      G(M, R);
                      function M(I) {
                        var O = R.call(this) || this;
                        return (O._nativeFont = I), O;
                      }
                      return (
                        Object.defineProperty(M.prototype, "nativeFont", {
                          get: function () {
                            return this._nativeFont;
                          },
                          enumerable: !1,
                          configurable: !0,
                        }),
                        (M.prototype.unref = function () {
                          this.selfUnref && this._nativeFont.unref();
                        }),
                        M
                      );
                    })(T),
                    Le = (function () {
                      function R(M, I) {
                        (this._assetLoaderCallback = I),
                          (this.assetLoader = new M.CustomFileAssetLoader({
                            loadContents: this.loadContents.bind(this),
                          }));
                      }
                      return (
                        (R.prototype.loadContents = function (M, I) {
                          var O;
                          return (
                            M.isImage
                              ? (O = new te(M))
                              : M.isAudio
                              ? (O = new Ce(M))
                              : M.isFont && (O = new ne(M)),
                            this._assetLoaderCallback(O, I)
                          );
                        }),
                        R
                      );
                    })(),
                    ee = (function () {
                      function R(M) {
                        this._nativeFileAsset = M;
                      }
                      return (
                        (R.prototype.decode = function (M) {
                          this._nativeFileAsset.decode(M);
                        }),
                        Object.defineProperty(R.prototype, "name", {
                          get: function () {
                            return this._nativeFileAsset.name;
                          },
                          enumerable: !1,
                          configurable: !0,
                        }),
                        Object.defineProperty(R.prototype, "fileExtension", {
                          get: function () {
                            return this._nativeFileAsset.fileExtension;
                          },
                          enumerable: !1,
                          configurable: !0,
                        }),
                        Object.defineProperty(R.prototype, "uniqueFilename", {
                          get: function () {
                            return this._nativeFileAsset.uniqueFilename;
                          },
                          enumerable: !1,
                          configurable: !0,
                        }),
                        Object.defineProperty(R.prototype, "isAudio", {
                          get: function () {
                            return this._nativeFileAsset.isAudio;
                          },
                          enumerable: !1,
                          configurable: !0,
                        }),
                        Object.defineProperty(R.prototype, "isImage", {
                          get: function () {
                            return this._nativeFileAsset.isImage;
                          },
                          enumerable: !1,
                          configurable: !0,
                        }),
                        Object.defineProperty(R.prototype, "isFont", {
                          get: function () {
                            return this._nativeFileAsset.isFont;
                          },
                          enumerable: !1,
                          configurable: !0,
                        }),
                        Object.defineProperty(R.prototype, "cdnUuid", {
                          get: function () {
                            return this._nativeFileAsset.cdnUuid;
                          },
                          enumerable: !1,
                          configurable: !0,
                        }),
                        Object.defineProperty(R.prototype, "nativeFileAsset", {
                          get: function () {
                            return this._nativeFileAsset;
                          },
                          enumerable: !1,
                          configurable: !0,
                        }),
                        R
                      );
                    })(),
                    te = (function (R) {
                      G(M, R);
                      function M() {
                        return (R !== null && R.apply(this, arguments)) || this;
                      }
                      return (
                        (M.prototype.setRenderImage = function (I) {
                          this._nativeFileAsset.setRenderImage(I.nativeImage);
                        }),
                        M
                      );
                    })(ee),
                    Ce = (function (R) {
                      G(M, R);
                      function M() {
                        return (R !== null && R.apply(this, arguments)) || this;
                      }
                      return (
                        (M.prototype.setAudioSource = function (I) {
                          this._nativeFileAsset.setAudioSource(I.nativeAudio);
                        }),
                        M
                      );
                    })(ee),
                    ne = (function (R) {
                      G(M, R);
                      function M() {
                        return (R !== null && R.apply(this, arguments)) || this;
                      }
                      return (
                        (M.prototype.setFont = function (I) {
                          this._nativeFileAsset.setFont(I.nativeFont);
                        }),
                        M
                      );
                    })(ee),
                    ue = (function () {
                      function R(M) {}
                      return (
                        (R.prototype.register = function (M) {
                          M.selfUnref = !0;
                        }),
                        (R.prototype.unregister = function (M) {}),
                        R
                      );
                    })(),
                    ge =
                      typeof FinalizationRegistry < "u"
                        ? FinalizationRegistry
                        : ue,
                    Te = new ge(function (R) {
                      R?.unref();
                    }),
                    rt = function (R, M) {
                      var I = new Y(M);
                      Te.register(R, I);
                    };
                },
              ],
              Dt = {};
            function Re(se) {
              var B = Dt[se];
              if (B !== void 0) return B.exports;
              var k = (Dt[se] = { exports: {} });
              return Qt[se](k, k.exports, Re), k.exports;
            }
            (Re.d = (se, B) => {
              for (var k in B)
                Re.o(B, k) &&
                  !Re.o(se, k) &&
                  Object.defineProperty(se, k, { enumerable: !0, get: B[k] });
            }),
              (Re.o = (se, B) => Object.prototype.hasOwnProperty.call(se, B)),
              (Re.r = (se) => {
                typeof Symbol < "u" &&
                  Symbol.toStringTag &&
                  Object.defineProperty(se, Symbol.toStringTag, {
                    value: "Module",
                  }),
                  Object.defineProperty(se, "__esModule", { value: !0 });
              });
            var Ut = {};
            return (
              (() => {
                Re.r(Ut),
                  Re.d(Ut, {
                    Alignment: () => te,
                    DataEnum: () => Ye,
                    EventType: () => I,
                    Fit: () => ee,
                    Layout: () => Ce,
                    LoopType: () => O,
                    Rive: () => re,
                    RiveEventType: () => Te,
                    RiveFile: () => De,
                    RuntimeLoader: () => ne,
                    StateMachineInput: () => ge,
                    StateMachineInputType: () => ue,
                    Testing: () => Bt,
                    ViewModel: () => q,
                    ViewModelInstance: () => Oe,
                    ViewModelInstanceArtboard: () => qe,
                    ViewModelInstanceAssetImage: () => vt,
                    ViewModelInstanceBoolean: () => Qe,
                    ViewModelInstanceColor: () => ft,
                    ViewModelInstanceEnum: () => Ee,
                    ViewModelInstanceList: () => Ue,
                    ViewModelInstanceNumber: () => it,
                    ViewModelInstanceString: () => Je,
                    ViewModelInstanceTrigger: () => at,
                    ViewModelInstanceValue: () => ce,
                    decodeAudio: () => At,
                    decodeFont: () => mt,
                    decodeImage: () => Nt,
                  });
                var se = Re(1),
                  B = Re(2),
                  k = Re(3),
                  G = Re(5),
                  K = (function () {
                    var i = function (e, n) {
                      return (
                        (i =
                          Object.setPrototypeOf ||
                          ({ __proto__: [] } instanceof Array &&
                            function (s, h) {
                              s.__proto__ = h;
                            }) ||
                          function (s, h) {
                            for (var d in h)
                              Object.prototype.hasOwnProperty.call(h, d) &&
                                (s[d] = h[d]);
                          }),
                        i(e, n)
                      );
                    };
                    return function (e, n) {
                      if (typeof n != "function" && n !== null)
                        throw new TypeError(
                          "Class extends value " +
                            String(n) +
                            " is not a constructor or null"
                        );
                      i(e, n);
                      function s() {
                        this.constructor = e;
                      }
                      e.prototype =
                        n === null
                          ? Object.create(n)
                          : ((s.prototype = n.prototype), new s());
                    };
                  })(),
                  Y = function () {
                    return (
                      (Y =
                        Object.assign ||
                        function (i) {
                          for (var e, n = 1, s = arguments.length; n < s; n++) {
                            e = arguments[n];
                            for (var h in e)
                              Object.prototype.hasOwnProperty.call(e, h) &&
                                (i[h] = e[h]);
                          }
                          return i;
                        }),
                      Y.apply(this, arguments)
                    );
                  },
                  T = function (i, e, n, s) {
                    function h(d) {
                      return d instanceof n
                        ? d
                        : new n(function (y) {
                            y(d);
                          });
                    }
                    return new (n || (n = Promise))(function (d, y) {
                      function L(V) {
                        try {
                          F(s.next(V));
                        } catch (j) {
                          y(j);
                        }
                      }
                      function W(V) {
                        try {
                          F(s.throw(V));
                        } catch (j) {
                          y(j);
                        }
                      }
                      function F(V) {
                        V.done ? d(V.value) : h(V.value).then(L, W);
                      }
                      F((s = s.apply(i, e || [])).next());
                    });
                  },
                  c = function (i, e) {
                    var n = {
                        label: 0,
                        sent: function () {
                          if (d[0] & 1) throw d[1];
                          return d[1];
                        },
                        trys: [],
                        ops: [],
                      },
                      s,
                      h,
                      d,
                      y = Object.create(
                        (typeof Iterator == "function" ? Iterator : Object)
                          .prototype
                      );
                    return (
                      (y.next = L(0)),
                      (y.throw = L(1)),
                      (y.return = L(2)),
                      typeof Symbol == "function" &&
                        (y[Symbol.iterator] = function () {
                          return this;
                        }),
                      y
                    );
                    function L(F) {
                      return function (V) {
                        return W([F, V]);
                      };
                    }
                    function W(F) {
                      if (s)
                        throw new TypeError("Generator is already executing.");
                      for (; y && ((y = 0), F[0] && (n = 0)), n; )
                        try {
                          if (
                            ((s = 1),
                            h &&
                              (d =
                                F[0] & 2
                                  ? h.return
                                  : F[0]
                                  ? h.throw || ((d = h.return) && d.call(h), 0)
                                  : h.next) &&
                              !(d = d.call(h, F[1])).done)
                          )
                            return d;
                          switch (
                            ((h = 0), d && (F = [F[0] & 2, d.value]), F[0])
                          ) {
                            case 0:
                            case 1:
                              d = F;
                              break;
                            case 4:
                              return n.label++, { value: F[1], done: !1 };
                            case 5:
                              n.label++, (h = F[1]), (F = [0]);
                              continue;
                            case 7:
                              (F = n.ops.pop()), n.trys.pop();
                              continue;
                            default:
                              if (
                                ((d = n.trys),
                                !(d = d.length > 0 && d[d.length - 1]) &&
                                  (F[0] === 6 || F[0] === 2))
                              ) {
                                n = 0;
                                continue;
                              }
                              if (
                                F[0] === 3 &&
                                (!d || (F[1] > d[0] && F[1] < d[3]))
                              ) {
                                n.label = F[1];
                                break;
                              }
                              if (F[0] === 6 && n.label < d[1]) {
                                (n.label = d[1]), (d = F);
                                break;
                              }
                              if (d && n.label < d[2]) {
                                (n.label = d[2]), n.ops.push(F);
                                break;
                              }
                              d[2] && n.ops.pop(), n.trys.pop();
                              continue;
                          }
                          F = e.call(i, n);
                        } catch (V) {
                          (F = [6, V]), (h = 0);
                        } finally {
                          s = d = 0;
                        }
                      if (F[0] & 5) throw F[1];
                      return { value: F[0] ? F[1] : void 0, done: !0 };
                    }
                  },
                  me = function (i, e, n) {
                    if (n || arguments.length === 2)
                      for (var s = 0, h = e.length, d; s < h; s++)
                        (d || !(s in e)) &&
                          (d || (d = Array.prototype.slice.call(e, 0, s)),
                          (d[s] = e[s]));
                    return i.concat(d || Array.prototype.slice.call(e));
                  },
                  fe = (function (i) {
                    K(e, i);
                    function e() {
                      var n = (i !== null && i.apply(this, arguments)) || this;
                      return (n.isHandledError = !0), n;
                    }
                    return e;
                  })(Error),
                  Le = function (i) {
                    return i && i.isHandledError
                      ? i.message
                      : "Problem loading file; may be corrupt!";
                  },
                  ee;
                (function (i) {
                  (i.Cover = "cover"),
                    (i.Contain = "contain"),
                    (i.Fill = "fill"),
                    (i.FitWidth = "fitWidth"),
                    (i.FitHeight = "fitHeight"),
                    (i.None = "none"),
                    (i.ScaleDown = "scaleDown"),
                    (i.Layout = "layout");
                })(ee || (ee = {}));
                var te;
                (function (i) {
                  (i.Center = "center"),
                    (i.TopLeft = "topLeft"),
                    (i.TopCenter = "topCenter"),
                    (i.TopRight = "topRight"),
                    (i.CenterLeft = "centerLeft"),
                    (i.CenterRight = "centerRight"),
                    (i.BottomLeft = "bottomLeft"),
                    (i.BottomCenter = "bottomCenter"),
                    (i.BottomRight = "bottomRight");
                })(te || (te = {}));
                var Ce = (function () {
                    function i(e) {
                      var n, s, h, d, y, L, W;
                      (this.fit =
                        (n = e?.fit) !== null && n !== void 0 ? n : ee.Contain),
                        (this.alignment =
                          (s = e?.alignment) !== null && s !== void 0
                            ? s
                            : te.Center),
                        (this.layoutScaleFactor =
                          (h = e?.layoutScaleFactor) !== null && h !== void 0
                            ? h
                            : 1),
                        (this.minX =
                          (d = e?.minX) !== null && d !== void 0 ? d : 0),
                        (this.minY =
                          (y = e?.minY) !== null && y !== void 0 ? y : 0),
                        (this.maxX =
                          (L = e?.maxX) !== null && L !== void 0 ? L : 0),
                        (this.maxY =
                          (W = e?.maxY) !== null && W !== void 0 ? W : 0);
                    }
                    return (
                      (i.new = function (e) {
                        var n = e.fit,
                          s = e.alignment,
                          h = e.minX,
                          d = e.minY,
                          y = e.maxX,
                          L = e.maxY;
                        return (
                          console.warn(
                            "This function is deprecated: please use `new Layout({})` instead"
                          ),
                          new i({
                            fit: n,
                            alignment: s,
                            minX: h,
                            minY: d,
                            maxX: y,
                            maxY: L,
                          })
                        );
                      }),
                      (i.prototype.copyWith = function (e) {
                        var n = e.fit,
                          s = e.alignment,
                          h = e.layoutScaleFactor,
                          d = e.minX,
                          y = e.minY,
                          L = e.maxX,
                          W = e.maxY;
                        return new i({
                          fit: n ?? this.fit,
                          alignment: s ?? this.alignment,
                          layoutScaleFactor: h ?? this.layoutScaleFactor,
                          minX: d ?? this.minX,
                          minY: y ?? this.minY,
                          maxX: L ?? this.maxX,
                          maxY: W ?? this.maxY,
                        });
                      }),
                      (i.prototype.runtimeFit = function (e) {
                        if (this.cachedRuntimeFit) return this.cachedRuntimeFit;
                        var n;
                        return (
                          this.fit === ee.Cover
                            ? (n = e.Fit.cover)
                            : this.fit === ee.Contain
                            ? (n = e.Fit.contain)
                            : this.fit === ee.Fill
                            ? (n = e.Fit.fill)
                            : this.fit === ee.FitWidth
                            ? (n = e.Fit.fitWidth)
                            : this.fit === ee.FitHeight
                            ? (n = e.Fit.fitHeight)
                            : this.fit === ee.ScaleDown
                            ? (n = e.Fit.scaleDown)
                            : this.fit === ee.Layout
                            ? (n = e.Fit.layout)
                            : (n = e.Fit.none),
                          (this.cachedRuntimeFit = n),
                          n
                        );
                      }),
                      (i.prototype.runtimeAlignment = function (e) {
                        if (this.cachedRuntimeAlignment)
                          return this.cachedRuntimeAlignment;
                        var n;
                        return (
                          this.alignment === te.TopLeft
                            ? (n = e.Alignment.topLeft)
                            : this.alignment === te.TopCenter
                            ? (n = e.Alignment.topCenter)
                            : this.alignment === te.TopRight
                            ? (n = e.Alignment.topRight)
                            : this.alignment === te.CenterLeft
                            ? (n = e.Alignment.centerLeft)
                            : this.alignment === te.CenterRight
                            ? (n = e.Alignment.centerRight)
                            : this.alignment === te.BottomLeft
                            ? (n = e.Alignment.bottomLeft)
                            : this.alignment === te.BottomCenter
                            ? (n = e.Alignment.bottomCenter)
                            : this.alignment === te.BottomRight
                            ? (n = e.Alignment.bottomRight)
                            : (n = e.Alignment.center),
                          (this.cachedRuntimeAlignment = n),
                          n
                        );
                      }),
                      i
                    );
                  })(),
                  ne = (function () {
                    function i() {}
                    return (
                      (i.loadRuntime = function () {
                        se.default({
                          locateFile: function () {
                            return i.wasmURL;
                          },
                        })
                          .then(function (e) {
                            var n;
                            for (i.runtime = e; i.callBackQueue.length > 0; )
                              (n = i.callBackQueue.shift()) === null ||
                                n === void 0 ||
                                n(i.runtime);
                          })
                          .catch(function (e) {
                            var n = {
                              message: e?.message || "Unknown error",
                              type: e?.name || "Error",
                              wasmError:
                                e instanceof WebAssembly.CompileError ||
                                e instanceof WebAssembly.RuntimeError,
                              originalError: e,
                            };
                            console.debug("Rive WASM load error details:", n);
                            var s = "https://cdn.jsdelivr.net/npm/"
                              .concat(B.name, "@")
                              .concat(B.version, "/rive_fallback.wasm");
                            if (i.wasmURL.toLowerCase() !== s)
                              console.warn(
                                "Failed to load WASM from "
                                  .concat(i.wasmURL, " (")
                                  .concat(
                                    n.message,
                                    "), trying jsdelivr as a backup"
                                  )
                              ),
                                i.setWasmUrl(s),
                                i.loadRuntime();
                            else {
                              var h = [
                                "Could not load Rive WASM file from "
                                  .concat(i.wasmURL, " or ")
                                  .concat(s, "."),
                                "Possible reasons:",
                                "- Network connection is down",
                                "- WebAssembly is not supported in this environment",
                                "- The WASM file is corrupted or incompatible",
                                `
Error details:`,
                                "- Type: ".concat(n.type),
                                "- Message: ".concat(n.message),
                                "- WebAssembly-specific error: ".concat(
                                  n.wasmError
                                ),
                                `
To resolve, you may need to:`,
                                "1. Check your network connection",
                                "2. Set a new WASM source via RuntimeLoader.setWasmUrl()",
                                "3. Call RuntimeLoader.loadRuntime() again",
                              ].join(`
`);
                              console.error(h);
                            }
                          });
                      }),
                      (i.getInstance = function (e) {
                        i.isLoading || ((i.isLoading = !0), i.loadRuntime()),
                          i.runtime ? e(i.runtime) : i.callBackQueue.push(e);
                      }),
                      (i.awaitInstance = function () {
                        return new Promise(function (e) {
                          return i.getInstance(function (n) {
                            return e(n);
                          });
                        });
                      }),
                      (i.setWasmUrl = function (e) {
                        i.wasmURL = e;
                      }),
                      (i.getWasmUrl = function () {
                        return i.wasmURL;
                      }),
                      (i.isLoading = !1),
                      (i.callBackQueue = []),
                      (i.wasmURL = "https://unpkg.com/"
                        .concat(B.name, "@")
                        .concat(B.version, "/rive.wasm")),
                      i
                    );
                  })(),
                  ue;
                (function (i) {
                  (i[(i.Number = 56)] = "Number"),
                    (i[(i.Trigger = 58)] = "Trigger"),
                    (i[(i.Boolean = 59)] = "Boolean");
                })(ue || (ue = {}));
                var ge = (function () {
                    function i(e, n) {
                      (this.type = e), (this.runtimeInput = n);
                    }
                    return (
                      Object.defineProperty(i.prototype, "name", {
                        get: function () {
                          return this.runtimeInput.name;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      Object.defineProperty(i.prototype, "value", {
                        get: function () {
                          return this.runtimeInput.value;
                        },
                        set: function (e) {
                          this.runtimeInput.value = e;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      (i.prototype.fire = function () {
                        this.type === ue.Trigger && this.runtimeInput.fire();
                      }),
                      (i.prototype.delete = function () {
                        this.runtimeInput = null;
                      }),
                      i
                    );
                  })(),
                  Te;
                (function (i) {
                  (i[(i.General = 128)] = "General"),
                    (i[(i.OpenUrl = 131)] = "OpenUrl");
                })(Te || (Te = {}));
                var rt = (function () {
                    function i(e) {
                      this.nativeArtboard = e;
                    }
                    return i;
                  })(),
                  R = (function () {
                    function i(e, n, s, h) {
                      (this.stateMachine = e),
                        (this.playing = s),
                        (this.artboard = h),
                        (this.inputs = []),
                        (this.instance = new n.StateMachineInstance(e, h)),
                        this.initInputs(n);
                    }
                    return (
                      Object.defineProperty(i.prototype, "name", {
                        get: function () {
                          return this.stateMachine.name;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      Object.defineProperty(i.prototype, "statesChanged", {
                        get: function () {
                          for (
                            var e = [], n = 0;
                            n < this.instance.stateChangedCount();
                            n++
                          )
                            e.push(this.instance.stateChangedNameByIndex(n));
                          return e;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      (i.prototype.advance = function (e) {
                        this.instance.advance(e);
                      }),
                      (i.prototype.advanceAndApply = function (e) {
                        this.instance.advanceAndApply(e);
                      }),
                      (i.prototype.reportedEventCount = function () {
                        return this.instance.reportedEventCount();
                      }),
                      (i.prototype.reportedEventAt = function (e) {
                        return this.instance.reportedEventAt(e);
                      }),
                      (i.prototype.initInputs = function (e) {
                        for (var n = 0; n < this.instance.inputCount(); n++) {
                          var s = this.instance.input(n);
                          this.inputs.push(this.mapRuntimeInput(s, e));
                        }
                      }),
                      (i.prototype.mapRuntimeInput = function (e, n) {
                        if (e.type === n.SMIInput.bool)
                          return new ge(ue.Boolean, e.asBool());
                        if (e.type === n.SMIInput.number)
                          return new ge(ue.Number, e.asNumber());
                        if (e.type === n.SMIInput.trigger)
                          return new ge(ue.Trigger, e.asTrigger());
                      }),
                      (i.prototype.cleanup = function () {
                        this.inputs.forEach(function (e) {
                          e.delete();
                        }),
                          (this.inputs.length = 0),
                          this.instance.delete();
                      }),
                      (i.prototype.bindViewModelInstance = function (e) {
                        e.runtimeInstance != null &&
                          this.instance.bindViewModelInstance(
                            e.runtimeInstance
                          );
                      }),
                      i
                    );
                  })(),
                  M = (function () {
                    function i(e, n, s, h, d) {
                      h === void 0 && (h = []),
                        d === void 0 && (d = []),
                        (this.runtime = e),
                        (this.artboard = n),
                        (this.eventManager = s),
                        (this.animations = h),
                        (this.stateMachines = d);
                    }
                    return (
                      (i.prototype.add = function (e, n, s) {
                        if (
                          (s === void 0 && (s = !0),
                          (e = Se(e)),
                          e.length === 0)
                        )
                          this.animations.forEach(function (ie) {
                            return (ie.playing = n);
                          }),
                            this.stateMachines.forEach(function (ie) {
                              return (ie.playing = n);
                            });
                        else
                          for (
                            var h = this.animations.map(function (ie) {
                                return ie.name;
                              }),
                              d = this.stateMachines.map(function (ie) {
                                return ie.name;
                              }),
                              y = 0;
                            y < e.length;
                            y++
                          ) {
                            var L = h.indexOf(e[y]),
                              W = d.indexOf(e[y]);
                            if (L >= 0 || W >= 0)
                              L >= 0
                                ? (this.animations[L].playing = n)
                                : (this.stateMachines[W].playing = n);
                            else {
                              var F = this.artboard.animationByName(e[y]);
                              if (F) {
                                var V = new k.Animation(
                                  F,
                                  this.artboard,
                                  this.runtime,
                                  n
                                );
                                V.advance(0),
                                  V.apply(1),
                                  this.animations.push(V);
                              } else {
                                var j = this.artboard.stateMachineByName(e[y]);
                                if (j) {
                                  var de = new R(
                                    j,
                                    this.runtime,
                                    n,
                                    this.artboard
                                  );
                                  this.stateMachines.push(de);
                                }
                              }
                            }
                          }
                        return (
                          s &&
                            (n
                              ? this.eventManager.fire({
                                  type: I.Play,
                                  data: this.playing,
                                })
                              : this.eventManager.fire({
                                  type: I.Pause,
                                  data: this.paused,
                                })),
                          n ? this.playing : this.paused
                        );
                      }),
                      (i.prototype.initLinearAnimations = function (e, n) {
                        for (
                          var s = this.animations.map(function (W) {
                              return W.name;
                            }),
                            h = 0;
                          h < e.length;
                          h++
                        ) {
                          var d = s.indexOf(e[h]);
                          if (d >= 0) this.animations[d].playing = n;
                          else {
                            var y = this.artboard.animationByName(e[h]);
                            if (y) {
                              var L = new k.Animation(
                                y,
                                this.artboard,
                                this.runtime,
                                n
                              );
                              L.advance(0), L.apply(1), this.animations.push(L);
                            } else
                              console.error(
                                "Animation with name ".concat(
                                  e[h],
                                  " not found."
                                )
                              );
                          }
                        }
                      }),
                      (i.prototype.initStateMachines = function (e, n) {
                        for (
                          var s = this.stateMachines.map(function (W) {
                              return W.name;
                            }),
                            h = 0;
                          h < e.length;
                          h++
                        ) {
                          var d = s.indexOf(e[h]);
                          if (d >= 0) this.stateMachines[d].playing = n;
                          else {
                            var y = this.artboard.stateMachineByName(e[h]);
                            if (y) {
                              var L = new R(y, this.runtime, n, this.artboard);
                              this.stateMachines.push(L);
                            } else
                              console.warn(
                                "State Machine with name ".concat(
                                  e[h],
                                  " not found."
                                )
                              ),
                                this.initLinearAnimations([e[h]], n);
                          }
                        }
                      }),
                      (i.prototype.play = function (e) {
                        return this.add(e, !0);
                      }),
                      (i.prototype.advanceIfPaused = function () {
                        this.stateMachines.forEach(function (e) {
                          e.playing || e.advanceAndApply(0);
                        });
                      }),
                      (i.prototype.pause = function (e) {
                        return this.add(e, !1);
                      }),
                      (i.prototype.scrub = function (e, n) {
                        var s = this.animations.filter(function (h) {
                          return e.includes(h.name);
                        });
                        return (
                          s.forEach(function (h) {
                            return (h.scrubTo = n);
                          }),
                          s.map(function (h) {
                            return h.name;
                          })
                        );
                      }),
                      Object.defineProperty(i.prototype, "playing", {
                        get: function () {
                          return this.animations
                            .filter(function (e) {
                              return e.playing;
                            })
                            .map(function (e) {
                              return e.name;
                            })
                            .concat(
                              this.stateMachines
                                .filter(function (e) {
                                  return e.playing;
                                })
                                .map(function (e) {
                                  return e.name;
                                })
                            );
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      Object.defineProperty(i.prototype, "paused", {
                        get: function () {
                          return this.animations
                            .filter(function (e) {
                              return !e.playing;
                            })
                            .map(function (e) {
                              return e.name;
                            })
                            .concat(
                              this.stateMachines
                                .filter(function (e) {
                                  return !e.playing;
                                })
                                .map(function (e) {
                                  return e.name;
                                })
                            );
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      (i.prototype.stop = function (e) {
                        var n = this;
                        e = Se(e);
                        var s = [];
                        if (e.length === 0)
                          (s = this.animations
                            .map(function (y) {
                              return y.name;
                            })
                            .concat(
                              this.stateMachines.map(function (y) {
                                return y.name;
                              })
                            )),
                            this.animations.forEach(function (y) {
                              return y.cleanup();
                            }),
                            this.stateMachines.forEach(function (y) {
                              return y.cleanup();
                            }),
                            this.animations.splice(0, this.animations.length),
                            this.stateMachines.splice(
                              0,
                              this.stateMachines.length
                            );
                        else {
                          var h = this.animations.filter(function (y) {
                            return e.includes(y.name);
                          });
                          h.forEach(function (y) {
                            y.cleanup(),
                              n.animations.splice(n.animations.indexOf(y), 1);
                          });
                          var d = this.stateMachines.filter(function (y) {
                            return e.includes(y.name);
                          });
                          d.forEach(function (y) {
                            y.cleanup(),
                              n.stateMachines.splice(
                                n.stateMachines.indexOf(y),
                                1
                              );
                          }),
                            (s = h
                              .map(function (y) {
                                return y.name;
                              })
                              .concat(
                                d.map(function (y) {
                                  return y.name;
                                })
                              ));
                        }
                        return (
                          this.eventManager.fire({ type: I.Stop, data: s }), s
                        );
                      }),
                      Object.defineProperty(i.prototype, "isPlaying", {
                        get: function () {
                          return (
                            this.animations.reduce(function (e, n) {
                              return e || n.playing;
                            }, !1) ||
                            this.stateMachines.reduce(function (e, n) {
                              return e || n.playing;
                            }, !1)
                          );
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      Object.defineProperty(i.prototype, "isPaused", {
                        get: function () {
                          return (
                            !this.isPlaying &&
                            (this.animations.length > 0 ||
                              this.stateMachines.length > 0)
                          );
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      Object.defineProperty(i.prototype, "isStopped", {
                        get: function () {
                          return (
                            this.animations.length === 0 &&
                            this.stateMachines.length === 0
                          );
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      (i.prototype.atLeastOne = function (e, n) {
                        n === void 0 && (n = !0);
                        var s;
                        return (
                          this.animations.length === 0 &&
                            this.stateMachines.length === 0 &&
                            (this.artboard.animationCount() > 0
                              ? this.add(
                                  [
                                    (s =
                                      this.artboard.animationByIndex(0).name),
                                  ],
                                  e,
                                  n
                                )
                              : this.artboard.stateMachineCount() > 0 &&
                                this.add(
                                  [
                                    (s =
                                      this.artboard.stateMachineByIndex(
                                        0
                                      ).name),
                                  ],
                                  e,
                                  n
                                )),
                          s
                        );
                      }),
                      (i.prototype.handleLooping = function () {
                        for (
                          var e = 0,
                            n = this.animations.filter(function (h) {
                              return h.playing;
                            });
                          e < n.length;
                          e++
                        ) {
                          var s = n[e];
                          s.loopValue === 0 && s.loopCount
                            ? ((s.loopCount = 0), this.stop(s.name))
                            : s.loopValue === 1 && s.loopCount
                            ? (this.eventManager.fire({
                                type: I.Loop,
                                data: { animation: s.name, type: O.Loop },
                              }),
                              (s.loopCount = 0))
                            : s.loopValue === 2 &&
                              s.loopCount > 1 &&
                              (this.eventManager.fire({
                                type: I.Loop,
                                data: { animation: s.name, type: O.PingPong },
                              }),
                              (s.loopCount = 0));
                        }
                      }),
                      (i.prototype.handleStateChanges = function () {
                        for (
                          var e = [],
                            n = 0,
                            s = this.stateMachines.filter(function (d) {
                              return d.playing;
                            });
                          n < s.length;
                          n++
                        ) {
                          var h = s[n];
                          e.push.apply(e, h.statesChanged);
                        }
                        e.length > 0 &&
                          this.eventManager.fire({
                            type: I.StateChange,
                            data: e,
                          });
                      }),
                      (i.prototype.handleAdvancing = function (e) {
                        this.eventManager.fire({ type: I.Advance, data: e });
                      }),
                      i
                    );
                  })(),
                  I;
                (function (i) {
                  (i.Load = "load"),
                    (i.LoadError = "loaderror"),
                    (i.Play = "play"),
                    (i.Pause = "pause"),
                    (i.Stop = "stop"),
                    (i.Loop = "loop"),
                    (i.Draw = "draw"),
                    (i.Advance = "advance"),
                    (i.StateChange = "statechange"),
                    (i.RiveEvent = "riveevent"),
                    (i.AudioStatusChange = "audiostatuschange");
                })(I || (I = {}));
                var O;
                (function (i) {
                  (i.OneShot = "oneshot"),
                    (i.Loop = "loop"),
                    (i.PingPong = "pingpong");
                })(O || (O = {}));
                var he = (function () {
                    function i(e) {
                      e === void 0 && (e = []), (this.listeners = e);
                    }
                    return (
                      (i.prototype.getListeners = function (e) {
                        return this.listeners.filter(function (n) {
                          return n.type === e;
                        });
                      }),
                      (i.prototype.add = function (e) {
                        this.listeners.includes(e) || this.listeners.push(e);
                      }),
                      (i.prototype.remove = function (e) {
                        for (var n = 0; n < this.listeners.length; n++) {
                          var s = this.listeners[n];
                          if (s.type === e.type && s.callback === e.callback) {
                            this.listeners.splice(n, 1);
                            break;
                          }
                        }
                      }),
                      (i.prototype.removeAll = function (e) {
                        var n = this;
                        e
                          ? this.listeners
                              .filter(function (s) {
                                return s.type === e;
                              })
                              .forEach(function (s) {
                                return n.remove(s);
                              })
                          : this.listeners.splice(0, this.listeners.length);
                      }),
                      (i.prototype.fire = function (e) {
                        var n = this.getListeners(e.type);
                        n.forEach(function (s) {
                          return s.callback(e);
                        });
                      }),
                      i
                    );
                  })(),
                  ye = (function () {
                    function i(e) {
                      (this.eventManager = e), (this.queue = []);
                    }
                    return (
                      (i.prototype.add = function (e) {
                        this.queue.push(e);
                      }),
                      (i.prototype.process = function () {
                        for (; this.queue.length > 0; ) {
                          var e = this.queue.shift();
                          e?.action && e.action(),
                            e?.event && this.eventManager.fire(e.event);
                        }
                      }),
                      i
                    );
                  })(),
                  we;
                (function (i) {
                  (i[(i.AVAILABLE = 0)] = "AVAILABLE"),
                    (i[(i.UNAVAILABLE = 1)] = "UNAVAILABLE");
                })(we || (we = {}));
                var Ke = (function (i) {
                    K(e, i);
                    function e() {
                      var n = (i !== null && i.apply(this, arguments)) || this;
                      return (
                        (n._started = !1),
                        (n._enabled = !1),
                        (n._status = we.UNAVAILABLE),
                        n
                      );
                    }
                    return (
                      (e.prototype.delay = function (n) {
                        return T(this, void 0, void 0, function () {
                          return c(this, function (s) {
                            return [
                              2,
                              new Promise(function (h) {
                                return setTimeout(h, n);
                              }),
                            ];
                          });
                        });
                      }),
                      (e.prototype.timeout = function () {
                        return T(this, void 0, void 0, function () {
                          return c(this, function (n) {
                            return [
                              2,
                              new Promise(function (s, h) {
                                return setTimeout(h, 50);
                              }),
                            ];
                          });
                        });
                      }),
                      (e.prototype.reportToListeners = function () {
                        this.fire({ type: I.AudioStatusChange }),
                          this.removeAll();
                      }),
                      (e.prototype.enableAudio = function () {
                        return T(this, void 0, void 0, function () {
                          return c(this, function (n) {
                            return (
                              this._enabled ||
                                ((this._enabled = !0),
                                (this._status = we.AVAILABLE),
                                this.reportToListeners()),
                              [2]
                            );
                          });
                        });
                      }),
                      (e.prototype.testAudio = function () {
                        return T(this, void 0, void 0, function () {
                          return c(this, function (n) {
                            switch (n.label) {
                              case 0:
                                if (
                                  !(
                                    this._status === we.UNAVAILABLE &&
                                    this._audioContext !== null
                                  )
                                )
                                  return [3, 4];
                                n.label = 1;
                              case 1:
                                return (
                                  n.trys.push([1, 3, , 4]),
                                  [
                                    4,
                                    Promise.race([
                                      this._audioContext.resume(),
                                      this.timeout(),
                                    ]),
                                  ]
                                );
                              case 2:
                                return n.sent(), this.enableAudio(), [3, 4];
                              case 3:
                                return n.sent(), [3, 4];
                              case 4:
                                return [2];
                            }
                          });
                        });
                      }),
                      (e.prototype._establishAudio = function () {
                        return T(this, void 0, void 0, function () {
                          return c(this, function (n) {
                            switch (n.label) {
                              case 0:
                                return this._started
                                  ? [3, 5]
                                  : ((this._started = !0),
                                    typeof window > "u"
                                      ? (this.enableAudio(), [3, 5])
                                      : [3, 1]);
                              case 1:
                                (this._audioContext = new AudioContext()),
                                  this.listenForUserAction(),
                                  (n.label = 2);
                              case 2:
                                return this._status !== we.UNAVAILABLE
                                  ? [3, 5]
                                  : [4, this.testAudio()];
                              case 3:
                                return n.sent(), [4, this.delay(1e3)];
                              case 4:
                                return n.sent(), [3, 2];
                              case 5:
                                return [2];
                            }
                          });
                        });
                      }),
                      (e.prototype.listenForUserAction = function () {
                        var n = this,
                          s = function () {
                            return T(n, void 0, void 0, function () {
                              return c(this, function (h) {
                                return this.enableAudio(), [2];
                              });
                            });
                          };
                        document.addEventListener("pointerdown", s, {
                          once: !0,
                        });
                      }),
                      (e.prototype.establishAudio = function () {
                        return T(this, void 0, void 0, function () {
                          return c(this, function (n) {
                            return this._establishAudio(), [2];
                          });
                        });
                      }),
                      Object.defineProperty(e.prototype, "systemVolume", {
                        get: function () {
                          return this._status === we.UNAVAILABLE
                            ? (this.testAudio(), 0)
                            : 1;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      Object.defineProperty(e.prototype, "status", {
                        get: function () {
                          return this._status;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      e
                    );
                  })(he),
                  ae = new Ke(),
                  ct = (function () {
                    function i() {}
                    return (
                      (i.prototype.observe = function () {}),
                      (i.prototype.unobserve = function () {}),
                      (i.prototype.disconnect = function () {}),
                      i
                    );
                  })(),
                  ke = globalThis.ResizeObserver || ct,
                  le = (function () {
                    function i() {
                      var e = this;
                      (this._elementsMap = new Map()),
                        (this._onObservedEntry = function (n) {
                          var s = e._elementsMap.get(n.target);
                          s !== null
                            ? s.onResize(
                                n.target.clientWidth == 0 ||
                                  n.target.clientHeight == 0
                              )
                            : e._resizeObserver.unobserve(n.target);
                        }),
                        (this._onObserved = function (n) {
                          n.forEach(e._onObservedEntry);
                        }),
                        (this._resizeObserver = new ke(this._onObserved));
                    }
                    return (
                      (i.prototype.add = function (e, n) {
                        var s = { onResize: n, element: e };
                        return (
                          this._elementsMap.set(e, s),
                          this._resizeObserver.observe(e),
                          s
                        );
                      }),
                      (i.prototype.remove = function (e) {
                        this._resizeObserver.unobserve(e.element),
                          this._elementsMap.delete(e.element);
                      }),
                      i
                    );
                  })(),
                  Pe = new le(),
                  De = (function () {
                    function i(e) {
                      (this.enableRiveAssetCDN = !0),
                        (this.referenceCount = 0),
                        (this.destroyed = !1),
                        (this.selfUnref = !1),
                        (this.src = e.src),
                        (this.buffer = e.buffer),
                        e.assetLoader && (this.assetLoader = e.assetLoader),
                        (this.enableRiveAssetCDN =
                          typeof e.enableRiveAssetCDN == "boolean"
                            ? e.enableRiveAssetCDN
                            : !0),
                        (this.eventManager = new he()),
                        e.onLoad && this.on(I.Load, e.onLoad),
                        e.onLoadError && this.on(I.LoadError, e.onLoadError);
                    }
                    return (
                      (i.prototype.releaseFile = function () {
                        var e;
                        this.selfUnref &&
                          ((e = this.file) === null ||
                            e === void 0 ||
                            e.unref()),
                          (this.file = null);
                      }),
                      (i.prototype.initData = function () {
                        return T(this, void 0, void 0, function () {
                          var e, n, s, h, d;
                          return c(this, function (y) {
                            switch (y.label) {
                              case 0:
                                return this.src
                                  ? ((e = this), [4, wt(this.src)])
                                  : [3, 2];
                              case 1:
                                (e.buffer = y.sent()), (y.label = 2);
                              case 2:
                                return this.destroyed
                                  ? [2]
                                  : (this.assetLoader &&
                                      ((s = new G.CustomFileAssetLoaderWrapper(
                                        this.runtime,
                                        this.assetLoader
                                      )),
                                      (n = s.assetLoader)),
                                    (h = this),
                                    [
                                      4,
                                      this.runtime.load(
                                        new Uint8Array(this.buffer),
                                        n,
                                        this.enableRiveAssetCDN
                                      ),
                                    ]);
                              case 3:
                                return (
                                  (h.file = y.sent()),
                                  (d = new G.FileFinalizer(this.file)),
                                  G.finalizationRegistry.register(this, d),
                                  this.destroyed
                                    ? (this.releaseFile(), [2])
                                    : (this.file !== null
                                        ? this.eventManager.fire({
                                            type: I.Load,
                                            data: this,
                                          })
                                        : this.fireLoadError(
                                            i.fileLoadErrorMessage
                                          ),
                                      [2])
                                );
                            }
                          });
                        });
                      }),
                      (i.prototype.init = function () {
                        return T(this, void 0, void 0, function () {
                          var e, n;
                          return c(this, function (s) {
                            switch (s.label) {
                              case 0:
                                if (!this.src && !this.buffer)
                                  return (
                                    this.fireLoadError(i.missingErrorMessage),
                                    [2]
                                  );
                                s.label = 1;
                              case 1:
                                return (
                                  s.trys.push([1, 4, , 5]),
                                  (e = this),
                                  [4, ne.awaitInstance()]
                                );
                              case 2:
                                return (
                                  (e.runtime = s.sent()),
                                  this.destroyed ? [2] : [4, this.initData()]
                                );
                              case 3:
                                return s.sent(), [3, 5];
                              case 4:
                                return (
                                  (n = s.sent()),
                                  this.fireLoadError(
                                    n instanceof Error
                                      ? n.message
                                      : i.fileLoadErrorMessage
                                  ),
                                  [3, 5]
                                );
                              case 5:
                                return [2];
                            }
                          });
                        });
                      }),
                      (i.prototype.fireLoadError = function (e) {
                        throw (
                          (this.eventManager.fire({
                            type: I.LoadError,
                            data: e,
                          }),
                          new Error(e))
                        );
                      }),
                      (i.prototype.on = function (e, n) {
                        this.eventManager.add({ type: e, callback: n });
                      }),
                      (i.prototype.off = function (e, n) {
                        this.eventManager.remove({ type: e, callback: n });
                      }),
                      (i.prototype.cleanup = function () {
                        (this.referenceCount -= 1),
                          this.referenceCount <= 0 &&
                            (this.removeAllRiveEventListeners(),
                            this.releaseFile(),
                            (this.destroyed = !0));
                      }),
                      (i.prototype.removeAllRiveEventListeners = function (e) {
                        this.eventManager.removeAll(e);
                      }),
                      (i.prototype.getInstance = function () {
                        if (this.file !== null)
                          return (this.referenceCount += 1), this.file;
                      }),
                      (i.prototype.destroyIfUnused = function () {
                        this.referenceCount <= 0 && this.cleanup();
                      }),
                      (i.prototype.getArtboard = function (e) {
                        var n = this.file.artboardByName(e);
                        return n != null ? new rt(n) : null;
                      }),
                      (i.missingErrorMessage =
                        "Rive source file or data buffer required"),
                      (i.fileLoadErrorMessage = "The file failed to load"),
                      i
                    );
                  })(),
                  re = (function () {
                    function i(e) {
                      var n = this,
                        s;
                      (this.loaded = !1),
                        (this.destroyed = !1),
                        (this._observed = null),
                        (this.readyForPlaying = !1),
                        (this.artboard = null),
                        (this.eventCleanup = null),
                        (this.shouldDisableRiveListeners = !1),
                        (this.automaticallyHandleEvents = !1),
                        (this.enableRiveAssetCDN = !0),
                        (this._volume = 1),
                        (this._artboardWidth = void 0),
                        (this._artboardHeight = void 0),
                        (this._devicePixelRatioUsed = 1),
                        (this._hasZeroSize = !1),
                        (this._audioEventListener = null),
                        (this._boundDraw = null),
                        (this._viewModelInstance = null),
                        (this._dataEnums = null),
                        (this.durations = []),
                        (this.frameTimes = []),
                        (this.frameCount = 0),
                        (this.isTouchScrollEnabled = !1),
                        (this.onCanvasResize = function (h) {
                          var d = n._hasZeroSize !== h;
                          (n._hasZeroSize = h),
                            h
                              ? (!n._layout.maxX || !n._layout.maxY) &&
                                n.resizeToCanvas()
                              : d && n.resizeDrawingSurfaceToCanvas();
                        }),
                        (this.renderSecondTimer = 0),
                        (this._boundDraw = this.draw.bind(this)),
                        (this.canvas = e.canvas),
                        e.canvas.constructor === HTMLCanvasElement &&
                          (this._observed = Pe.add(
                            this.canvas,
                            this.onCanvasResize
                          )),
                        (this.src = e.src),
                        (this.buffer = e.buffer),
                        (this.riveFile = e.riveFile),
                        (this.layout =
                          (s = e.layout) !== null && s !== void 0
                            ? s
                            : new Ce()),
                        (this.shouldDisableRiveListeners =
                          !!e.shouldDisableRiveListeners),
                        (this.isTouchScrollEnabled = !!e.isTouchScrollEnabled),
                        (this.automaticallyHandleEvents =
                          !!e.automaticallyHandleEvents),
                        (this.enableRiveAssetCDN =
                          e.enableRiveAssetCDN === void 0
                            ? !0
                            : e.enableRiveAssetCDN),
                        (this.eventManager = new he()),
                        e.onLoad && this.on(I.Load, e.onLoad),
                        e.onLoadError && this.on(I.LoadError, e.onLoadError),
                        e.onPlay && this.on(I.Play, e.onPlay),
                        e.onPause && this.on(I.Pause, e.onPause),
                        e.onStop && this.on(I.Stop, e.onStop),
                        e.onLoop && this.on(I.Loop, e.onLoop),
                        e.onStateChange &&
                          this.on(I.StateChange, e.onStateChange),
                        e.onAdvance && this.on(I.Advance, e.onAdvance),
                        e.onload && !e.onLoad && this.on(I.Load, e.onload),
                        e.onloaderror &&
                          !e.onLoadError &&
                          this.on(I.LoadError, e.onloaderror),
                        e.onplay && !e.onPlay && this.on(I.Play, e.onplay),
                        e.onpause && !e.onPause && this.on(I.Pause, e.onpause),
                        e.onstop && !e.onStop && this.on(I.Stop, e.onstop),
                        e.onloop && !e.onLoop && this.on(I.Loop, e.onloop),
                        e.onstatechange &&
                          !e.onStateChange &&
                          this.on(I.StateChange, e.onstatechange),
                        e.assetLoader && (this.assetLoader = e.assetLoader),
                        (this.taskQueue = new ye(this.eventManager)),
                        this.init({
                          src: this.src,
                          buffer: this.buffer,
                          riveFile: this.riveFile,
                          autoplay: e.autoplay,
                          autoBind: e.autoBind,
                          animations: e.animations,
                          stateMachines: e.stateMachines,
                          artboard: e.artboard,
                          useOffscreenRenderer: e.useOffscreenRenderer,
                        });
                    }
                    return (
                      Object.defineProperty(i.prototype, "viewModelCount", {
                        get: function () {
                          return this.file.viewModelCount();
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      (i.new = function (e) {
                        return (
                          console.warn(
                            "This function is deprecated: please use `new Rive({})` instead"
                          ),
                          new i(e)
                        );
                      }),
                      (i.prototype.onSystemAudioChanged = function () {
                        this.volume = this._volume;
                      }),
                      (i.prototype.init = function (e) {
                        var n = this,
                          s = e.src,
                          h = e.buffer,
                          d = e.riveFile,
                          y = e.animations,
                          L = e.stateMachines,
                          W = e.artboard,
                          F = e.autoplay,
                          V = F === void 0 ? !1 : F,
                          j = e.useOffscreenRenderer,
                          de = j === void 0 ? !1 : j,
                          ie = e.autoBind,
                          Fe = ie === void 0 ? !1 : ie;
                        if (!this.destroyed) {
                          if (
                            ((this.src = s),
                            (this.buffer = h),
                            (this.riveFile = d),
                            !this.src && !this.buffer && !this.riveFile)
                          )
                            throw new fe(i.missingErrorMessage);
                          var pe = Se(y),
                            Ie = Se(L);
                          (this.loaded = !1),
                            (this.readyForPlaying = !1),
                            ne
                              .awaitInstance()
                              .then(function (ve) {
                                n.destroyed ||
                                  ((n.runtime = ve),
                                  n.removeRiveListeners(),
                                  n.deleteRiveRenderer(),
                                  (n.renderer = n.runtime.makeRenderer(
                                    n.canvas,
                                    de
                                  )),
                                  n.canvas.width ||
                                    n.canvas.height ||
                                    n.resizeDrawingSurfaceToCanvas(),
                                  n
                                    .initData(W, pe, Ie, V, Fe)
                                    .then(function (je) {
                                      if (je) return n.setupRiveListeners();
                                    })
                                    .catch(function (je) {
                                      console.error(je);
                                    }));
                              })
                              .catch(function (ve) {
                                console.error(ve);
                              });
                        }
                      }),
                      (i.prototype.setupRiveListeners = function (e) {
                        var n = this;
                        if (
                          (this.eventCleanup && this.eventCleanup(),
                          !this.shouldDisableRiveListeners)
                        ) {
                          var s = (this.animator.stateMachines || [])
                              .filter(function (d) {
                                return (
                                  d.playing &&
                                  n.runtime.hasListeners(d.instance)
                                );
                              })
                              .map(function (d) {
                                return d.instance;
                              }),
                            h = this.isTouchScrollEnabled;
                          e &&
                            "isTouchScrollEnabled" in e &&
                            (h = e.isTouchScrollEnabled),
                            (this.eventCleanup = (0,
                            G.registerTouchInteractions)({
                              canvas: this.canvas,
                              artboard: this.artboard,
                              stateMachines: s,
                              renderer: this.renderer,
                              rive: this.runtime,
                              fit: this._layout.runtimeFit(this.runtime),
                              alignment: this._layout.runtimeAlignment(
                                this.runtime
                              ),
                              isTouchScrollEnabled: h,
                              layoutScaleFactor: this._layout.layoutScaleFactor,
                            }));
                        }
                      }),
                      (i.prototype.removeRiveListeners = function () {
                        this.eventCleanup &&
                          (this.eventCleanup(), (this.eventCleanup = null));
                      }),
                      (i.prototype.initializeAudio = function () {
                        var e = this,
                          n;
                        ae.status == we.UNAVAILABLE &&
                          !((n = this.artboard) === null || n === void 0) &&
                          n.hasAudio &&
                          this._audioEventListener === null &&
                          ((this._audioEventListener = {
                            type: I.AudioStatusChange,
                            callback: function () {
                              return e.onSystemAudioChanged();
                            },
                          }),
                          ae.add(this._audioEventListener),
                          ae.establishAudio());
                      }),
                      (i.prototype.initArtboardSize = function () {
                        this.artboard &&
                          ((this._artboardWidth = this.artboard.width =
                            this._artboardWidth || this.artboard.width),
                          (this._artboardHeight = this.artboard.height =
                            this._artboardHeight || this.artboard.height));
                      }),
                      (i.prototype.initData = function (e, n, s, h, d) {
                        return T(this, void 0, void 0, function () {
                          var y, L, W, F;
                          return c(this, function (V) {
                            switch (V.label) {
                              case 0:
                                return (
                                  V.trys.push([0, 3, , 4]),
                                  this.riveFile != null
                                    ? [3, 2]
                                    : ((y = new De({
                                        src: this.src,
                                        buffer: this.buffer,
                                        enableRiveAssetCDN:
                                          this.enableRiveAssetCDN,
                                        assetLoader: this.assetLoader,
                                      })),
                                      (this.riveFile = y),
                                      [4, y.init()])
                                );
                              case 1:
                                if ((V.sent(), this.destroyed))
                                  return y.destroyIfUnused(), [2, !1];
                                V.label = 2;
                              case 2:
                                return (
                                  (this.file = this.riveFile.getInstance()),
                                  this.initArtboard(e, n, s, h, d),
                                  this.initArtboardSize(),
                                  this.initializeAudio(),
                                  (this.loaded = !0),
                                  this.eventManager.fire({
                                    type: I.Load,
                                    data:
                                      (F = this.src) !== null && F !== void 0
                                        ? F
                                        : "buffer",
                                  }),
                                  this.animator.advanceIfPaused(),
                                  (this.readyForPlaying = !0),
                                  this.taskQueue.process(),
                                  this.drawFrame(),
                                  [2, !0]
                                );
                              case 3:
                                return (
                                  (L = V.sent()),
                                  (W = Le(L)),
                                  console.warn(W),
                                  this.eventManager.fire({
                                    type: I.LoadError,
                                    data: W,
                                  }),
                                  [2, Promise.reject(W)]
                                );
                              case 4:
                                return [2];
                            }
                          });
                        });
                      }),
                      (i.prototype.initArtboard = function (e, n, s, h, d) {
                        if (this.file) {
                          var y = e
                            ? this.file.artboardByName(e)
                            : this.file.defaultArtboard();
                          if (!y) {
                            var L =
                              "Invalid artboard name or no default artboard";
                            console.warn(L),
                              this.eventManager.fire({
                                type: I.LoadError,
                                data: L,
                              });
                            return;
                          }
                          (this.artboard = y),
                            (y.volume = this._volume * ae.systemVolume),
                            (this.animator = new M(
                              this.runtime,
                              this.artboard,
                              this.eventManager
                            ));
                          var W;
                          if (
                            (n.length > 0 || s.length > 0
                              ? ((W = n.concat(s)),
                                this.animator.initLinearAnimations(n, h),
                                this.animator.initStateMachines(s, h))
                              : (W = [this.animator.atLeastOne(h, !1)]),
                            this.taskQueue.add({
                              event: { type: h ? I.Play : I.Pause, data: W },
                            }),
                            d)
                          ) {
                            var F = this.file.defaultArtboardViewModel(y);
                            if (F !== null) {
                              var V = F.defaultInstance();
                              if (V !== null) {
                                var j = new Oe(V, null);
                                this.bindViewModelInstance(j);
                              }
                            }
                          }
                        }
                      }),
                      (i.prototype.drawFrame = function () {
                        var e, n;
                        !((e = document?.timeline) === null || e === void 0) &&
                        e.currentTime
                          ? this.loaded &&
                            this.artboard &&
                            !this.frameRequestId &&
                            (this._boundDraw(document.timeline.currentTime),
                            (n = this.runtime) === null ||
                              n === void 0 ||
                              n.resolveAnimationFrame())
                          : this.startRendering();
                      }),
                      (i.prototype.draw = function (e, n) {
                        var s;
                        this.frameRequestId = null;
                        var h = performance.now();
                        this.lastRenderTime || (this.lastRenderTime = e),
                          (this.renderSecondTimer += e - this.lastRenderTime),
                          this.renderSecondTimer > 5e3 &&
                            ((this.renderSecondTimer = 0), n?.());
                        var d = (e - this.lastRenderTime) / 1e3;
                        this.lastRenderTime = e;
                        for (
                          var y = this.animator.animations
                              .filter(function (Ze) {
                                return Ze.playing || Ze.needsScrub;
                              })
                              .sort(function (Ze) {
                                return Ze.needsScrub ? -1 : 1;
                              }),
                            L = 0,
                            W = y;
                          L < W.length;
                          L++
                        ) {
                          var F = W[L];
                          F.advance(d),
                            F.instance.didLoop && (F.loopCount += 1),
                            F.apply(1);
                        }
                        for (
                          var V = this.animator.stateMachines.filter(function (
                              Ze
                            ) {
                              return Ze.playing;
                            }),
                            j = 0,
                            de = V;
                          j < de.length;
                          j++
                        ) {
                          var ie = de[j],
                            Fe = ie.reportedEventCount();
                          if (Fe)
                            for (var pe = 0; pe < Fe; pe++) {
                              var Ie = ie.reportedEventAt(pe);
                              if (Ie)
                                if (Ie.type === Te.OpenUrl) {
                                  if (
                                    (this.eventManager.fire({
                                      type: I.RiveEvent,
                                      data: Ie,
                                    }),
                                    this.automaticallyHandleEvents)
                                  ) {
                                    var ve = document.createElement("a"),
                                      je = Ie,
                                      xe = je.url,
                                      Be = je.target,
                                      Ne = (0, G.sanitizeUrl)(xe);
                                    xe && ve.setAttribute("href", Ne),
                                      Be && ve.setAttribute("target", Be),
                                      Ne && Ne !== G.BLANK_URL && ve.click();
                                  }
                                } else
                                  this.eventManager.fire({
                                    type: I.RiveEvent,
                                    data: Ie,
                                  });
                            }
                          ie.advanceAndApply(d);
                        }
                        this.animator.stateMachines.length == 0 &&
                          this.artboard.advance(d);
                        var ze = this.renderer;
                        ze.clear(),
                          ze.save(),
                          this.alignRenderer(),
                          this._hasZeroSize || this.artboard.draw(ze),
                          ze.restore(),
                          ze.flush(),
                          this.animator.handleLooping(),
                          this.animator.handleStateChanges(),
                          this.animator.handleAdvancing(d),
                          this.frameCount++;
                        var N = performance.now();
                        for (
                          this.frameTimes.push(N), this.durations.push(N - h);
                          this.frameTimes[0] <= N - 1e3;

                        )
                          this.frameTimes.shift(), this.durations.shift();
                        (s = this._viewModelInstance) === null ||
                          s === void 0 ||
                          s.handleCallbacks(),
                          this.animator.isPlaying
                            ? this.startRendering()
                            : this.animator.isPaused
                            ? (this.lastRenderTime = 0)
                            : this.animator.isStopped &&
                              (this.lastRenderTime = 0);
                      }),
                      (i.prototype.alignRenderer = function () {
                        var e = this,
                          n = e.renderer,
                          s = e.runtime,
                          h = e._layout,
                          d = e.artboard;
                        n.align(
                          h.runtimeFit(s),
                          h.runtimeAlignment(s),
                          {
                            minX: h.minX,
                            minY: h.minY,
                            maxX: h.maxX,
                            maxY: h.maxY,
                          },
                          d.bounds,
                          this._devicePixelRatioUsed * h.layoutScaleFactor
                        );
                      }),
                      Object.defineProperty(i.prototype, "fps", {
                        get: function () {
                          return this.durations.length;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      Object.defineProperty(i.prototype, "frameTime", {
                        get: function () {
                          return this.durations.length === 0
                            ? 0
                            : (
                                this.durations.reduce(function (e, n) {
                                  return e + n;
                                }, 0) / this.durations.length
                              ).toFixed(4);
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      (i.prototype.cleanup = function () {
                        var e, n;
                        (this.destroyed = !0),
                          this.stopRendering(),
                          this.cleanupInstances(),
                          this._observed !== null && Pe.remove(this._observed),
                          this.removeRiveListeners(),
                          this.file &&
                            ((e = this.riveFile) === null ||
                              e === void 0 ||
                              e.cleanup(),
                            (this.file = null)),
                          (this.riveFile = null),
                          this.deleteRiveRenderer(),
                          this._audioEventListener !== null &&
                            (ae.remove(this._audioEventListener),
                            (this._audioEventListener = null)),
                          (n = this._viewModelInstance) === null ||
                            n === void 0 ||
                            n.cleanup(),
                          (this._viewModelInstance = null),
                          (this._dataEnums = null);
                      }),
                      (i.prototype.deleteRiveRenderer = function () {
                        var e;
                        (e = this.renderer) === null ||
                          e === void 0 ||
                          e.delete(),
                          (this.renderer = null);
                      }),
                      (i.prototype.cleanupInstances = function () {
                        this.eventCleanup !== null && this.eventCleanup(),
                          this.stop(),
                          this.artboard &&
                            (this.artboard.delete(), (this.artboard = null));
                      }),
                      (i.prototype.retrieveTextRun = function (e) {
                        var n;
                        if (!e) {
                          console.warn("No text run name provided");
                          return;
                        }
                        if (!this.artboard) {
                          console.warn(
                            "Tried to access text run, but the Artboard is null"
                          );
                          return;
                        }
                        var s = this.artboard.textRun(e);
                        if (!s) {
                          console.warn(
                            "Could not access a text run with name '"
                              .concat(e, "' in the '")
                              .concat(
                                (n = this.artboard) === null || n === void 0
                                  ? void 0
                                  : n.name,
                                "' Artboard. Note that you must rename a text run node in the Rive editor to make it queryable at runtime."
                              )
                          );
                          return;
                        }
                        return s;
                      }),
                      (i.prototype.getTextRunValue = function (e) {
                        var n = this.retrieveTextRun(e);
                        return n ? n.text : void 0;
                      }),
                      (i.prototype.setTextRunValue = function (e, n) {
                        var s = this.retrieveTextRun(e);
                        s && (s.text = n);
                      }),
                      (i.prototype.play = function (e, n) {
                        var s = this;
                        if (((e = Se(e)), !this.readyForPlaying)) {
                          this.taskQueue.add({
                            action: function () {
                              return s.play(e, n);
                            },
                          });
                          return;
                        }
                        this.animator.play(e),
                          this.eventCleanup && this.eventCleanup(),
                          this.setupRiveListeners(),
                          this.startRendering();
                      }),
                      (i.prototype.pause = function (e) {
                        var n = this;
                        if (((e = Se(e)), !this.readyForPlaying)) {
                          this.taskQueue.add({
                            action: function () {
                              return n.pause(e);
                            },
                          });
                          return;
                        }
                        this.eventCleanup && this.eventCleanup(),
                          this.animator.pause(e);
                      }),
                      (i.prototype.scrub = function (e, n) {
                        var s = this;
                        if (((e = Se(e)), !this.readyForPlaying)) {
                          this.taskQueue.add({
                            action: function () {
                              return s.scrub(e, n);
                            },
                          });
                          return;
                        }
                        this.animator.scrub(e, n || 0), this.drawFrame();
                      }),
                      (i.prototype.stop = function (e) {
                        var n = this;
                        if (((e = Se(e)), !this.readyForPlaying)) {
                          this.taskQueue.add({
                            action: function () {
                              return n.stop(e);
                            },
                          });
                          return;
                        }
                        this.animator && this.animator.stop(e),
                          this.eventCleanup && this.eventCleanup();
                      }),
                      (i.prototype.reset = function (e) {
                        var n,
                          s,
                          h = e?.artboard,
                          d = Se(e?.animations),
                          y = Se(e?.stateMachines),
                          L =
                            (n = e?.autoplay) !== null && n !== void 0 ? n : !1,
                          W =
                            (s = e?.autoBind) !== null && s !== void 0 ? s : !1;
                        this.cleanupInstances(),
                          this.initArtboard(h, d, y, L, W),
                          this.taskQueue.process();
                      }),
                      (i.prototype.load = function (e) {
                        (this.file = null), this.stop(), this.init(e);
                      }),
                      Object.defineProperty(i.prototype, "layout", {
                        get: function () {
                          return this._layout;
                        },
                        set: function (e) {
                          (this._layout = e),
                            (!e.maxX || !e.maxY) && this.resizeToCanvas(),
                            this.loaded &&
                              !this.animator.isPlaying &&
                              this.drawFrame();
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      (i.prototype.resizeToCanvas = function () {
                        this._layout = this.layout.copyWith({
                          minX: 0,
                          minY: 0,
                          maxX: this.canvas.width,
                          maxY: this.canvas.height,
                        });
                      }),
                      (i.prototype.resizeDrawingSurfaceToCanvas = function (e) {
                        if (
                          this.canvas instanceof HTMLCanvasElement &&
                          window
                        ) {
                          var n = this.canvas.getBoundingClientRect(),
                            s = n.width,
                            h = n.height,
                            d = e || window.devicePixelRatio || 1;
                          if (
                            ((this.devicePixelRatioUsed = d),
                            (this.canvas.width = d * s),
                            (this.canvas.height = d * h),
                            this.resizeToCanvas(),
                            this.drawFrame(),
                            this.layout.fit === ee.Layout)
                          ) {
                            var y = this._layout.layoutScaleFactor;
                            (this.artboard.width = s / y),
                              (this.artboard.height = h / y);
                          }
                        }
                      }),
                      Object.defineProperty(i.prototype, "source", {
                        get: function () {
                          return this.src;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      Object.defineProperty(i.prototype, "activeArtboard", {
                        get: function () {
                          return this.artboard ? this.artboard.name : "";
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      Object.defineProperty(i.prototype, "animationNames", {
                        get: function () {
                          if (!this.loaded || !this.artboard) return [];
                          for (
                            var e = [], n = 0;
                            n < this.artboard.animationCount();
                            n++
                          )
                            e.push(this.artboard.animationByIndex(n).name);
                          return e;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      Object.defineProperty(i.prototype, "stateMachineNames", {
                        get: function () {
                          if (!this.loaded || !this.artboard) return [];
                          for (
                            var e = [], n = 0;
                            n < this.artboard.stateMachineCount();
                            n++
                          )
                            e.push(this.artboard.stateMachineByIndex(n).name);
                          return e;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      (i.prototype.stateMachineInputs = function (e) {
                        if (this.loaded) {
                          var n = this.animator.stateMachines.find(function (
                            s
                          ) {
                            return s.name === e;
                          });
                          return n?.inputs;
                        }
                      }),
                      (i.prototype.retrieveInputAtPath = function (e, n) {
                        if (!e) {
                          console.warn(
                            "No input name provided for path '".concat(n, "'")
                          );
                          return;
                        }
                        if (!this.artboard) {
                          console.warn(
                            "Tried to access input: '"
                              .concat(e, "', at path: '")
                              .concat(n, "', but the Artboard is null")
                          );
                          return;
                        }
                        var s = this.artboard.inputByPath(e, n);
                        if (!s) {
                          console.warn(
                            "Could not access an input with name: '"
                              .concat(e, "', at path:'")
                              .concat(n, "'")
                          );
                          return;
                        }
                        return s;
                      }),
                      (i.prototype.setBooleanStateAtPath = function (e, n, s) {
                        var h = this.retrieveInputAtPath(e, s);
                        h &&
                          (h.type === ue.Boolean
                            ? (h.asBool().value = n)
                            : console.warn(
                                "Input with name: '"
                                  .concat(e, "', at path:'")
                                  .concat(s, "' is not a boolean")
                              ));
                      }),
                      (i.prototype.setNumberStateAtPath = function (e, n, s) {
                        var h = this.retrieveInputAtPath(e, s);
                        h &&
                          (h.type === ue.Number
                            ? (h.asNumber().value = n)
                            : console.warn(
                                "Input with name: '"
                                  .concat(e, "', at path:'")
                                  .concat(s, "' is not a number")
                              ));
                      }),
                      (i.prototype.fireStateAtPath = function (e, n) {
                        var s = this.retrieveInputAtPath(e, n);
                        s &&
                          (s.type === ue.Trigger
                            ? s.asTrigger().fire()
                            : console.warn(
                                "Input with name: '"
                                  .concat(e, "', at path:'")
                                  .concat(n, "' is not a trigger")
                              ));
                      }),
                      (i.prototype.retrieveTextAtPath = function (e, n) {
                        if (!e) {
                          console.warn(
                            "No text name provided for path '".concat(n, "'")
                          );
                          return;
                        }
                        if (!n) {
                          console.warn(
                            "No path provided for text '".concat(e, "'")
                          );
                          return;
                        }
                        if (!this.artboard) {
                          console.warn(
                            "Tried to access text: '"
                              .concat(e, "', at path: '")
                              .concat(n, "', but the Artboard is null")
                          );
                          return;
                        }
                        var s = this.artboard.textByPath(e, n);
                        if (!s) {
                          console.warn(
                            "Could not access text with name: '"
                              .concat(e, "', at path:'")
                              .concat(n, "'")
                          );
                          return;
                        }
                        return s;
                      }),
                      (i.prototype.getTextRunValueAtPath = function (e, n) {
                        var s = this.retrieveTextAtPath(e, n);
                        if (!s) {
                          console.warn(
                            "Could not get text with name: '"
                              .concat(e, "', at path:'")
                              .concat(n, "'")
                          );
                          return;
                        }
                        return s.text;
                      }),
                      (i.prototype.setTextRunValueAtPath = function (e, n, s) {
                        var h = this.retrieveTextAtPath(e, s);
                        if (!h) {
                          console.warn(
                            "Could not set text with name: '"
                              .concat(e, "', at path:'")
                              .concat(s, "'")
                          );
                          return;
                        }
                        h.text = n;
                      }),
                      Object.defineProperty(
                        i.prototype,
                        "playingStateMachineNames",
                        {
                          get: function () {
                            return this.loaded
                              ? this.animator.stateMachines
                                  .filter(function (e) {
                                    return e.playing;
                                  })
                                  .map(function (e) {
                                    return e.name;
                                  })
                              : [];
                          },
                          enumerable: !1,
                          configurable: !0,
                        }
                      ),
                      Object.defineProperty(
                        i.prototype,
                        "playingAnimationNames",
                        {
                          get: function () {
                            return this.loaded
                              ? this.animator.animations
                                  .filter(function (e) {
                                    return e.playing;
                                  })
                                  .map(function (e) {
                                    return e.name;
                                  })
                              : [];
                          },
                          enumerable: !1,
                          configurable: !0,
                        }
                      ),
                      Object.defineProperty(
                        i.prototype,
                        "pausedAnimationNames",
                        {
                          get: function () {
                            return this.loaded
                              ? this.animator.animations
                                  .filter(function (e) {
                                    return !e.playing;
                                  })
                                  .map(function (e) {
                                    return e.name;
                                  })
                              : [];
                          },
                          enumerable: !1,
                          configurable: !0,
                        }
                      ),
                      Object.defineProperty(
                        i.prototype,
                        "pausedStateMachineNames",
                        {
                          get: function () {
                            return this.loaded
                              ? this.animator.stateMachines
                                  .filter(function (e) {
                                    return !e.playing;
                                  })
                                  .map(function (e) {
                                    return e.name;
                                  })
                              : [];
                          },
                          enumerable: !1,
                          configurable: !0,
                        }
                      ),
                      Object.defineProperty(i.prototype, "isPlaying", {
                        get: function () {
                          return this.animator.isPlaying;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      Object.defineProperty(i.prototype, "isPaused", {
                        get: function () {
                          return this.animator.isPaused;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      Object.defineProperty(i.prototype, "isStopped", {
                        get: function () {
                          return this.animator.isStopped;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      Object.defineProperty(i.prototype, "bounds", {
                        get: function () {
                          return this.artboard ? this.artboard.bounds : void 0;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      (i.prototype.on = function (e, n) {
                        this.eventManager.add({ type: e, callback: n });
                      }),
                      (i.prototype.off = function (e, n) {
                        this.eventManager.remove({ type: e, callback: n });
                      }),
                      (i.prototype.unsubscribe = function (e, n) {
                        console.warn(
                          "This function is deprecated: please use `off()` instead."
                        ),
                          this.off(e, n);
                      }),
                      (i.prototype.removeAllRiveEventListeners = function (e) {
                        this.eventManager.removeAll(e);
                      }),
                      (i.prototype.unsubscribeAll = function (e) {
                        console.warn(
                          "This function is deprecated: please use `removeAllRiveEventListeners()` instead."
                        ),
                          this.removeAllRiveEventListeners(e);
                      }),
                      (i.prototype.stopRendering = function () {
                        this.loaded &&
                          this.frameRequestId &&
                          (this.runtime.cancelAnimationFrame
                            ? this.runtime.cancelAnimationFrame(
                                this.frameRequestId
                              )
                            : cancelAnimationFrame(this.frameRequestId),
                          (this.frameRequestId = null));
                      }),
                      (i.prototype.startRendering = function () {
                        this.loaded &&
                          this.artboard &&
                          !this.frameRequestId &&
                          (this.runtime.requestAnimationFrame
                            ? (this.frameRequestId =
                                this.runtime.requestAnimationFrame(
                                  this._boundDraw
                                ))
                            : (this.frameRequestId = requestAnimationFrame(
                                this._boundDraw
                              )));
                      }),
                      (i.prototype.enableFPSCounter = function (e) {
                        this.runtime.enableFPSCounter(e);
                      }),
                      (i.prototype.disableFPSCounter = function () {
                        this.runtime.disableFPSCounter();
                      }),
                      Object.defineProperty(i.prototype, "contents", {
                        get: function () {
                          if (this.loaded) {
                            for (
                              var e = { artboards: [] }, n = 0;
                              n < this.file.artboardCount();
                              n++
                            ) {
                              for (
                                var s = this.file.artboardByIndex(n),
                                  h = {
                                    name: s.name,
                                    animations: [],
                                    stateMachines: [],
                                  },
                                  d = 0;
                                d < s.animationCount();
                                d++
                              ) {
                                var y = s.animationByIndex(d);
                                h.animations.push(y.name);
                              }
                              for (var L = 0; L < s.stateMachineCount(); L++) {
                                for (
                                  var W = s.stateMachineByIndex(L),
                                    F = W.name,
                                    V = new this.runtime.StateMachineInstance(
                                      W,
                                      s
                                    ),
                                    j = [],
                                    de = 0;
                                  de < V.inputCount();
                                  de++
                                ) {
                                  var ie = V.input(de);
                                  j.push({ name: ie.name, type: ie.type });
                                }
                                h.stateMachines.push({ name: F, inputs: j });
                              }
                              e.artboards.push(h);
                            }
                            return e;
                          }
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      Object.defineProperty(i.prototype, "volume", {
                        get: function () {
                          return (
                            this.artboard &&
                              this.artboard.volume !== this._volume &&
                              (this._volume = this.artboard.volume),
                            this._volume
                          );
                        },
                        set: function (e) {
                          (this._volume = e),
                            this.artboard &&
                              (this.artboard.volume = e * ae.systemVolume);
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      Object.defineProperty(i.prototype, "artboardWidth", {
                        get: function () {
                          var e;
                          return this.artboard
                            ? this.artboard.width
                            : (e = this._artboardWidth) !== null && e !== void 0
                            ? e
                            : 0;
                        },
                        set: function (e) {
                          (this._artboardWidth = e),
                            this.artboard && (this.artboard.width = e);
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      Object.defineProperty(i.prototype, "artboardHeight", {
                        get: function () {
                          var e;
                          return this.artboard
                            ? this.artboard.height
                            : (e = this._artboardHeight) !== null &&
                              e !== void 0
                            ? e
                            : 0;
                        },
                        set: function (e) {
                          (this._artboardHeight = e),
                            this.artboard && (this.artboard.height = e);
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      (i.prototype.resetArtboardSize = function () {
                        this.artboard
                          ? (this.artboard.resetArtboardSize(),
                            (this._artboardWidth = this.artboard.width),
                            (this._artboardHeight = this.artboard.height))
                          : ((this._artboardWidth = void 0),
                            (this._artboardHeight = void 0));
                      }),
                      Object.defineProperty(
                        i.prototype,
                        "devicePixelRatioUsed",
                        {
                          get: function () {
                            return this._devicePixelRatioUsed;
                          },
                          set: function (e) {
                            this._devicePixelRatioUsed = e;
                          },
                          enumerable: !1,
                          configurable: !0,
                        }
                      ),
                      (i.prototype.bindViewModelInstance = function (e) {
                        var n;
                        this.artboard &&
                          !this.destroyed &&
                          e &&
                          e.runtimeInstance &&
                          (e.internalIncrementReferenceCount(),
                          (n = this._viewModelInstance) === null ||
                            n === void 0 ||
                            n.cleanup(),
                          (this._viewModelInstance = e),
                          this.animator.stateMachines.length > 0
                            ? this.animator.stateMachines.forEach(function (s) {
                                return s.bindViewModelInstance(e);
                              })
                            : this.artboard.bindViewModelInstance(
                                e.runtimeInstance
                              ));
                      }),
                      Object.defineProperty(i.prototype, "viewModelInstance", {
                        get: function () {
                          return this._viewModelInstance;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      (i.prototype.viewModelByIndex = function (e) {
                        var n = this.file.viewModelByIndex(e);
                        return n !== null ? new q(n) : null;
                      }),
                      (i.prototype.viewModelByName = function (e) {
                        var n = this.file.viewModelByName(e);
                        return n !== null ? new q(n) : null;
                      }),
                      (i.prototype.enums = function () {
                        if (this._dataEnums === null) {
                          var e = this.file.enums();
                          this._dataEnums = e.map(function (n) {
                            return new Ye(n);
                          });
                        }
                        return this._dataEnums;
                      }),
                      (i.prototype.defaultViewModel = function () {
                        if (this.artboard) {
                          var e = this.file.defaultArtboardViewModel(
                            this.artboard
                          );
                          if (e) return new q(e);
                        }
                        return null;
                      }),
                      (i.prototype.getArtboard = function (e) {
                        var n, s;
                        return (s =
                          (n = this.riveFile) === null || n === void 0
                            ? void 0
                            : n.getArtboard(e)) !== null && s !== void 0
                          ? s
                          : null;
                      }),
                      (i.missingErrorMessage =
                        "Rive source file or data buffer required"),
                      (i.cleanupErrorMessage =
                        "Attempt to use file after calling cleanup."),
                      i
                    );
                  })(),
                  q = (function () {
                    function i(e) {
                      this._viewModel = e;
                    }
                    return (
                      Object.defineProperty(i.prototype, "instanceCount", {
                        get: function () {
                          return this._viewModel.instanceCount;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      Object.defineProperty(i.prototype, "name", {
                        get: function () {
                          return this._viewModel.name;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      (i.prototype.instanceByIndex = function (e) {
                        var n = this._viewModel.instanceByIndex(e);
                        return n !== null ? new Oe(n, null) : null;
                      }),
                      (i.prototype.instanceByName = function (e) {
                        var n = this._viewModel.instanceByName(e);
                        return n !== null ? new Oe(n, null) : null;
                      }),
                      (i.prototype.defaultInstance = function () {
                        var e = this._viewModel.defaultInstance();
                        return e !== null ? new Oe(e, null) : null;
                      }),
                      (i.prototype.instance = function () {
                        var e = this._viewModel.instance();
                        return e !== null ? new Oe(e, null) : null;
                      }),
                      Object.defineProperty(i.prototype, "properties", {
                        get: function () {
                          return this._viewModel.getProperties();
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      Object.defineProperty(i.prototype, "instanceNames", {
                        get: function () {
                          return this._viewModel.getInstanceNames();
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      i
                    );
                  })(),
                  Ye = (function () {
                    function i(e) {
                      this._dataEnum = e;
                    }
                    return (
                      Object.defineProperty(i.prototype, "name", {
                        get: function () {
                          return this._dataEnum.name;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      Object.defineProperty(i.prototype, "values", {
                        get: function () {
                          return this._dataEnum.values;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      i
                    );
                  })(),
                  Z;
                (function (i) {
                  (i.Number = "number"),
                    (i.String = "string"),
                    (i.Boolean = "boolean"),
                    (i.Color = "color"),
                    (i.Trigger = "trigger"),
                    (i.Enum = "enum"),
                    (i.List = "list"),
                    (i.Image = "image"),
                    (i.Artboard = "artboard");
                })(Z || (Z = {}));
                var Oe = (function () {
                    function i(e, n) {
                      (this._parents = []),
                        (this._children = []),
                        (this._viewModelInstances = new Map()),
                        (this._propertiesWithCallbacks = []),
                        (this._referenceCount = 0),
                        (this._runtimeInstance = e),
                        n !== null && this._parents.push(n);
                    }
                    return (
                      Object.defineProperty(i.prototype, "runtimeInstance", {
                        get: function () {
                          return this._runtimeInstance;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      (i.prototype.handleCallbacks = function () {
                        this._propertiesWithCallbacks.length !== 0 &&
                          (this._propertiesWithCallbacks.forEach(function (e) {
                            e.handleCallbacks();
                          }),
                          this._propertiesWithCallbacks.forEach(function (e) {
                            e.clearChanges();
                          })),
                          this._children.forEach(function (e) {
                            return e.handleCallbacks();
                          });
                      }),
                      (i.prototype.addParent = function (e) {
                        this._parents.includes(e) ||
                          (this._parents.push(e),
                          (this._propertiesWithCallbacks.length > 0 ||
                            this._children.length > 0) &&
                            e.addToViewModelCallbacks(this));
                      }),
                      (i.prototype.removeParent = function (e) {
                        var n = this._parents.indexOf(e);
                        if (n !== -1) {
                          var s = this._parents[n];
                          s.removeFromViewModelCallbacks(this),
                            this._parents.splice(n, 1);
                        }
                      }),
                      (i.prototype.addToPropertyCallbacks = function (e) {
                        var n = this;
                        this._propertiesWithCallbacks.includes(e) ||
                          (this._propertiesWithCallbacks.push(e),
                          this._propertiesWithCallbacks.length > 0 &&
                            this._parents.forEach(function (s) {
                              s.addToViewModelCallbacks(n);
                            }));
                      }),
                      (i.prototype.removeFromPropertyCallbacks = function (e) {
                        var n = this;
                        this._propertiesWithCallbacks.includes(e) &&
                          ((this._propertiesWithCallbacks =
                            this._propertiesWithCallbacks.filter(function (s) {
                              return s !== e;
                            })),
                          this._children.length === 0 &&
                            this._propertiesWithCallbacks.length === 0 &&
                            this._parents.forEach(function (s) {
                              s.removeFromViewModelCallbacks(n);
                            }));
                      }),
                      (i.prototype.addToViewModelCallbacks = function (e) {
                        var n = this;
                        this._children.includes(e) ||
                          (this._children.push(e),
                          this._parents.forEach(function (s) {
                            s.addToViewModelCallbacks(n);
                          }));
                      }),
                      (i.prototype.removeFromViewModelCallbacks = function (e) {
                        var n = this;
                        this._children.includes(e) &&
                          ((this._children = this._children.filter(function (
                            s
                          ) {
                            return s !== e;
                          })),
                          this._children.length === 0 &&
                            this._propertiesWithCallbacks.length === 0 &&
                            this._parents.forEach(function (s) {
                              s.removeFromViewModelCallbacks(n);
                            }));
                      }),
                      (i.prototype.clearCallbacks = function () {
                        this._propertiesWithCallbacks.forEach(function (e) {
                          e.clearCallbacks();
                        });
                      }),
                      (i.prototype.propertyFromPath = function (e, n) {
                        var s = e.split("/");
                        return this.propertyFromPathSegments(s, 0, n);
                      }),
                      (i.prototype.viewModelFromPathSegments = function (e, n) {
                        var s = this.internalViewModelInstance(e[n]);
                        return s !== null
                          ? n == e.length - 1
                            ? s
                            : s.viewModelFromPathSegments(e, n++)
                          : null;
                      }),
                      (i.prototype.propertyFromPathSegments = function (
                        e,
                        n,
                        s
                      ) {
                        var h,
                          d,
                          y,
                          L,
                          W,
                          F,
                          V,
                          j,
                          de,
                          ie,
                          Fe,
                          pe,
                          Ie,
                          ve,
                          je,
                          xe,
                          Be,
                          Ne;
                        if (n < e.length - 1) {
                          var ze = this.internalViewModelInstance(e[n]);
                          return ze !== null
                            ? ze.propertyFromPathSegments(e, n + 1, s)
                            : null;
                        }
                        var N = null;
                        switch (s) {
                          case Z.Number:
                            if (
                              ((N =
                                (d =
                                  (h = this._runtimeInstance) === null ||
                                  h === void 0
                                    ? void 0
                                    : h.number(e[n])) !== null && d !== void 0
                                  ? d
                                  : null),
                              N !== null)
                            )
                              return new it(N, this);
                            break;
                          case Z.String:
                            if (
                              ((N =
                                (L =
                                  (y = this._runtimeInstance) === null ||
                                  y === void 0
                                    ? void 0
                                    : y.string(e[n])) !== null && L !== void 0
                                  ? L
                                  : null),
                              N !== null)
                            )
                              return new Je(N, this);
                            break;
                          case Z.Boolean:
                            if (
                              ((N =
                                (F =
                                  (W = this._runtimeInstance) === null ||
                                  W === void 0
                                    ? void 0
                                    : W.boolean(e[n])) !== null && F !== void 0
                                  ? F
                                  : null),
                              N !== null)
                            )
                              return new Qe(N, this);
                            break;
                          case Z.Color:
                            if (
                              ((N =
                                (j =
                                  (V = this._runtimeInstance) === null ||
                                  V === void 0
                                    ? void 0
                                    : V.color(e[n])) !== null && j !== void 0
                                  ? j
                                  : null),
                              N !== null)
                            )
                              return new ft(N, this);
                            break;
                          case Z.Trigger:
                            if (
                              ((N =
                                (ie =
                                  (de = this._runtimeInstance) === null ||
                                  de === void 0
                                    ? void 0
                                    : de.trigger(e[n])) !== null &&
                                ie !== void 0
                                  ? ie
                                  : null),
                              N !== null)
                            )
                              return new at(N, this);
                            break;
                          case Z.Enum:
                            if (
                              ((N =
                                (pe =
                                  (Fe = this._runtimeInstance) === null ||
                                  Fe === void 0
                                    ? void 0
                                    : Fe.enum(e[n])) !== null && pe !== void 0
                                  ? pe
                                  : null),
                              N !== null)
                            )
                              return new Ee(N, this);
                            break;
                          case Z.List:
                            if (
                              ((N =
                                (ve =
                                  (Ie = this._runtimeInstance) === null ||
                                  Ie === void 0
                                    ? void 0
                                    : Ie.list(e[n])) !== null && ve !== void 0
                                  ? ve
                                  : null),
                              N !== null)
                            )
                              return new Ue(N, this);
                            break;
                          case Z.Image:
                            if (
                              ((N =
                                (xe =
                                  (je = this._runtimeInstance) === null ||
                                  je === void 0
                                    ? void 0
                                    : je.image(e[n])) !== null && xe !== void 0
                                  ? xe
                                  : null),
                              N !== null)
                            )
                              return new vt(N, this);
                            break;
                          case Z.Artboard:
                            if (
                              ((N =
                                (Ne =
                                  (Be = this._runtimeInstance) === null ||
                                  Be === void 0
                                    ? void 0
                                    : Be.artboard(e[n])) !== null &&
                                Ne !== void 0
                                  ? Ne
                                  : null),
                              N !== null)
                            )
                              return new qe(N, this);
                            break;
                        }
                        return null;
                      }),
                      (i.prototype.internalViewModelInstance = function (e) {
                        var n;
                        if (this._viewModelInstances.has(e))
                          return this._viewModelInstances.get(e);
                        var s =
                          (n = this._runtimeInstance) === null || n === void 0
                            ? void 0
                            : n.viewModel(e);
                        if (s !== null) {
                          var h = new i(s, this);
                          return (
                            h.internalIncrementReferenceCount(),
                            this._viewModelInstances.set(e, h),
                            h
                          );
                        }
                        return null;
                      }),
                      (i.prototype.number = function (e) {
                        var n = this.propertyFromPath(e, Z.Number);
                        return n;
                      }),
                      (i.prototype.string = function (e) {
                        var n = this.propertyFromPath(e, Z.String);
                        return n;
                      }),
                      (i.prototype.boolean = function (e) {
                        var n = this.propertyFromPath(e, Z.Boolean);
                        return n;
                      }),
                      (i.prototype.color = function (e) {
                        var n = this.propertyFromPath(e, Z.Color);
                        return n;
                      }),
                      (i.prototype.trigger = function (e) {
                        var n = this.propertyFromPath(e, Z.Trigger);
                        return n;
                      }),
                      (i.prototype.enum = function (e) {
                        var n = this.propertyFromPath(e, Z.Enum);
                        return n;
                      }),
                      (i.prototype.list = function (e) {
                        var n = this.propertyFromPath(e, Z.List);
                        return n;
                      }),
                      (i.prototype.image = function (e) {
                        var n = this.propertyFromPath(e, Z.Image);
                        return n;
                      }),
                      (i.prototype.artboard = function (e) {
                        var n = this.propertyFromPath(e, Z.Artboard);
                        return n;
                      }),
                      (i.prototype.viewModel = function (e) {
                        var n = e.split("/"),
                          s =
                            n.length > 1
                              ? this.viewModelFromPathSegments(
                                  n.slice(0, n.length - 1),
                                  0
                                )
                              : this;
                        return s != null
                          ? s.internalViewModelInstance(n[n.length - 1])
                          : null;
                      }),
                      (i.prototype.internalReplaceViewModel = function (e, n) {
                        var s;
                        if (n.runtimeInstance !== null) {
                          var h =
                            ((s = this._runtimeInstance) === null ||
                            s === void 0
                              ? void 0
                              : s.replaceViewModel(e, n.runtimeInstance)) || !1;
                          if (h) {
                            n.internalIncrementReferenceCount();
                            var d = this.internalViewModelInstance(e);
                            d !== null &&
                              (d.removeParent(this),
                              this._children.includes(d) &&
                                (this._children = this._children.filter(
                                  function (y) {
                                    return y !== d;
                                  }
                                )),
                              d.cleanup()),
                              this._viewModelInstances.set(e, n),
                              n.addParent(this);
                          }
                          return h;
                        }
                        return !1;
                      }),
                      (i.prototype.replaceViewModel = function (e, n) {
                        var s,
                          h = e.split("/"),
                          d =
                            h.length > 1
                              ? this.viewModelFromPathSegments(
                                  h.slice(0, h.length - 1),
                                  0
                                )
                              : this;
                        return (s = d?.internalReplaceViewModel(
                          h[h.length - 1],
                          n
                        )) !== null && s !== void 0
                          ? s
                          : !1;
                      }),
                      (i.prototype.incrementReferenceCount = function () {
                        var e;
                        this._referenceCount++,
                          (e = this._runtimeInstance) === null ||
                            e === void 0 ||
                            e.incrementReferenceCount();
                      }),
                      (i.prototype.decrementReferenceCount = function () {
                        var e;
                        this._referenceCount--,
                          (e = this._runtimeInstance) === null ||
                            e === void 0 ||
                            e.decrementReferenceCount();
                      }),
                      Object.defineProperty(i.prototype, "properties", {
                        get: function () {
                          var e;
                          return (
                            ((e = this._runtimeInstance) === null ||
                            e === void 0
                              ? void 0
                              : e.getProperties().map(function (n) {
                                  return Y({}, n);
                                })) || []
                          );
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      (i.prototype.internalIncrementReferenceCount =
                        function () {
                          this._referenceCount++;
                        }),
                      (i.prototype.cleanup = function () {
                        var e = this;
                        if (
                          (this._referenceCount--, this._referenceCount <= 0)
                        ) {
                          (this._runtimeInstance = null),
                            this.clearCallbacks(),
                            (this._propertiesWithCallbacks = []),
                            this._viewModelInstances.forEach(function (h) {
                              h.cleanup();
                            }),
                            this._viewModelInstances.clear();
                          var n = me([], this._children, !0);
                          this._children.length = 0;
                          var s = me([], this._parents, !0);
                          (this._parents.length = 0),
                            n.forEach(function (h) {
                              h.removeParent(e);
                            }),
                            s.forEach(function (h) {
                              h.removeFromViewModelCallbacks(e);
                            });
                        }
                      }),
                      i
                    );
                  })(),
                  ce = (function () {
                    function i(e, n) {
                      (this.callbacks = []),
                        (this._viewModelInstanceValue = e),
                        (this._parentViewModel = n);
                    }
                    return (
                      (i.prototype.on = function (e) {
                        this.callbacks.length === 0 &&
                          this._viewModelInstanceValue.clearChanges(),
                          this.callbacks.includes(e) ||
                            (this.callbacks.push(e),
                            this._parentViewModel.addToPropertyCallbacks(this));
                      }),
                      (i.prototype.off = function (e) {
                        e
                          ? (this.callbacks = this.callbacks.filter(function (
                              n
                            ) {
                              return n !== e;
                            }))
                          : (this.callbacks.length = 0),
                          this.callbacks.length === 0 &&
                            this._parentViewModel.removeFromPropertyCallbacks(
                              this
                            );
                      }),
                      (i.prototype.internalHandleCallback = function (e) {}),
                      (i.prototype.handleCallbacks = function () {
                        var e = this;
                        this._viewModelInstanceValue.hasChanged &&
                          this.callbacks.forEach(function (n) {
                            e.internalHandleCallback(n);
                          });
                      }),
                      (i.prototype.clearChanges = function () {
                        this._viewModelInstanceValue.clearChanges();
                      }),
                      (i.prototype.clearCallbacks = function () {
                        this.callbacks.length = 0;
                      }),
                      Object.defineProperty(i.prototype, "name", {
                        get: function () {
                          return this._viewModelInstanceValue.name;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      i
                    );
                  })(),
                  Je = (function (i) {
                    K(e, i);
                    function e(n, s) {
                      return i.call(this, n, s) || this;
                    }
                    return (
                      Object.defineProperty(e.prototype, "value", {
                        get: function () {
                          return this._viewModelInstanceValue.value;
                        },
                        set: function (n) {
                          this._viewModelInstanceValue.value = n;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      (e.prototype.internalHandleCallback = function (n) {
                        n(this.value);
                      }),
                      e
                    );
                  })(ce),
                  it = (function (i) {
                    K(e, i);
                    function e(n, s) {
                      return i.call(this, n, s) || this;
                    }
                    return (
                      Object.defineProperty(e.prototype, "value", {
                        get: function () {
                          return this._viewModelInstanceValue.value;
                        },
                        set: function (n) {
                          this._viewModelInstanceValue.value = n;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      (e.prototype.internalHandleCallback = function (n) {
                        n(this.value);
                      }),
                      e
                    );
                  })(ce),
                  Qe = (function (i) {
                    K(e, i);
                    function e(n, s) {
                      return i.call(this, n, s) || this;
                    }
                    return (
                      Object.defineProperty(e.prototype, "value", {
                        get: function () {
                          return this._viewModelInstanceValue.value;
                        },
                        set: function (n) {
                          this._viewModelInstanceValue.value = n;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      (e.prototype.internalHandleCallback = function (n) {
                        n(this.value);
                      }),
                      e
                    );
                  })(ce),
                  at = (function (i) {
                    K(e, i);
                    function e(n, s) {
                      return i.call(this, n, s) || this;
                    }
                    return (
                      (e.prototype.trigger = function () {
                        return this._viewModelInstanceValue.trigger();
                      }),
                      (e.prototype.internalHandleCallback = function (n) {
                        n();
                      }),
                      e
                    );
                  })(ce),
                  Ee = (function (i) {
                    K(e, i);
                    function e(n, s) {
                      return i.call(this, n, s) || this;
                    }
                    return (
                      Object.defineProperty(e.prototype, "value", {
                        get: function () {
                          return this._viewModelInstanceValue.value;
                        },
                        set: function (n) {
                          this._viewModelInstanceValue.value = n;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      Object.defineProperty(e.prototype, "valueIndex", {
                        get: function () {
                          return this._viewModelInstanceValue.valueIndex;
                        },
                        set: function (n) {
                          this._viewModelInstanceValue.valueIndex = n;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      Object.defineProperty(e.prototype, "values", {
                        get: function () {
                          return this._viewModelInstanceValue.values;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      (e.prototype.internalHandleCallback = function (n) {
                        n(this.value);
                      }),
                      e
                    );
                  })(ce),
                  Ue = (function (i) {
                    K(e, i);
                    function e(n, s) {
                      return i.call(this, n, s) || this;
                    }
                    return (
                      Object.defineProperty(e.prototype, "length", {
                        get: function () {
                          return this._viewModelInstanceValue.size;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      (e.prototype.addInstance = function (n) {
                        n.runtimeInstance != null &&
                          (this._viewModelInstanceValue.addInstance(
                            n.runtimeInstance
                          ),
                          n.addParent(this._parentViewModel));
                      }),
                      (e.prototype.addInstanceAt = function (n, s) {
                        return n.runtimeInstance != null &&
                          this._viewModelInstanceValue.addInstanceAt(
                            n.runtimeInstance,
                            s
                          )
                          ? (n.addParent(this._parentViewModel), !0)
                          : !1;
                      }),
                      (e.prototype.removeInstance = function (n) {
                        n.runtimeInstance != null &&
                          (this._viewModelInstanceValue.removeInstance(
                            n.runtimeInstance
                          ),
                          n.removeParent(this._parentViewModel));
                      }),
                      (e.prototype.removeInstanceAt = function (n) {
                        this._viewModelInstanceValue.removeInstanceAt(n);
                      }),
                      (e.prototype.instanceAt = function (n) {
                        var s = this._viewModelInstanceValue.instanceAt(n);
                        if (s != null) {
                          var h = new Oe(s, this._parentViewModel);
                          return h;
                        }
                        return null;
                      }),
                      (e.prototype.swap = function (n, s) {
                        this._viewModelInstanceValue.swap(n, s);
                      }),
                      (e.prototype.internalHandleCallback = function (n) {
                        n();
                      }),
                      e
                    );
                  })(ce),
                  ft = (function (i) {
                    K(e, i);
                    function e(n, s) {
                      return i.call(this, n, s) || this;
                    }
                    return (
                      Object.defineProperty(e.prototype, "value", {
                        get: function () {
                          return this._viewModelInstanceValue.value;
                        },
                        set: function (n) {
                          this._viewModelInstanceValue.value = n;
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      (e.prototype.rgb = function (n, s, h) {
                        this._viewModelInstanceValue.rgb(n, s, h);
                      }),
                      (e.prototype.rgba = function (n, s, h, d) {
                        this._viewModelInstanceValue.argb(d, n, s, h);
                      }),
                      (e.prototype.argb = function (n, s, h, d) {
                        this._viewModelInstanceValue.argb(n, s, h, d);
                      }),
                      (e.prototype.alpha = function (n) {
                        this._viewModelInstanceValue.alpha(n);
                      }),
                      (e.prototype.opacity = function (n) {
                        this._viewModelInstanceValue.alpha(
                          Math.round(Math.max(0, Math.min(1, n)) * 255)
                        );
                      }),
                      (e.prototype.internalHandleCallback = function (n) {
                        n(this.value);
                      }),
                      e
                    );
                  })(ce),
                  vt = (function (i) {
                    K(e, i);
                    function e(n, s) {
                      return i.call(this, n, s) || this;
                    }
                    return (
                      Object.defineProperty(e.prototype, "value", {
                        set: function (n) {
                          var s;
                          this._viewModelInstanceValue.value(
                            (s = n?.nativeImage) !== null && s !== void 0
                              ? s
                              : null
                          );
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      (e.prototype.internalHandleCallback = function (n) {
                        n();
                      }),
                      e
                    );
                  })(ce),
                  qe = (function (i) {
                    K(e, i);
                    function e(n, s) {
                      return i.call(this, n, s) || this;
                    }
                    return (
                      Object.defineProperty(e.prototype, "value", {
                        set: function (n) {
                          var s;
                          this._viewModelInstanceValue.value(
                            (s = n?.nativeArtboard) !== null && s !== void 0
                              ? s
                              : null
                          );
                        },
                        enumerable: !1,
                        configurable: !0,
                      }),
                      (e.prototype.internalHandleCallback = function (n) {
                        n();
                      }),
                      e
                    );
                  })(ce),
                  wt = function (i) {
                    return T(void 0, void 0, void 0, function () {
                      var e, n, s;
                      return c(this, function (h) {
                        switch (h.label) {
                          case 0:
                            return (e = new Request(i)), [4, fetch(e)];
                          case 1:
                            return (n = h.sent()), [4, n.arrayBuffer()];
                          case 2:
                            return (s = h.sent()), [2, s];
                        }
                      });
                    });
                  },
                  Se = function (i) {
                    return typeof i == "string"
                      ? [i]
                      : i instanceof Array
                      ? i
                      : [];
                  },
                  Bt = { EventManager: he, TaskQueueManager: ye },
                  At = function (i) {
                    return T(void 0, void 0, void 0, function () {
                      var e, n, s;
                      return c(this, function (h) {
                        switch (h.label) {
                          case 0:
                            return (
                              (e = new Promise(function (d) {
                                return ne.getInstance(function (y) {
                                  y.decodeAudio(i, d);
                                });
                              })),
                              [4, e]
                            );
                          case 1:
                            return (
                              (n = h.sent()),
                              (s = new G.AudioWrapper(n)),
                              G.finalizationRegistry.register(s, n),
                              [2, s]
                            );
                        }
                      });
                    });
                  },
                  Nt = function (i) {
                    return T(void 0, void 0, void 0, function () {
                      var e, n, s;
                      return c(this, function (h) {
                        switch (h.label) {
                          case 0:
                            return (
                              (e = new Promise(function (d) {
                                return ne.getInstance(function (y) {
                                  y.decodeImage(i, d);
                                });
                              })),
                              [4, e]
                            );
                          case 1:
                            return (
                              (n = h.sent()),
                              (s = new G.ImageWrapper(n)),
                              G.finalizationRegistry.register(s, n),
                              [2, s]
                            );
                        }
                      });
                    });
                  },
                  mt = function (i) {
                    return T(void 0, void 0, void 0, function () {
                      var e, n, s;
                      return c(this, function (h) {
                        switch (h.label) {
                          case 0:
                            return (
                              (e = new Promise(function (d) {
                                return ne.getInstance(function (y) {
                                  y.decodeFont(i, d);
                                });
                              })),
                              [4, e]
                            );
                          case 1:
                            return (
                              (n = h.sent()),
                              (s = new G.FontWrapper(n)),
                              G.finalizationRegistry.register(s, n),
                              [2, s]
                            );
                        }
                      });
                    });
                  };
              })(),
              Ut
            );
          })()
        );
      })(kt)),
    kt.exports
  );
}
var Jn = Gn();
export { Jn as r };
