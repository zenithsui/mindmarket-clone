import { r as t } from "./index.esm.Fld8o4I5.js";
import { m as e } from "./index.DtsRjIc2.js";
const o = e({ width: window.innerWidth, height: window.innerHeight }),
  d = e({ width: window.innerWidth, height: window.innerHeight });
window.addEventListener("resize", () => {
  const n = window.innerWidth,
    i = window.innerHeight;
  o.set({ width: n, height: i });
});
const w = () => {
  const n = window.innerWidth,
    i = window.innerHeight;
  d.set({ width: n, height: i });
};
window.addEventListener("resize", t(w, 200));
export { d as $ };
